/**
 * GMPWebServicesTest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.9  Built on : Nov 16, 2018 (12:05:37 GMT)
 */
package org.tempuri;


/*
 *  GMPWebServicesTest Junit test case
 */
public class GMPWebServicesTest extends junit.framework.TestCase {
    /**
     * Auto generated test method
     */
    public void testconsultaParceiroAgencia() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub(); //the default implementation should point to the right endpoint

        org.tempuri.ConsultaParceiroAgenciaDocument consultaParceiroAgencia252 = (org.tempuri.ConsultaParceiroAgenciaDocument) getTestObject(org.tempuri.ConsultaParceiroAgenciaDocument.class);
        // TODO : Fill in the consultaParceiroAgencia252 here
        assertNotNull(stub.consultaParceiroAgencia(consultaParceiroAgencia252));
    }

    /**
     * Auto generated test method
     */
    public void testStartconsultaParceiroAgencia() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub();
        org.tempuri.ConsultaParceiroAgenciaDocument consultaParceiroAgencia252 = (org.tempuri.ConsultaParceiroAgenciaDocument) getTestObject(org.tempuri.ConsultaParceiroAgenciaDocument.class);
        // TODO : Fill in the consultaParceiroAgencia252 here
        stub.startconsultaParceiroAgencia(consultaParceiroAgencia252,
            new tempCallbackN1000C());
    }

    /**
     * Auto generated test method
     */
    public void testconsultarDadosParceiro() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub(); //the default implementation should point to the right endpoint

        org.tempuri.ConsultarDadosParceiroDocument consultarDadosParceiro254 = (org.tempuri.ConsultarDadosParceiroDocument) getTestObject(org.tempuri.ConsultarDadosParceiroDocument.class);
        // TODO : Fill in the consultarDadosParceiro254 here
        assertNotNull(stub.consultarDadosParceiro(consultarDadosParceiro254));
    }

    /**
     * Auto generated test method
     */
    public void testStartconsultarDadosParceiro() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub();
        org.tempuri.ConsultarDadosParceiroDocument consultarDadosParceiro254 = (org.tempuri.ConsultarDadosParceiroDocument) getTestObject(org.tempuri.ConsultarDadosParceiroDocument.class);
        // TODO : Fill in the consultarDadosParceiro254 here
        stub.startconsultarDadosParceiro(consultarDadosParceiro254,
            new tempCallbackN10035());
    }

    /**
     * Auto generated test method
     */
    public void testconsultarDadosInstalacao() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub(); //the default implementation should point to the right endpoint

        org.tempuri.ConsultarDadosInstalacaoDocument consultarDadosInstalacao256 =
            (org.tempuri.ConsultarDadosInstalacaoDocument) getTestObject(org.tempuri.ConsultarDadosInstalacaoDocument.class);
        // TODO : Fill in the consultarDadosInstalacao256 here
        assertNotNull(stub.consultarDadosInstalacao(consultarDadosInstalacao256));
    }

    /**
     * Auto generated test method
     */
    public void testStartconsultarDadosInstalacao() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub();
        org.tempuri.ConsultarDadosInstalacaoDocument consultarDadosInstalacao256 =
            (org.tempuri.ConsultarDadosInstalacaoDocument) getTestObject(org.tempuri.ConsultarDadosInstalacaoDocument.class);
        // TODO : Fill in the consultarDadosInstalacao256 here
        stub.startconsultarDadosInstalacao(consultarDadosInstalacao256,
            new tempCallbackN1005E());
    }

    /**
     * Auto generated test method
     */
    public void testcadastrarDoacao() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub(); //the default implementation should point to the right endpoint

        org.tempuri.CadastrarDoacaoDocument cadastrarDoacao258 = (org.tempuri.CadastrarDoacaoDocument) getTestObject(org.tempuri.CadastrarDoacaoDocument.class);
        // TODO : Fill in the cadastrarDoacao258 here
        assertNotNull(stub.cadastrarDoacao(cadastrarDoacao258));
    }

    /**
     * Auto generated test method
     */
    public void testStartcadastrarDoacao() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub();
        org.tempuri.CadastrarDoacaoDocument cadastrarDoacao258 = (org.tempuri.CadastrarDoacaoDocument) getTestObject(org.tempuri.CadastrarDoacaoDocument.class);
        // TODO : Fill in the cadastrarDoacao258 here
        stub.startcadastrarDoacao(cadastrarDoacao258, new tempCallbackN10087());
    }

    /**
     * Auto generated test method
     */
    public void testgerarProtocoloSimulacaoFintech() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub(); //the default implementation should point to the right endpoint

        org.tempuri.GerarProtocoloSimulacaoFintechDocument gerarProtocoloSimulacaoFintech260 =
            (org.tempuri.GerarProtocoloSimulacaoFintechDocument) getTestObject(org.tempuri.GerarProtocoloSimulacaoFintechDocument.class);
        // TODO : Fill in the gerarProtocoloSimulacaoFintech260 here
        assertNotNull(stub.gerarProtocoloSimulacaoFintech(
                gerarProtocoloSimulacaoFintech260));
    }

    /**
     * Auto generated test method
     */
    public void testStartgerarProtocoloSimulacaoFintech()
        throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub();
        org.tempuri.GerarProtocoloSimulacaoFintechDocument gerarProtocoloSimulacaoFintech260 =
            (org.tempuri.GerarProtocoloSimulacaoFintechDocument) getTestObject(org.tempuri.GerarProtocoloSimulacaoFintechDocument.class);
        // TODO : Fill in the gerarProtocoloSimulacaoFintech260 here
        stub.startgerarProtocoloSimulacaoFintech(gerarProtocoloSimulacaoFintech260,
            new tempCallbackN100B0());
    }

    /**
     * Auto generated test method
     */
    public void testconsultarProdutoParceiro() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub(); //the default implementation should point to the right endpoint

        org.tempuri.ConsultarProdutoParceiroDocument consultarProdutoParceiro262 =
            (org.tempuri.ConsultarProdutoParceiroDocument) getTestObject(org.tempuri.ConsultarProdutoParceiroDocument.class);
        // TODO : Fill in the consultarProdutoParceiro262 here
        assertNotNull(stub.consultarProdutoParceiro(consultarProdutoParceiro262));
    }

    /**
     * Auto generated test method
     */
    public void testStartconsultarProdutoParceiro() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub();
        org.tempuri.ConsultarProdutoParceiroDocument consultarProdutoParceiro262 =
            (org.tempuri.ConsultarProdutoParceiroDocument) getTestObject(org.tempuri.ConsultarProdutoParceiroDocument.class);
        // TODO : Fill in the consultarProdutoParceiro262 here
        stub.startconsultarProdutoParceiro(consultarProdutoParceiro262,
            new tempCallbackN100D9());
    }

    /**
     * Auto generated test method
     */
    public void testexcluirDoacao() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub(); //the default implementation should point to the right endpoint

        org.tempuri.ExcluirDoacaoDocument excluirDoacao264 = (org.tempuri.ExcluirDoacaoDocument) getTestObject(org.tempuri.ExcluirDoacaoDocument.class);
        // TODO : Fill in the excluirDoacao264 here
        assertNotNull(stub.excluirDoacao(excluirDoacao264));
    }

    /**
     * Auto generated test method
     */
    public void testStartexcluirDoacao() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub();
        org.tempuri.ExcluirDoacaoDocument excluirDoacao264 = (org.tempuri.ExcluirDoacaoDocument) getTestObject(org.tempuri.ExcluirDoacaoDocument.class);
        // TODO : Fill in the excluirDoacao264 here
        stub.startexcluirDoacao(excluirDoacao264, new tempCallbackN10102());
    }

    /**
     * Auto generated test method
     */
    public void testcadastrarCliente() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub(); //the default implementation should point to the right endpoint

        org.tempuri.CadastrarClienteDocument cadastrarCliente266 = (org.tempuri.CadastrarClienteDocument) getTestObject(org.tempuri.CadastrarClienteDocument.class);
        // TODO : Fill in the cadastrarCliente266 here
        assertNotNull(stub.cadastrarCliente(cadastrarCliente266));
    }

    /**
     * Auto generated test method
     */
    public void testStartcadastrarCliente() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub();
        org.tempuri.CadastrarClienteDocument cadastrarCliente266 = (org.tempuri.CadastrarClienteDocument) getTestObject(org.tempuri.CadastrarClienteDocument.class);
        // TODO : Fill in the cadastrarCliente266 here
        stub.startcadastrarCliente(cadastrarCliente266, new tempCallbackN1012B());
    }

    /**
     * Auto generated test method
     */
    public void testcadastrarCobrancaFintech() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub(); //the default implementation should point to the right endpoint

        org.tempuri.CadastrarCobrancaFintechDocument cadastrarCobrancaFintech268 =
            (org.tempuri.CadastrarCobrancaFintechDocument) getTestObject(org.tempuri.CadastrarCobrancaFintechDocument.class);
        // TODO : Fill in the cadastrarCobrancaFintech268 here
        assertNotNull(stub.cadastrarCobrancaFintech(cadastrarCobrancaFintech268));
    }

    /**
     * Auto generated test method
     */
    public void testStartcadastrarCobrancaFintech() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub();
        org.tempuri.CadastrarCobrancaFintechDocument cadastrarCobrancaFintech268 =
            (org.tempuri.CadastrarCobrancaFintechDocument) getTestObject(org.tempuri.CadastrarCobrancaFintechDocument.class);
        // TODO : Fill in the cadastrarCobrancaFintech268 here
        stub.startcadastrarCobrancaFintech(cadastrarCobrancaFintech268,
            new tempCallbackN10154());
    }

    /**
     * Auto generated test method
     */
    public void testcadastrarCobranca() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub(); //the default implementation should point to the right endpoint

        org.tempuri.CadastrarCobrancaDocument cadastrarCobranca270 = (org.tempuri.CadastrarCobrancaDocument) getTestObject(org.tempuri.CadastrarCobrancaDocument.class);
        // TODO : Fill in the cadastrarCobranca270 here
        assertNotNull(stub.cadastrarCobranca(cadastrarCobranca270));
    }

    /**
     * Auto generated test method
     */
    public void testStartcadastrarCobranca() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub();
        org.tempuri.CadastrarCobrancaDocument cadastrarCobranca270 = (org.tempuri.CadastrarCobrancaDocument) getTestObject(org.tempuri.CadastrarCobrancaDocument.class);
        // TODO : Fill in the cadastrarCobranca270 here
        stub.startcadastrarCobranca(cadastrarCobranca270,
            new tempCallbackN1017D());
    }

    /**
     * Auto generated test method
     */
    public void testenviarNotificacaoSMS() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub(); //the default implementation should point to the right endpoint

        org.tempuri.EnviarNotificacaoSMSDocument enviarNotificacaoSMS272 = (org.tempuri.EnviarNotificacaoSMSDocument) getTestObject(org.tempuri.EnviarNotificacaoSMSDocument.class);
        // TODO : Fill in the enviarNotificacaoSMS272 here
        assertNotNull(stub.enviarNotificacaoSMS(enviarNotificacaoSMS272));
    }

    /**
     * Auto generated test method
     */
    public void testStartenviarNotificacaoSMS() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub();
        org.tempuri.EnviarNotificacaoSMSDocument enviarNotificacaoSMS272 = (org.tempuri.EnviarNotificacaoSMSDocument) getTestObject(org.tempuri.EnviarNotificacaoSMSDocument.class);
        // TODO : Fill in the enviarNotificacaoSMS272 here
        stub.startenviarNotificacaoSMS(enviarNotificacaoSMS272,
            new tempCallbackN101A6());
    }

    /**
     * Auto generated test method
     */
    public void testvalidarConsulta() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub(); //the default implementation should point to the right endpoint

        org.tempuri.ValidarConsultaDocument validarConsulta274 = (org.tempuri.ValidarConsultaDocument) getTestObject(org.tempuri.ValidarConsultaDocument.class);
        // TODO : Fill in the validarConsulta274 here
        assertNotNull(stub.validarConsulta(validarConsulta274));
    }

    /**
     * Auto generated test method
     */
    public void testStartvalidarConsulta() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub();
        org.tempuri.ValidarConsultaDocument validarConsulta274 = (org.tempuri.ValidarConsultaDocument) getTestObject(org.tempuri.ValidarConsultaDocument.class);
        // TODO : Fill in the validarConsulta274 here
        stub.startvalidarConsulta(validarConsulta274, new tempCallbackN101CF());
    }

    /**
     * Auto generated test method
     */
    public void testconsultarDadosFatura() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub(); //the default implementation should point to the right endpoint

        org.tempuri.ConsultarDadosFaturaDocument consultarDadosFatura276 = (org.tempuri.ConsultarDadosFaturaDocument) getTestObject(org.tempuri.ConsultarDadosFaturaDocument.class);
        // TODO : Fill in the consultarDadosFatura276 here
        assertNotNull(stub.consultarDadosFatura(consultarDadosFatura276));
    }

    /**
     * Auto generated test method
     */
    public void testStartconsultarDadosFatura() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub();
        org.tempuri.ConsultarDadosFaturaDocument consultarDadosFatura276 = (org.tempuri.ConsultarDadosFaturaDocument) getTestObject(org.tempuri.ConsultarDadosFaturaDocument.class);
        // TODO : Fill in the consultarDadosFatura276 here
        stub.startconsultarDadosFatura(consultarDadosFatura276,
            new tempCallbackN101F8());
    }

    /**
     * Auto generated test method
     */
    public void testexcluirCobranca() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub(); //the default implementation should point to the right endpoint

        org.tempuri.ExcluirCobrancaDocument excluirCobranca278 = (org.tempuri.ExcluirCobrancaDocument) getTestObject(org.tempuri.ExcluirCobrancaDocument.class);
        // TODO : Fill in the excluirCobranca278 here
        assertNotNull(stub.excluirCobranca(excluirCobranca278));
    }

    /**
     * Auto generated test method
     */
    public void testStartexcluirCobranca() throws java.lang.Exception {
        org.tempuri.GMPWebServicesStub stub = new org.tempuri.GMPWebServicesStub();
        org.tempuri.ExcluirCobrancaDocument excluirCobranca278 = (org.tempuri.ExcluirCobrancaDocument) getTestObject(org.tempuri.ExcluirCobrancaDocument.class);
        // TODO : Fill in the excluirCobranca278 here
        stub.startexcluirCobranca(excluirCobranca278, new tempCallbackN10221());
    }

    //Create the desired XmlObject and provide it as the test object
    public org.apache.xmlbeans.XmlObject getTestObject(java.lang.Class type)
        throws java.lang.Exception {
        java.lang.reflect.Method creatorMethod = null;

        if (org.apache.xmlbeans.XmlObject.class.isAssignableFrom(type)) {
            Class[] declaredClasses = type.getDeclaredClasses();

            for (int i = 0; i < declaredClasses.length; i++) {
                Class declaredClass = declaredClasses[i];

                if (declaredClass.getName().endsWith("$Factory")) {
                    creatorMethod = declaredClass.getMethod("newInstance", null);

                    break;
                }
            }
        }

        if (creatorMethod != null) {
            return (org.apache.xmlbeans.XmlObject) creatorMethod.invoke(null,
                null);
        } else {
            throw new java.lang.Exception("Creator not found!");
        }
    }

    private class tempCallbackN1000C extends org.tempuri.GMPWebServicesCallbackHandler {
        public tempCallbackN1000C() {
            super(null);
        }

        public void receiveResultconsultaParceiroAgencia(
            org.tempuri.ConsultaParceiroAgenciaResponseDocument result) {
        }

        public void receiveErrorconsultaParceiroAgencia(java.lang.Exception e) {
            fail();
        }
    }

    private class tempCallbackN10035 extends org.tempuri.GMPWebServicesCallbackHandler {
        public tempCallbackN10035() {
            super(null);
        }

        public void receiveResultconsultarDadosParceiro(
            org.tempuri.ConsultarDadosParceiroResponseDocument result) {
        }

        public void receiveErrorconsultarDadosParceiro(java.lang.Exception e) {
            fail();
        }
    }

    private class tempCallbackN1005E extends org.tempuri.GMPWebServicesCallbackHandler {
        public tempCallbackN1005E() {
            super(null);
        }

        public void receiveResultconsultarDadosInstalacao(
            org.tempuri.ConsultarDadosInstalacaoResponseDocument result) {
        }

        public void receiveErrorconsultarDadosInstalacao(java.lang.Exception e) {
            fail();
        }
    }

    private class tempCallbackN10087 extends org.tempuri.GMPWebServicesCallbackHandler {
        public tempCallbackN10087() {
            super(null);
        }

        public void receiveResultcadastrarDoacao(
            org.tempuri.CadastrarDoacaoResponseDocument result) {
        }

        public void receiveErrorcadastrarDoacao(java.lang.Exception e) {
            fail();
        }
    }

    private class tempCallbackN100B0 extends org.tempuri.GMPWebServicesCallbackHandler {
        public tempCallbackN100B0() {
            super(null);
        }

        public void receiveResultgerarProtocoloSimulacaoFintech(
            org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument result) {
        }

        public void receiveErrorgerarProtocoloSimulacaoFintech(
            java.lang.Exception e) {
            fail();
        }
    }

    private class tempCallbackN100D9 extends org.tempuri.GMPWebServicesCallbackHandler {
        public tempCallbackN100D9() {
            super(null);
        }

        public void receiveResultconsultarProdutoParceiro(
            org.tempuri.ConsultarProdutoParceiroResponseDocument result) {
        }

        public void receiveErrorconsultarProdutoParceiro(java.lang.Exception e) {
            fail();
        }
    }

    private class tempCallbackN10102 extends org.tempuri.GMPWebServicesCallbackHandler {
        public tempCallbackN10102() {
            super(null);
        }

        public void receiveResultexcluirDoacao(
            org.tempuri.ExcluirDoacaoResponseDocument result) {
        }

        public void receiveErrorexcluirDoacao(java.lang.Exception e) {
            fail();
        }
    }

    private class tempCallbackN1012B extends org.tempuri.GMPWebServicesCallbackHandler {
        public tempCallbackN1012B() {
            super(null);
        }

        public void receiveResultcadastrarCliente(
            org.tempuri.CadastrarClienteResponseDocument result) {
        }

        public void receiveErrorcadastrarCliente(java.lang.Exception e) {
            fail();
        }
    }

    private class tempCallbackN10154 extends org.tempuri.GMPWebServicesCallbackHandler {
        public tempCallbackN10154() {
            super(null);
        }

        public void receiveResultcadastrarCobrancaFintech(
            org.tempuri.CadastrarCobrancaFintechResponseDocument result) {
        }

        public void receiveErrorcadastrarCobrancaFintech(java.lang.Exception e) {
            fail();
        }
    }

    private class tempCallbackN1017D extends org.tempuri.GMPWebServicesCallbackHandler {
        public tempCallbackN1017D() {
            super(null);
        }

        public void receiveResultcadastrarCobranca(
            org.tempuri.CadastrarCobrancaResponseDocument result) {
        }

        public void receiveErrorcadastrarCobranca(java.lang.Exception e) {
            fail();
        }
    }

    private class tempCallbackN101A6 extends org.tempuri.GMPWebServicesCallbackHandler {
        public tempCallbackN101A6() {
            super(null);
        }

        public void receiveResultenviarNotificacaoSMS(
            org.tempuri.EnviarNotificacaoSMSResponseDocument result) {
        }

        public void receiveErrorenviarNotificacaoSMS(java.lang.Exception e) {
            fail();
        }
    }

    private class tempCallbackN101CF extends org.tempuri.GMPWebServicesCallbackHandler {
        public tempCallbackN101CF() {
            super(null);
        }

        public void receiveResultvalidarConsulta(
            org.tempuri.ValidarConsultaResponseDocument result) {
        }

        public void receiveErrorvalidarConsulta(java.lang.Exception e) {
            fail();
        }
    }

    private class tempCallbackN101F8 extends org.tempuri.GMPWebServicesCallbackHandler {
        public tempCallbackN101F8() {
            super(null);
        }

        public void receiveResultconsultarDadosFatura(
            org.tempuri.ConsultarDadosFaturaResponseDocument result) {
        }

        public void receiveErrorconsultarDadosFatura(java.lang.Exception e) {
            fail();
        }
    }

    private class tempCallbackN10221 extends org.tempuri.GMPWebServicesCallbackHandler {
        public tempCallbackN10221() {
            super(null);
        }

        public void receiveResultexcluirCobranca(
            org.tempuri.ExcluirCobrancaResponseDocument result) {
        }

        public void receiveErrorexcluirCobranca(java.lang.Exception e) {
            fail();
        }
    }
}
