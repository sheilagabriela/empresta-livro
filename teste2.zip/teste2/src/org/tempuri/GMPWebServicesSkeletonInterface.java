/**
 * GMPWebServicesSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.9  Built on : Nov 16, 2018 (12:05:37 GMT)
 */
package org.tempuri;

/**
 *  GMPWebServicesSkeletonInterface java skeleton interface for the axisService
 */
public interface GMPWebServicesSkeletonInterface {
    /**
     * Auto generated method signature
     *
     * @param consultaParceiroAgencia
     */
    public org.tempuri.ConsultaParceiroAgenciaResponseDocument consultaParceiroAgencia(
        org.tempuri.ConsultaParceiroAgenciaDocument consultaParceiroAgencia);

    /**
     * Auto generated method signature
     *
     * @param consultarDadosParceiro
     */
    public org.tempuri.ConsultarDadosParceiroResponseDocument consultarDadosParceiro(
        org.tempuri.ConsultarDadosParceiroDocument consultarDadosParceiro);

    /**
     * Auto generated method signature
     *
     * @param consultarDadosInstalacao
     */
    public org.tempuri.ConsultarDadosInstalacaoResponseDocument consultarDadosInstalacao(
        org.tempuri.ConsultarDadosInstalacaoDocument consultarDadosInstalacao);

    /**
     * Auto generated method signature
     *
     * @param cadastrarDoacao
     */
    public org.tempuri.CadastrarDoacaoResponseDocument cadastrarDoacao(
        org.tempuri.CadastrarDoacaoDocument cadastrarDoacao);

    /**
     * Auto generated method signature
     *
     * @param gerarProtocoloSimulacaoFintech
     */
    public org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument gerarProtocoloSimulacaoFintech(
        org.tempuri.GerarProtocoloSimulacaoFintechDocument gerarProtocoloSimulacaoFintech);

    /**
     * Auto generated method signature
     *
     * @param consultarProdutoParceiro
     */
    public org.tempuri.ConsultarProdutoParceiroResponseDocument consultarProdutoParceiro(
        org.tempuri.ConsultarProdutoParceiroDocument consultarProdutoParceiro);

    /**
     * Auto generated method signature
     *
     * @param excluirDoacao
     */
    public org.tempuri.ExcluirDoacaoResponseDocument excluirDoacao(
        org.tempuri.ExcluirDoacaoDocument excluirDoacao);

    /**
     * Auto generated method signature
     *
     * @param cadastrarCliente
     */
    public org.tempuri.CadastrarClienteResponseDocument cadastrarCliente(
        org.tempuri.CadastrarClienteDocument cadastrarCliente);

    /**
     * Auto generated method signature
     *
     * @param cadastrarCobrancaFintech
     */
    public org.tempuri.CadastrarCobrancaFintechResponseDocument cadastrarCobrancaFintech(
        org.tempuri.CadastrarCobrancaFintechDocument cadastrarCobrancaFintech);

    /**
     * Auto generated method signature
     *
     * @param cadastrarCobranca
     */
    public org.tempuri.CadastrarCobrancaResponseDocument cadastrarCobranca(
        org.tempuri.CadastrarCobrancaDocument cadastrarCobranca);

    /**
     * Auto generated method signature
     *
     * @param enviarNotificacaoSMS
     */
    public org.tempuri.EnviarNotificacaoSMSResponseDocument enviarNotificacaoSMS(
        org.tempuri.EnviarNotificacaoSMSDocument enviarNotificacaoSMS);

    /**
     * Auto generated method signature
     *
     * @param validarConsulta
     */
    public org.tempuri.ValidarConsultaResponseDocument validarConsulta(
        org.tempuri.ValidarConsultaDocument validarConsulta);

    /**
     * Auto generated method signature
     *
     * @param consultarDadosFatura
     */
    public org.tempuri.ConsultarDadosFaturaResponseDocument consultarDadosFatura(
        org.tempuri.ConsultarDadosFaturaDocument consultarDadosFatura);

    /**
     * Auto generated method signature
     *
     * @param excluirCobranca
     */
    public org.tempuri.ExcluirCobrancaResponseDocument excluirCobranca(
        org.tempuri.ExcluirCobrancaDocument excluirCobranca);
}
