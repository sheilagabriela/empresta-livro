/*
 * An XML document type.
 * Localname: ConsultarDadosInstalacaoResponse
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.ConsultarDadosInstalacaoResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one ConsultarDadosInstalacaoResponse(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class ConsultarDadosInstalacaoResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultarDadosInstalacaoResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarDadosInstalacaoResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTARDADOSINSTALACAORESPONSE$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "ConsultarDadosInstalacaoResponse");
    
    
    /**
     * Gets the "ConsultarDadosInstalacaoResponse" element
     */
    public org.tempuri.ConsultarDadosInstalacaoResponseDocument.ConsultarDadosInstalacaoResponse getConsultarDadosInstalacaoResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultarDadosInstalacaoResponseDocument.ConsultarDadosInstalacaoResponse target = null;
            target = (org.tempuri.ConsultarDadosInstalacaoResponseDocument.ConsultarDadosInstalacaoResponse)get_store().find_element_user(CONSULTARDADOSINSTALACAORESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultarDadosInstalacaoResponse" element
     */
    public void setConsultarDadosInstalacaoResponse(org.tempuri.ConsultarDadosInstalacaoResponseDocument.ConsultarDadosInstalacaoResponse consultarDadosInstalacaoResponse)
    {
        generatedSetterHelperImpl(consultarDadosInstalacaoResponse, CONSULTARDADOSINSTALACAORESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultarDadosInstalacaoResponse" element
     */
    public org.tempuri.ConsultarDadosInstalacaoResponseDocument.ConsultarDadosInstalacaoResponse addNewConsultarDadosInstalacaoResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultarDadosInstalacaoResponseDocument.ConsultarDadosInstalacaoResponse target = null;
            target = (org.tempuri.ConsultarDadosInstalacaoResponseDocument.ConsultarDadosInstalacaoResponse)get_store().add_element_user(CONSULTARDADOSINSTALACAORESPONSE$0);
            return target;
        }
    }
    /**
     * An XML ConsultarDadosInstalacaoResponse(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class ConsultarDadosInstalacaoResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultarDadosInstalacaoResponseDocument.ConsultarDadosInstalacaoResponse
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultarDadosInstalacaoResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CONSULTARDADOSINSTALACAORESULT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "ConsultarDadosInstalacaoResult");
        
        
        /**
         * Gets the "ConsultarDadosInstalacaoResult" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO getConsultarDadosInstalacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO)get_store().find_element_user(CONSULTARDADOSINSTALACAORESULT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "ConsultarDadosInstalacaoResult" element
         */
        public boolean isNilConsultarDadosInstalacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO)get_store().find_element_user(CONSULTARDADOSINSTALACAORESULT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "ConsultarDadosInstalacaoResult" element
         */
        public boolean isSetConsultarDadosInstalacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CONSULTARDADOSINSTALACAORESULT$0) != 0;
            }
        }
        
        /**
         * Sets the "ConsultarDadosInstalacaoResult" element
         */
        public void setConsultarDadosInstalacaoResult(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO consultarDadosInstalacaoResult)
        {
            generatedSetterHelperImpl(consultarDadosInstalacaoResult, CONSULTARDADOSINSTALACAORESULT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ConsultarDadosInstalacaoResult" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO addNewConsultarDadosInstalacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO)get_store().add_element_user(CONSULTARDADOSINSTALACAORESULT$0);
                return target;
            }
        }
        
        /**
         * Nils the "ConsultarDadosInstalacaoResult" element
         */
        public void setNilConsultarDadosInstalacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO)get_store().find_element_user(CONSULTARDADOSINSTALACAORESULT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO)get_store().add_element_user(CONSULTARDADOSINSTALACAORESULT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "ConsultarDadosInstalacaoResult" element
         */
        public void unsetConsultarDadosInstalacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CONSULTARDADOSINSTALACAORESULT$0, 0);
            }
        }
    }
}
