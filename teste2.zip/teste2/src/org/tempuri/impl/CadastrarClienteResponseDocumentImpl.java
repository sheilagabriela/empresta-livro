/*
 * An XML document type.
 * Localname: CadastrarClienteResponse
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.CadastrarClienteResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one CadastrarClienteResponse(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class CadastrarClienteResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarClienteResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public CadastrarClienteResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CADASTRARCLIENTERESPONSE$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "CadastrarClienteResponse");
    
    
    /**
     * Gets the "CadastrarClienteResponse" element
     */
    public org.tempuri.CadastrarClienteResponseDocument.CadastrarClienteResponse getCadastrarClienteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarClienteResponseDocument.CadastrarClienteResponse target = null;
            target = (org.tempuri.CadastrarClienteResponseDocument.CadastrarClienteResponse)get_store().find_element_user(CADASTRARCLIENTERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "CadastrarClienteResponse" element
     */
    public void setCadastrarClienteResponse(org.tempuri.CadastrarClienteResponseDocument.CadastrarClienteResponse cadastrarClienteResponse)
    {
        generatedSetterHelperImpl(cadastrarClienteResponse, CADASTRARCLIENTERESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CadastrarClienteResponse" element
     */
    public org.tempuri.CadastrarClienteResponseDocument.CadastrarClienteResponse addNewCadastrarClienteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarClienteResponseDocument.CadastrarClienteResponse target = null;
            target = (org.tempuri.CadastrarClienteResponseDocument.CadastrarClienteResponse)get_store().add_element_user(CADASTRARCLIENTERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML CadastrarClienteResponse(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class CadastrarClienteResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarClienteResponseDocument.CadastrarClienteResponse
    {
        private static final long serialVersionUID = 1L;
        
        public CadastrarClienteResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CADASTRARCLIENTERESULT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "CadastrarClienteResult");
        
        
        /**
         * Gets the "CadastrarClienteResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO getCadastrarClienteResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(CADASTRARCLIENTERESULT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "CadastrarClienteResult" element
         */
        public boolean isNilCadastrarClienteResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(CADASTRARCLIENTERESULT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "CadastrarClienteResult" element
         */
        public boolean isSetCadastrarClienteResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CADASTRARCLIENTERESULT$0) != 0;
            }
        }
        
        /**
         * Sets the "CadastrarClienteResult" element
         */
        public void setCadastrarClienteResult(org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO cadastrarClienteResult)
        {
            generatedSetterHelperImpl(cadastrarClienteResult, CADASTRARCLIENTERESULT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "CadastrarClienteResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO addNewCadastrarClienteResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().add_element_user(CADASTRARCLIENTERESULT$0);
                return target;
            }
        }
        
        /**
         * Nils the "CadastrarClienteResult" element
         */
        public void setNilCadastrarClienteResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(CADASTRARCLIENTERESULT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().add_element_user(CADASTRARCLIENTERESULT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "CadastrarClienteResult" element
         */
        public void unsetCadastrarClienteResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CADASTRARCLIENTERESULT$0, 0);
            }
        }
    }
}
