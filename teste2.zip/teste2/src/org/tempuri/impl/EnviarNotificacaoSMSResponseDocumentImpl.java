/*
 * An XML document type.
 * Localname: EnviarNotificacaoSMSResponse
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.EnviarNotificacaoSMSResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one EnviarNotificacaoSMSResponse(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class EnviarNotificacaoSMSResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.EnviarNotificacaoSMSResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public EnviarNotificacaoSMSResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ENVIARNOTIFICACAOSMSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "EnviarNotificacaoSMSResponse");
    
    
    /**
     * Gets the "EnviarNotificacaoSMSResponse" element
     */
    public org.tempuri.EnviarNotificacaoSMSResponseDocument.EnviarNotificacaoSMSResponse getEnviarNotificacaoSMSResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.EnviarNotificacaoSMSResponseDocument.EnviarNotificacaoSMSResponse target = null;
            target = (org.tempuri.EnviarNotificacaoSMSResponseDocument.EnviarNotificacaoSMSResponse)get_store().find_element_user(ENVIARNOTIFICACAOSMSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "EnviarNotificacaoSMSResponse" element
     */
    public void setEnviarNotificacaoSMSResponse(org.tempuri.EnviarNotificacaoSMSResponseDocument.EnviarNotificacaoSMSResponse enviarNotificacaoSMSResponse)
    {
        generatedSetterHelperImpl(enviarNotificacaoSMSResponse, ENVIARNOTIFICACAOSMSRESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "EnviarNotificacaoSMSResponse" element
     */
    public org.tempuri.EnviarNotificacaoSMSResponseDocument.EnviarNotificacaoSMSResponse addNewEnviarNotificacaoSMSResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.EnviarNotificacaoSMSResponseDocument.EnviarNotificacaoSMSResponse target = null;
            target = (org.tempuri.EnviarNotificacaoSMSResponseDocument.EnviarNotificacaoSMSResponse)get_store().add_element_user(ENVIARNOTIFICACAOSMSRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML EnviarNotificacaoSMSResponse(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class EnviarNotificacaoSMSResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.EnviarNotificacaoSMSResponseDocument.EnviarNotificacaoSMSResponse
    {
        private static final long serialVersionUID = 1L;
        
        public EnviarNotificacaoSMSResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ENVIARNOTIFICACAOSMSRESULT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "EnviarNotificacaoSMSResult");
        
        
        /**
         * Gets the "EnviarNotificacaoSMSResult" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO getEnviarNotificacaoSMSResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO)get_store().find_element_user(ENVIARNOTIFICACAOSMSRESULT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "EnviarNotificacaoSMSResult" element
         */
        public boolean isNilEnviarNotificacaoSMSResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO)get_store().find_element_user(ENVIARNOTIFICACAOSMSRESULT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "EnviarNotificacaoSMSResult" element
         */
        public boolean isSetEnviarNotificacaoSMSResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ENVIARNOTIFICACAOSMSRESULT$0) != 0;
            }
        }
        
        /**
         * Sets the "EnviarNotificacaoSMSResult" element
         */
        public void setEnviarNotificacaoSMSResult(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO enviarNotificacaoSMSResult)
        {
            generatedSetterHelperImpl(enviarNotificacaoSMSResult, ENVIARNOTIFICACAOSMSRESULT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "EnviarNotificacaoSMSResult" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO addNewEnviarNotificacaoSMSResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO)get_store().add_element_user(ENVIARNOTIFICACAOSMSRESULT$0);
                return target;
            }
        }
        
        /**
         * Nils the "EnviarNotificacaoSMSResult" element
         */
        public void setNilEnviarNotificacaoSMSResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO)get_store().find_element_user(ENVIARNOTIFICACAOSMSRESULT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO)get_store().add_element_user(ENVIARNOTIFICACAOSMSRESULT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "EnviarNotificacaoSMSResult" element
         */
        public void unsetEnviarNotificacaoSMSResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ENVIARNOTIFICACAOSMSRESULT$0, 0);
            }
        }
    }
}
