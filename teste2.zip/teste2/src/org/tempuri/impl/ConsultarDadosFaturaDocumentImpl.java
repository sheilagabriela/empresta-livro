/*
 * An XML document type.
 * Localname: ConsultarDadosFatura
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.ConsultarDadosFaturaDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one ConsultarDadosFatura(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class ConsultarDadosFaturaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultarDadosFaturaDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarDadosFaturaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTARDADOSFATURA$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "ConsultarDadosFatura");
    
    
    /**
     * Gets the "ConsultarDadosFatura" element
     */
    public org.tempuri.ConsultarDadosFaturaDocument.ConsultarDadosFatura getConsultarDadosFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultarDadosFaturaDocument.ConsultarDadosFatura target = null;
            target = (org.tempuri.ConsultarDadosFaturaDocument.ConsultarDadosFatura)get_store().find_element_user(CONSULTARDADOSFATURA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultarDadosFatura" element
     */
    public void setConsultarDadosFatura(org.tempuri.ConsultarDadosFaturaDocument.ConsultarDadosFatura consultarDadosFatura)
    {
        generatedSetterHelperImpl(consultarDadosFatura, CONSULTARDADOSFATURA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultarDadosFatura" element
     */
    public org.tempuri.ConsultarDadosFaturaDocument.ConsultarDadosFatura addNewConsultarDadosFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultarDadosFaturaDocument.ConsultarDadosFatura target = null;
            target = (org.tempuri.ConsultarDadosFaturaDocument.ConsultarDadosFatura)get_store().add_element_user(CONSULTARDADOSFATURA$0);
            return target;
        }
    }
    /**
     * An XML ConsultarDadosFatura(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class ConsultarDadosFaturaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultarDadosFaturaDocument.ConsultarDadosFatura
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultarDadosFaturaImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName INPUT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "input");
        
        
        /**
         * Gets the "input" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO getInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO)get_store().find_element_user(INPUT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "input" element
         */
        public boolean isNilInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO)get_store().find_element_user(INPUT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "input" element
         */
        public boolean isSetInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(INPUT$0) != 0;
            }
        }
        
        /**
         * Sets the "input" element
         */
        public void setInput(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO input)
        {
            generatedSetterHelperImpl(input, INPUT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "input" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO addNewInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO)get_store().add_element_user(INPUT$0);
                return target;
            }
        }
        
        /**
         * Nils the "input" element
         */
        public void setNilInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO)get_store().find_element_user(INPUT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO)get_store().add_element_user(INPUT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "input" element
         */
        public void unsetInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(INPUT$0, 0);
            }
        }
    }
}
