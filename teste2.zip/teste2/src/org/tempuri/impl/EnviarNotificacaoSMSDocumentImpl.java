/*
 * An XML document type.
 * Localname: EnviarNotificacaoSMS
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.EnviarNotificacaoSMSDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one EnviarNotificacaoSMS(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class EnviarNotificacaoSMSDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.EnviarNotificacaoSMSDocument
{
    private static final long serialVersionUID = 1L;
    
    public EnviarNotificacaoSMSDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ENVIARNOTIFICACAOSMS$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "EnviarNotificacaoSMS");
    
    
    /**
     * Gets the "EnviarNotificacaoSMS" element
     */
    public org.tempuri.EnviarNotificacaoSMSDocument.EnviarNotificacaoSMS getEnviarNotificacaoSMS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.EnviarNotificacaoSMSDocument.EnviarNotificacaoSMS target = null;
            target = (org.tempuri.EnviarNotificacaoSMSDocument.EnviarNotificacaoSMS)get_store().find_element_user(ENVIARNOTIFICACAOSMS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "EnviarNotificacaoSMS" element
     */
    public void setEnviarNotificacaoSMS(org.tempuri.EnviarNotificacaoSMSDocument.EnviarNotificacaoSMS enviarNotificacaoSMS)
    {
        generatedSetterHelperImpl(enviarNotificacaoSMS, ENVIARNOTIFICACAOSMS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "EnviarNotificacaoSMS" element
     */
    public org.tempuri.EnviarNotificacaoSMSDocument.EnviarNotificacaoSMS addNewEnviarNotificacaoSMS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.EnviarNotificacaoSMSDocument.EnviarNotificacaoSMS target = null;
            target = (org.tempuri.EnviarNotificacaoSMSDocument.EnviarNotificacaoSMS)get_store().add_element_user(ENVIARNOTIFICACAOSMS$0);
            return target;
        }
    }
    /**
     * An XML EnviarNotificacaoSMS(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class EnviarNotificacaoSMSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.EnviarNotificacaoSMSDocument.EnviarNotificacaoSMS
    {
        private static final long serialVersionUID = 1L;
        
        public EnviarNotificacaoSMSImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName INPUT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "input");
        
        
        /**
         * Gets the "input" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSInputDTO getInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSInputDTO)get_store().find_element_user(INPUT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "input" element
         */
        public boolean isNilInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSInputDTO)get_store().find_element_user(INPUT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "input" element
         */
        public boolean isSetInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(INPUT$0) != 0;
            }
        }
        
        /**
         * Sets the "input" element
         */
        public void setInput(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSInputDTO input)
        {
            generatedSetterHelperImpl(input, INPUT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "input" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSInputDTO addNewInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSInputDTO)get_store().add_element_user(INPUT$0);
                return target;
            }
        }
        
        /**
         * Nils the "input" element
         */
        public void setNilInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSInputDTO)get_store().find_element_user(INPUT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSInputDTO)get_store().add_element_user(INPUT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "input" element
         */
        public void unsetInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(INPUT$0, 0);
            }
        }
    }
}
