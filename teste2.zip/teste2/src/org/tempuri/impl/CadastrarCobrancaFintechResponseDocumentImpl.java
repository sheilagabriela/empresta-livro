/*
 * An XML document type.
 * Localname: CadastrarCobrancaFintechResponse
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.CadastrarCobrancaFintechResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one CadastrarCobrancaFintechResponse(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class CadastrarCobrancaFintechResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarCobrancaFintechResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public CadastrarCobrancaFintechResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CADASTRARCOBRANCAFINTECHRESPONSE$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "CadastrarCobrancaFintechResponse");
    
    
    /**
     * Gets the "CadastrarCobrancaFintechResponse" element
     */
    public org.tempuri.CadastrarCobrancaFintechResponseDocument.CadastrarCobrancaFintechResponse getCadastrarCobrancaFintechResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarCobrancaFintechResponseDocument.CadastrarCobrancaFintechResponse target = null;
            target = (org.tempuri.CadastrarCobrancaFintechResponseDocument.CadastrarCobrancaFintechResponse)get_store().find_element_user(CADASTRARCOBRANCAFINTECHRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "CadastrarCobrancaFintechResponse" element
     */
    public void setCadastrarCobrancaFintechResponse(org.tempuri.CadastrarCobrancaFintechResponseDocument.CadastrarCobrancaFintechResponse cadastrarCobrancaFintechResponse)
    {
        generatedSetterHelperImpl(cadastrarCobrancaFintechResponse, CADASTRARCOBRANCAFINTECHRESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CadastrarCobrancaFintechResponse" element
     */
    public org.tempuri.CadastrarCobrancaFintechResponseDocument.CadastrarCobrancaFintechResponse addNewCadastrarCobrancaFintechResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarCobrancaFintechResponseDocument.CadastrarCobrancaFintechResponse target = null;
            target = (org.tempuri.CadastrarCobrancaFintechResponseDocument.CadastrarCobrancaFintechResponse)get_store().add_element_user(CADASTRARCOBRANCAFINTECHRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML CadastrarCobrancaFintechResponse(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class CadastrarCobrancaFintechResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarCobrancaFintechResponseDocument.CadastrarCobrancaFintechResponse
    {
        private static final long serialVersionUID = 1L;
        
        public CadastrarCobrancaFintechResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CADASTRARCOBRANCAFINTECHRESULT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "CadastrarCobrancaFintechResult");
        
        
        /**
         * Gets the "CadastrarCobrancaFintechResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO getCadastrarCobrancaFintechResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(CADASTRARCOBRANCAFINTECHRESULT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "CadastrarCobrancaFintechResult" element
         */
        public boolean isNilCadastrarCobrancaFintechResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(CADASTRARCOBRANCAFINTECHRESULT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "CadastrarCobrancaFintechResult" element
         */
        public boolean isSetCadastrarCobrancaFintechResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CADASTRARCOBRANCAFINTECHRESULT$0) != 0;
            }
        }
        
        /**
         * Sets the "CadastrarCobrancaFintechResult" element
         */
        public void setCadastrarCobrancaFintechResult(org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO cadastrarCobrancaFintechResult)
        {
            generatedSetterHelperImpl(cadastrarCobrancaFintechResult, CADASTRARCOBRANCAFINTECHRESULT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "CadastrarCobrancaFintechResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO addNewCadastrarCobrancaFintechResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().add_element_user(CADASTRARCOBRANCAFINTECHRESULT$0);
                return target;
            }
        }
        
        /**
         * Nils the "CadastrarCobrancaFintechResult" element
         */
        public void setNilCadastrarCobrancaFintechResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(CADASTRARCOBRANCAFINTECHRESULT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().add_element_user(CADASTRARCOBRANCAFINTECHRESULT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "CadastrarCobrancaFintechResult" element
         */
        public void unsetCadastrarCobrancaFintechResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CADASTRARCOBRANCAFINTECHRESULT$0, 0);
            }
        }
    }
}
