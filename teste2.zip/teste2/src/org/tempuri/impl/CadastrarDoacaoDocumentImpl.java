/*
 * An XML document type.
 * Localname: CadastrarDoacao
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.CadastrarDoacaoDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one CadastrarDoacao(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class CadastrarDoacaoDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarDoacaoDocument
{
    private static final long serialVersionUID = 1L;
    
    public CadastrarDoacaoDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CADASTRARDOACAO$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "CadastrarDoacao");
    
    
    /**
     * Gets the "CadastrarDoacao" element
     */
    public org.tempuri.CadastrarDoacaoDocument.CadastrarDoacao getCadastrarDoacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarDoacaoDocument.CadastrarDoacao target = null;
            target = (org.tempuri.CadastrarDoacaoDocument.CadastrarDoacao)get_store().find_element_user(CADASTRARDOACAO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "CadastrarDoacao" element
     */
    public void setCadastrarDoacao(org.tempuri.CadastrarDoacaoDocument.CadastrarDoacao cadastrarDoacao)
    {
        generatedSetterHelperImpl(cadastrarDoacao, CADASTRARDOACAO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CadastrarDoacao" element
     */
    public org.tempuri.CadastrarDoacaoDocument.CadastrarDoacao addNewCadastrarDoacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarDoacaoDocument.CadastrarDoacao target = null;
            target = (org.tempuri.CadastrarDoacaoDocument.CadastrarDoacao)get_store().add_element_user(CADASTRARDOACAO$0);
            return target;
        }
    }
    /**
     * An XML CadastrarDoacao(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class CadastrarDoacaoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarDoacaoDocument.CadastrarDoacao
    {
        private static final long serialVersionUID = 1L;
        
        public CadastrarDoacaoImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName DOACAO$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "doacao");
        
        
        /**
         * Gets the "doacao" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO getDoacao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO)get_store().find_element_user(DOACAO$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "doacao" element
         */
        public boolean isNilDoacao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO)get_store().find_element_user(DOACAO$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "doacao" element
         */
        public boolean isSetDoacao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(DOACAO$0) != 0;
            }
        }
        
        /**
         * Sets the "doacao" element
         */
        public void setDoacao(org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO doacao)
        {
            generatedSetterHelperImpl(doacao, DOACAO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "doacao" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO addNewDoacao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO)get_store().add_element_user(DOACAO$0);
                return target;
            }
        }
        
        /**
         * Nils the "doacao" element
         */
        public void setNilDoacao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO)get_store().find_element_user(DOACAO$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO)get_store().add_element_user(DOACAO$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "doacao" element
         */
        public void unsetDoacao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(DOACAO$0, 0);
            }
        }
    }
}
