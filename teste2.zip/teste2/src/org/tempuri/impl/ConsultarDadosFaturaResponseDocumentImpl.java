/*
 * An XML document type.
 * Localname: ConsultarDadosFaturaResponse
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.ConsultarDadosFaturaResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one ConsultarDadosFaturaResponse(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class ConsultarDadosFaturaResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultarDadosFaturaResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarDadosFaturaResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTARDADOSFATURARESPONSE$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "ConsultarDadosFaturaResponse");
    
    
    /**
     * Gets the "ConsultarDadosFaturaResponse" element
     */
    public org.tempuri.ConsultarDadosFaturaResponseDocument.ConsultarDadosFaturaResponse getConsultarDadosFaturaResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultarDadosFaturaResponseDocument.ConsultarDadosFaturaResponse target = null;
            target = (org.tempuri.ConsultarDadosFaturaResponseDocument.ConsultarDadosFaturaResponse)get_store().find_element_user(CONSULTARDADOSFATURARESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultarDadosFaturaResponse" element
     */
    public void setConsultarDadosFaturaResponse(org.tempuri.ConsultarDadosFaturaResponseDocument.ConsultarDadosFaturaResponse consultarDadosFaturaResponse)
    {
        generatedSetterHelperImpl(consultarDadosFaturaResponse, CONSULTARDADOSFATURARESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultarDadosFaturaResponse" element
     */
    public org.tempuri.ConsultarDadosFaturaResponseDocument.ConsultarDadosFaturaResponse addNewConsultarDadosFaturaResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultarDadosFaturaResponseDocument.ConsultarDadosFaturaResponse target = null;
            target = (org.tempuri.ConsultarDadosFaturaResponseDocument.ConsultarDadosFaturaResponse)get_store().add_element_user(CONSULTARDADOSFATURARESPONSE$0);
            return target;
        }
    }
    /**
     * An XML ConsultarDadosFaturaResponse(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class ConsultarDadosFaturaResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultarDadosFaturaResponseDocument.ConsultarDadosFaturaResponse
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultarDadosFaturaResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CONSULTARDADOSFATURARESULT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "ConsultarDadosFaturaResult");
        
        
        /**
         * Gets the "ConsultarDadosFaturaResult" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaOutputDTO getConsultarDadosFaturaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaOutputDTO)get_store().find_element_user(CONSULTARDADOSFATURARESULT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "ConsultarDadosFaturaResult" element
         */
        public boolean isNilConsultarDadosFaturaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaOutputDTO)get_store().find_element_user(CONSULTARDADOSFATURARESULT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "ConsultarDadosFaturaResult" element
         */
        public boolean isSetConsultarDadosFaturaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CONSULTARDADOSFATURARESULT$0) != 0;
            }
        }
        
        /**
         * Sets the "ConsultarDadosFaturaResult" element
         */
        public void setConsultarDadosFaturaResult(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaOutputDTO consultarDadosFaturaResult)
        {
            generatedSetterHelperImpl(consultarDadosFaturaResult, CONSULTARDADOSFATURARESULT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ConsultarDadosFaturaResult" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaOutputDTO addNewConsultarDadosFaturaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaOutputDTO)get_store().add_element_user(CONSULTARDADOSFATURARESULT$0);
                return target;
            }
        }
        
        /**
         * Nils the "ConsultarDadosFaturaResult" element
         */
        public void setNilConsultarDadosFaturaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaOutputDTO)get_store().find_element_user(CONSULTARDADOSFATURARESULT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaOutputDTO)get_store().add_element_user(CONSULTARDADOSFATURARESULT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "ConsultarDadosFaturaResult" element
         */
        public void unsetConsultarDadosFaturaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CONSULTARDADOSFATURARESULT$0, 0);
            }
        }
    }
}
