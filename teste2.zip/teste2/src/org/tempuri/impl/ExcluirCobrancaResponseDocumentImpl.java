/*
 * An XML document type.
 * Localname: ExcluirCobrancaResponse
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.ExcluirCobrancaResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one ExcluirCobrancaResponse(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class ExcluirCobrancaResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ExcluirCobrancaResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public ExcluirCobrancaResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EXCLUIRCOBRANCARESPONSE$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "ExcluirCobrancaResponse");
    
    
    /**
     * Gets the "ExcluirCobrancaResponse" element
     */
    public org.tempuri.ExcluirCobrancaResponseDocument.ExcluirCobrancaResponse getExcluirCobrancaResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ExcluirCobrancaResponseDocument.ExcluirCobrancaResponse target = null;
            target = (org.tempuri.ExcluirCobrancaResponseDocument.ExcluirCobrancaResponse)get_store().find_element_user(EXCLUIRCOBRANCARESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ExcluirCobrancaResponse" element
     */
    public void setExcluirCobrancaResponse(org.tempuri.ExcluirCobrancaResponseDocument.ExcluirCobrancaResponse excluirCobrancaResponse)
    {
        generatedSetterHelperImpl(excluirCobrancaResponse, EXCLUIRCOBRANCARESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ExcluirCobrancaResponse" element
     */
    public org.tempuri.ExcluirCobrancaResponseDocument.ExcluirCobrancaResponse addNewExcluirCobrancaResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ExcluirCobrancaResponseDocument.ExcluirCobrancaResponse target = null;
            target = (org.tempuri.ExcluirCobrancaResponseDocument.ExcluirCobrancaResponse)get_store().add_element_user(EXCLUIRCOBRANCARESPONSE$0);
            return target;
        }
    }
    /**
     * An XML ExcluirCobrancaResponse(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class ExcluirCobrancaResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ExcluirCobrancaResponseDocument.ExcluirCobrancaResponse
    {
        private static final long serialVersionUID = 1L;
        
        public ExcluirCobrancaResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName EXCLUIRCOBRANCARESULT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "ExcluirCobrancaResult");
        
        
        /**
         * Gets the "ExcluirCobrancaResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO getExcluirCobrancaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(EXCLUIRCOBRANCARESULT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "ExcluirCobrancaResult" element
         */
        public boolean isNilExcluirCobrancaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(EXCLUIRCOBRANCARESULT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "ExcluirCobrancaResult" element
         */
        public boolean isSetExcluirCobrancaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(EXCLUIRCOBRANCARESULT$0) != 0;
            }
        }
        
        /**
         * Sets the "ExcluirCobrancaResult" element
         */
        public void setExcluirCobrancaResult(org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO excluirCobrancaResult)
        {
            generatedSetterHelperImpl(excluirCobrancaResult, EXCLUIRCOBRANCARESULT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ExcluirCobrancaResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO addNewExcluirCobrancaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().add_element_user(EXCLUIRCOBRANCARESULT$0);
                return target;
            }
        }
        
        /**
         * Nils the "ExcluirCobrancaResult" element
         */
        public void setNilExcluirCobrancaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(EXCLUIRCOBRANCARESULT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().add_element_user(EXCLUIRCOBRANCARESULT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "ExcluirCobrancaResult" element
         */
        public void unsetExcluirCobrancaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(EXCLUIRCOBRANCARESULT$0, 0);
            }
        }
    }
}
