/*
 * An XML document type.
 * Localname: CadastrarDoacaoResponse
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.CadastrarDoacaoResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one CadastrarDoacaoResponse(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class CadastrarDoacaoResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarDoacaoResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public CadastrarDoacaoResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CADASTRARDOACAORESPONSE$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "CadastrarDoacaoResponse");
    
    
    /**
     * Gets the "CadastrarDoacaoResponse" element
     */
    public org.tempuri.CadastrarDoacaoResponseDocument.CadastrarDoacaoResponse getCadastrarDoacaoResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarDoacaoResponseDocument.CadastrarDoacaoResponse target = null;
            target = (org.tempuri.CadastrarDoacaoResponseDocument.CadastrarDoacaoResponse)get_store().find_element_user(CADASTRARDOACAORESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "CadastrarDoacaoResponse" element
     */
    public void setCadastrarDoacaoResponse(org.tempuri.CadastrarDoacaoResponseDocument.CadastrarDoacaoResponse cadastrarDoacaoResponse)
    {
        generatedSetterHelperImpl(cadastrarDoacaoResponse, CADASTRARDOACAORESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CadastrarDoacaoResponse" element
     */
    public org.tempuri.CadastrarDoacaoResponseDocument.CadastrarDoacaoResponse addNewCadastrarDoacaoResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarDoacaoResponseDocument.CadastrarDoacaoResponse target = null;
            target = (org.tempuri.CadastrarDoacaoResponseDocument.CadastrarDoacaoResponse)get_store().add_element_user(CADASTRARDOACAORESPONSE$0);
            return target;
        }
    }
    /**
     * An XML CadastrarDoacaoResponse(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class CadastrarDoacaoResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarDoacaoResponseDocument.CadastrarDoacaoResponse
    {
        private static final long serialVersionUID = 1L;
        
        public CadastrarDoacaoResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CADASTRARDOACAORESULT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "CadastrarDoacaoResult");
        
        
        /**
         * Gets the "CadastrarDoacaoResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO getCadastrarDoacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO)get_store().find_element_user(CADASTRARDOACAORESULT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "CadastrarDoacaoResult" element
         */
        public boolean isNilCadastrarDoacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO)get_store().find_element_user(CADASTRARDOACAORESULT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "CadastrarDoacaoResult" element
         */
        public boolean isSetCadastrarDoacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CADASTRARDOACAORESULT$0) != 0;
            }
        }
        
        /**
         * Sets the "CadastrarDoacaoResult" element
         */
        public void setCadastrarDoacaoResult(org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO cadastrarDoacaoResult)
        {
            generatedSetterHelperImpl(cadastrarDoacaoResult, CADASTRARDOACAORESULT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "CadastrarDoacaoResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO addNewCadastrarDoacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO)get_store().add_element_user(CADASTRARDOACAORESULT$0);
                return target;
            }
        }
        
        /**
         * Nils the "CadastrarDoacaoResult" element
         */
        public void setNilCadastrarDoacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO)get_store().find_element_user(CADASTRARDOACAORESULT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO)get_store().add_element_user(CADASTRARDOACAORESULT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "CadastrarDoacaoResult" element
         */
        public void unsetCadastrarDoacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CADASTRARDOACAORESULT$0, 0);
            }
        }
    }
}
