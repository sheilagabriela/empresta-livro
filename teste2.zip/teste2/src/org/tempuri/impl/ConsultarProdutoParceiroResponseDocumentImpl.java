/*
 * An XML document type.
 * Localname: ConsultarProdutoParceiroResponse
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.ConsultarProdutoParceiroResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one ConsultarProdutoParceiroResponse(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class ConsultarProdutoParceiroResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultarProdutoParceiroResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarProdutoParceiroResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTARPRODUTOPARCEIRORESPONSE$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "ConsultarProdutoParceiroResponse");
    
    
    /**
     * Gets the "ConsultarProdutoParceiroResponse" element
     */
    public org.tempuri.ConsultarProdutoParceiroResponseDocument.ConsultarProdutoParceiroResponse getConsultarProdutoParceiroResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultarProdutoParceiroResponseDocument.ConsultarProdutoParceiroResponse target = null;
            target = (org.tempuri.ConsultarProdutoParceiroResponseDocument.ConsultarProdutoParceiroResponse)get_store().find_element_user(CONSULTARPRODUTOPARCEIRORESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultarProdutoParceiroResponse" element
     */
    public void setConsultarProdutoParceiroResponse(org.tempuri.ConsultarProdutoParceiroResponseDocument.ConsultarProdutoParceiroResponse consultarProdutoParceiroResponse)
    {
        generatedSetterHelperImpl(consultarProdutoParceiroResponse, CONSULTARPRODUTOPARCEIRORESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultarProdutoParceiroResponse" element
     */
    public org.tempuri.ConsultarProdutoParceiroResponseDocument.ConsultarProdutoParceiroResponse addNewConsultarProdutoParceiroResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultarProdutoParceiroResponseDocument.ConsultarProdutoParceiroResponse target = null;
            target = (org.tempuri.ConsultarProdutoParceiroResponseDocument.ConsultarProdutoParceiroResponse)get_store().add_element_user(CONSULTARPRODUTOPARCEIRORESPONSE$0);
            return target;
        }
    }
    /**
     * An XML ConsultarProdutoParceiroResponse(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class ConsultarProdutoParceiroResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultarProdutoParceiroResponseDocument.ConsultarProdutoParceiroResponse
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultarProdutoParceiroResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CONSULTARPRODUTOPARCEIRORESULT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "ConsultarProdutoParceiroResult");
        
        
        /**
         * Gets the "ConsultarProdutoParceiroResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ProdutosDTO getConsultarProdutoParceiroResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ProdutosDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutosDTO)get_store().find_element_user(CONSULTARPRODUTOPARCEIRORESULT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "ConsultarProdutoParceiroResult" element
         */
        public boolean isNilConsultarProdutoParceiroResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ProdutosDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutosDTO)get_store().find_element_user(CONSULTARPRODUTOPARCEIRORESULT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "ConsultarProdutoParceiroResult" element
         */
        public boolean isSetConsultarProdutoParceiroResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CONSULTARPRODUTOPARCEIRORESULT$0) != 0;
            }
        }
        
        /**
         * Sets the "ConsultarProdutoParceiroResult" element
         */
        public void setConsultarProdutoParceiroResult(org.datacontract.schemas._2004._07.model_webservicesdto.ProdutosDTO consultarProdutoParceiroResult)
        {
            generatedSetterHelperImpl(consultarProdutoParceiroResult, CONSULTARPRODUTOPARCEIRORESULT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ConsultarProdutoParceiroResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ProdutosDTO addNewConsultarProdutoParceiroResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ProdutosDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutosDTO)get_store().add_element_user(CONSULTARPRODUTOPARCEIRORESULT$0);
                return target;
            }
        }
        
        /**
         * Nils the "ConsultarProdutoParceiroResult" element
         */
        public void setNilConsultarProdutoParceiroResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ProdutosDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutosDTO)get_store().find_element_user(CONSULTARPRODUTOPARCEIRORESULT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutosDTO)get_store().add_element_user(CONSULTARPRODUTOPARCEIRORESULT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "ConsultarProdutoParceiroResult" element
         */
        public void unsetConsultarProdutoParceiroResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CONSULTARPRODUTOPARCEIRORESULT$0, 0);
            }
        }
    }
}
