/*
 * An XML document type.
 * Localname: CadastrarCobrancaFintech
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.CadastrarCobrancaFintechDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one CadastrarCobrancaFintech(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class CadastrarCobrancaFintechDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarCobrancaFintechDocument
{
    private static final long serialVersionUID = 1L;
    
    public CadastrarCobrancaFintechDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CADASTRARCOBRANCAFINTECH$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "CadastrarCobrancaFintech");
    
    
    /**
     * Gets the "CadastrarCobrancaFintech" element
     */
    public org.tempuri.CadastrarCobrancaFintechDocument.CadastrarCobrancaFintech getCadastrarCobrancaFintech()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarCobrancaFintechDocument.CadastrarCobrancaFintech target = null;
            target = (org.tempuri.CadastrarCobrancaFintechDocument.CadastrarCobrancaFintech)get_store().find_element_user(CADASTRARCOBRANCAFINTECH$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "CadastrarCobrancaFintech" element
     */
    public void setCadastrarCobrancaFintech(org.tempuri.CadastrarCobrancaFintechDocument.CadastrarCobrancaFintech cadastrarCobrancaFintech)
    {
        generatedSetterHelperImpl(cadastrarCobrancaFintech, CADASTRARCOBRANCAFINTECH$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CadastrarCobrancaFintech" element
     */
    public org.tempuri.CadastrarCobrancaFintechDocument.CadastrarCobrancaFintech addNewCadastrarCobrancaFintech()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarCobrancaFintechDocument.CadastrarCobrancaFintech target = null;
            target = (org.tempuri.CadastrarCobrancaFintechDocument.CadastrarCobrancaFintech)get_store().add_element_user(CADASTRARCOBRANCAFINTECH$0);
            return target;
        }
    }
    /**
     * An XML CadastrarCobrancaFintech(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class CadastrarCobrancaFintechImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarCobrancaFintechDocument.CadastrarCobrancaFintech
    {
        private static final long serialVersionUID = 1L;
        
        public CadastrarCobrancaFintechImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName COBRANCA$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "cobranca");
        
        
        /**
         * Gets the "cobranca" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO getCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO)get_store().find_element_user(COBRANCA$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "cobranca" element
         */
        public boolean isNilCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO)get_store().find_element_user(COBRANCA$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "cobranca" element
         */
        public boolean isSetCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(COBRANCA$0) != 0;
            }
        }
        
        /**
         * Sets the "cobranca" element
         */
        public void setCobranca(org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO cobranca)
        {
            generatedSetterHelperImpl(cobranca, COBRANCA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "cobranca" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO addNewCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO)get_store().add_element_user(COBRANCA$0);
                return target;
            }
        }
        
        /**
         * Nils the "cobranca" element
         */
        public void setNilCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO)get_store().find_element_user(COBRANCA$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO)get_store().add_element_user(COBRANCA$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "cobranca" element
         */
        public void unsetCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(COBRANCA$0, 0);
            }
        }
    }
}
