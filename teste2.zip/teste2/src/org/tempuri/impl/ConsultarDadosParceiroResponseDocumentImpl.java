/*
 * An XML document type.
 * Localname: ConsultarDadosParceiroResponse
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.ConsultarDadosParceiroResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one ConsultarDadosParceiroResponse(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class ConsultarDadosParceiroResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultarDadosParceiroResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarDadosParceiroResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTARDADOSPARCEIRORESPONSE$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "ConsultarDadosParceiroResponse");
    
    
    /**
     * Gets the "ConsultarDadosParceiroResponse" element
     */
    public org.tempuri.ConsultarDadosParceiroResponseDocument.ConsultarDadosParceiroResponse getConsultarDadosParceiroResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultarDadosParceiroResponseDocument.ConsultarDadosParceiroResponse target = null;
            target = (org.tempuri.ConsultarDadosParceiroResponseDocument.ConsultarDadosParceiroResponse)get_store().find_element_user(CONSULTARDADOSPARCEIRORESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultarDadosParceiroResponse" element
     */
    public void setConsultarDadosParceiroResponse(org.tempuri.ConsultarDadosParceiroResponseDocument.ConsultarDadosParceiroResponse consultarDadosParceiroResponse)
    {
        generatedSetterHelperImpl(consultarDadosParceiroResponse, CONSULTARDADOSPARCEIRORESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultarDadosParceiroResponse" element
     */
    public org.tempuri.ConsultarDadosParceiroResponseDocument.ConsultarDadosParceiroResponse addNewConsultarDadosParceiroResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultarDadosParceiroResponseDocument.ConsultarDadosParceiroResponse target = null;
            target = (org.tempuri.ConsultarDadosParceiroResponseDocument.ConsultarDadosParceiroResponse)get_store().add_element_user(CONSULTARDADOSPARCEIRORESPONSE$0);
            return target;
        }
    }
    /**
     * An XML ConsultarDadosParceiroResponse(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class ConsultarDadosParceiroResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultarDadosParceiroResponseDocument.ConsultarDadosParceiroResponse
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultarDadosParceiroResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CONSULTARDADOSPARCEIRORESULT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "ConsultarDadosParceiroResult");
        
        
        /**
         * Gets the "ConsultarDadosParceiroResult" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO getConsultarDadosParceiroResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO)get_store().find_element_user(CONSULTARDADOSPARCEIRORESULT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "ConsultarDadosParceiroResult" element
         */
        public boolean isNilConsultarDadosParceiroResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO)get_store().find_element_user(CONSULTARDADOSPARCEIRORESULT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "ConsultarDadosParceiroResult" element
         */
        public boolean isSetConsultarDadosParceiroResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CONSULTARDADOSPARCEIRORESULT$0) != 0;
            }
        }
        
        /**
         * Sets the "ConsultarDadosParceiroResult" element
         */
        public void setConsultarDadosParceiroResult(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO consultarDadosParceiroResult)
        {
            generatedSetterHelperImpl(consultarDadosParceiroResult, CONSULTARDADOSPARCEIRORESULT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ConsultarDadosParceiroResult" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO addNewConsultarDadosParceiroResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO)get_store().add_element_user(CONSULTARDADOSPARCEIRORESULT$0);
                return target;
            }
        }
        
        /**
         * Nils the "ConsultarDadosParceiroResult" element
         */
        public void setNilConsultarDadosParceiroResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO)get_store().find_element_user(CONSULTARDADOSPARCEIRORESULT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO)get_store().add_element_user(CONSULTARDADOSPARCEIRORESULT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "ConsultarDadosParceiroResult" element
         */
        public void unsetConsultarDadosParceiroResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CONSULTARDADOSPARCEIRORESULT$0, 0);
            }
        }
    }
}
