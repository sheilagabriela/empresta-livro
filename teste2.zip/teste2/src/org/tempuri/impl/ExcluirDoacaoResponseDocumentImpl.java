/*
 * An XML document type.
 * Localname: ExcluirDoacaoResponse
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.ExcluirDoacaoResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one ExcluirDoacaoResponse(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class ExcluirDoacaoResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ExcluirDoacaoResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public ExcluirDoacaoResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EXCLUIRDOACAORESPONSE$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "ExcluirDoacaoResponse");
    
    
    /**
     * Gets the "ExcluirDoacaoResponse" element
     */
    public org.tempuri.ExcluirDoacaoResponseDocument.ExcluirDoacaoResponse getExcluirDoacaoResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ExcluirDoacaoResponseDocument.ExcluirDoacaoResponse target = null;
            target = (org.tempuri.ExcluirDoacaoResponseDocument.ExcluirDoacaoResponse)get_store().find_element_user(EXCLUIRDOACAORESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ExcluirDoacaoResponse" element
     */
    public void setExcluirDoacaoResponse(org.tempuri.ExcluirDoacaoResponseDocument.ExcluirDoacaoResponse excluirDoacaoResponse)
    {
        generatedSetterHelperImpl(excluirDoacaoResponse, EXCLUIRDOACAORESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ExcluirDoacaoResponse" element
     */
    public org.tempuri.ExcluirDoacaoResponseDocument.ExcluirDoacaoResponse addNewExcluirDoacaoResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ExcluirDoacaoResponseDocument.ExcluirDoacaoResponse target = null;
            target = (org.tempuri.ExcluirDoacaoResponseDocument.ExcluirDoacaoResponse)get_store().add_element_user(EXCLUIRDOACAORESPONSE$0);
            return target;
        }
    }
    /**
     * An XML ExcluirDoacaoResponse(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class ExcluirDoacaoResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ExcluirDoacaoResponseDocument.ExcluirDoacaoResponse
    {
        private static final long serialVersionUID = 1L;
        
        public ExcluirDoacaoResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName EXCLUIRDOACAORESULT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "ExcluirDoacaoResult");
        
        
        /**
         * Gets the "ExcluirDoacaoResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO getExcluirDoacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(EXCLUIRDOACAORESULT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "ExcluirDoacaoResult" element
         */
        public boolean isNilExcluirDoacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(EXCLUIRDOACAORESULT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "ExcluirDoacaoResult" element
         */
        public boolean isSetExcluirDoacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(EXCLUIRDOACAORESULT$0) != 0;
            }
        }
        
        /**
         * Sets the "ExcluirDoacaoResult" element
         */
        public void setExcluirDoacaoResult(org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO excluirDoacaoResult)
        {
            generatedSetterHelperImpl(excluirDoacaoResult, EXCLUIRDOACAORESULT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ExcluirDoacaoResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO addNewExcluirDoacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().add_element_user(EXCLUIRDOACAORESULT$0);
                return target;
            }
        }
        
        /**
         * Nils the "ExcluirDoacaoResult" element
         */
        public void setNilExcluirDoacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(EXCLUIRDOACAORESULT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().add_element_user(EXCLUIRDOACAORESULT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "ExcluirDoacaoResult" element
         */
        public void unsetExcluirDoacaoResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(EXCLUIRDOACAORESULT$0, 0);
            }
        }
    }
}
