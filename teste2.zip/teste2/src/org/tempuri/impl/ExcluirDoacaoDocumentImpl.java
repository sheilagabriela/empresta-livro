/*
 * An XML document type.
 * Localname: ExcluirDoacao
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.ExcluirDoacaoDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one ExcluirDoacao(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class ExcluirDoacaoDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ExcluirDoacaoDocument
{
    private static final long serialVersionUID = 1L;
    
    public ExcluirDoacaoDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EXCLUIRDOACAO$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "ExcluirDoacao");
    
    
    /**
     * Gets the "ExcluirDoacao" element
     */
    public org.tempuri.ExcluirDoacaoDocument.ExcluirDoacao getExcluirDoacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ExcluirDoacaoDocument.ExcluirDoacao target = null;
            target = (org.tempuri.ExcluirDoacaoDocument.ExcluirDoacao)get_store().find_element_user(EXCLUIRDOACAO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ExcluirDoacao" element
     */
    public void setExcluirDoacao(org.tempuri.ExcluirDoacaoDocument.ExcluirDoacao excluirDoacao)
    {
        generatedSetterHelperImpl(excluirDoacao, EXCLUIRDOACAO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ExcluirDoacao" element
     */
    public org.tempuri.ExcluirDoacaoDocument.ExcluirDoacao addNewExcluirDoacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ExcluirDoacaoDocument.ExcluirDoacao target = null;
            target = (org.tempuri.ExcluirDoacaoDocument.ExcluirDoacao)get_store().add_element_user(EXCLUIRDOACAO$0);
            return target;
        }
    }
    /**
     * An XML ExcluirDoacao(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class ExcluirDoacaoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ExcluirDoacaoDocument.ExcluirDoacao
    {
        private static final long serialVersionUID = 1L;
        
        public ExcluirDoacaoImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName COBRANCA$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "cobranca");
        
        
        /**
         * Gets the "cobranca" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO getCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO)get_store().find_element_user(COBRANCA$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "cobranca" element
         */
        public boolean isNilCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO)get_store().find_element_user(COBRANCA$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "cobranca" element
         */
        public boolean isSetCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(COBRANCA$0) != 0;
            }
        }
        
        /**
         * Sets the "cobranca" element
         */
        public void setCobranca(org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO cobranca)
        {
            generatedSetterHelperImpl(cobranca, COBRANCA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "cobranca" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO addNewCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO)get_store().add_element_user(COBRANCA$0);
                return target;
            }
        }
        
        /**
         * Nils the "cobranca" element
         */
        public void setNilCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO)get_store().find_element_user(COBRANCA$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO)get_store().add_element_user(COBRANCA$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "cobranca" element
         */
        public void unsetCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(COBRANCA$0, 0);
            }
        }
    }
}
