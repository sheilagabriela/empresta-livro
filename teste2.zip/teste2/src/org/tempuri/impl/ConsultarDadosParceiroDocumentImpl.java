/*
 * An XML document type.
 * Localname: ConsultarDadosParceiro
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.ConsultarDadosParceiroDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one ConsultarDadosParceiro(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class ConsultarDadosParceiroDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultarDadosParceiroDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarDadosParceiroDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTARDADOSPARCEIRO$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "ConsultarDadosParceiro");
    
    
    /**
     * Gets the "ConsultarDadosParceiro" element
     */
    public org.tempuri.ConsultarDadosParceiroDocument.ConsultarDadosParceiro getConsultarDadosParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultarDadosParceiroDocument.ConsultarDadosParceiro target = null;
            target = (org.tempuri.ConsultarDadosParceiroDocument.ConsultarDadosParceiro)get_store().find_element_user(CONSULTARDADOSPARCEIRO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultarDadosParceiro" element
     */
    public void setConsultarDadosParceiro(org.tempuri.ConsultarDadosParceiroDocument.ConsultarDadosParceiro consultarDadosParceiro)
    {
        generatedSetterHelperImpl(consultarDadosParceiro, CONSULTARDADOSPARCEIRO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultarDadosParceiro" element
     */
    public org.tempuri.ConsultarDadosParceiroDocument.ConsultarDadosParceiro addNewConsultarDadosParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultarDadosParceiroDocument.ConsultarDadosParceiro target = null;
            target = (org.tempuri.ConsultarDadosParceiroDocument.ConsultarDadosParceiro)get_store().add_element_user(CONSULTARDADOSPARCEIRO$0);
            return target;
        }
    }
    /**
     * An XML ConsultarDadosParceiro(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class ConsultarDadosParceiroImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultarDadosParceiroDocument.ConsultarDadosParceiro
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultarDadosParceiroImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName INPUT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "input");
        
        
        /**
         * Gets the "input" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroInputDTO getInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroInputDTO)get_store().find_element_user(INPUT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "input" element
         */
        public boolean isNilInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroInputDTO)get_store().find_element_user(INPUT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "input" element
         */
        public boolean isSetInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(INPUT$0) != 0;
            }
        }
        
        /**
         * Sets the "input" element
         */
        public void setInput(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroInputDTO input)
        {
            generatedSetterHelperImpl(input, INPUT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "input" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroInputDTO addNewInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroInputDTO)get_store().add_element_user(INPUT$0);
                return target;
            }
        }
        
        /**
         * Nils the "input" element
         */
        public void setNilInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroInputDTO)get_store().find_element_user(INPUT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroInputDTO)get_store().add_element_user(INPUT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "input" element
         */
        public void unsetInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(INPUT$0, 0);
            }
        }
    }
}
