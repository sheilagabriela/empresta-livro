/*
 * An XML document type.
 * Localname: ValidarConsultaResponse
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.ValidarConsultaResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one ValidarConsultaResponse(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class ValidarConsultaResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ValidarConsultaResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public ValidarConsultaResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VALIDARCONSULTARESPONSE$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "ValidarConsultaResponse");
    
    
    /**
     * Gets the "ValidarConsultaResponse" element
     */
    public org.tempuri.ValidarConsultaResponseDocument.ValidarConsultaResponse getValidarConsultaResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ValidarConsultaResponseDocument.ValidarConsultaResponse target = null;
            target = (org.tempuri.ValidarConsultaResponseDocument.ValidarConsultaResponse)get_store().find_element_user(VALIDARCONSULTARESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ValidarConsultaResponse" element
     */
    public void setValidarConsultaResponse(org.tempuri.ValidarConsultaResponseDocument.ValidarConsultaResponse validarConsultaResponse)
    {
        generatedSetterHelperImpl(validarConsultaResponse, VALIDARCONSULTARESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ValidarConsultaResponse" element
     */
    public org.tempuri.ValidarConsultaResponseDocument.ValidarConsultaResponse addNewValidarConsultaResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ValidarConsultaResponseDocument.ValidarConsultaResponse target = null;
            target = (org.tempuri.ValidarConsultaResponseDocument.ValidarConsultaResponse)get_store().add_element_user(VALIDARCONSULTARESPONSE$0);
            return target;
        }
    }
    /**
     * An XML ValidarConsultaResponse(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class ValidarConsultaResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ValidarConsultaResponseDocument.ValidarConsultaResponse
    {
        private static final long serialVersionUID = 1L;
        
        public ValidarConsultaResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName VALIDARCONSULTARESULT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "ValidarConsultaResult");
        
        
        /**
         * Gets the "ValidarConsultaResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO getValidarConsultaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO)get_store().find_element_user(VALIDARCONSULTARESULT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "ValidarConsultaResult" element
         */
        public boolean isNilValidarConsultaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO)get_store().find_element_user(VALIDARCONSULTARESULT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "ValidarConsultaResult" element
         */
        public boolean isSetValidarConsultaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(VALIDARCONSULTARESULT$0) != 0;
            }
        }
        
        /**
         * Sets the "ValidarConsultaResult" element
         */
        public void setValidarConsultaResult(org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO validarConsultaResult)
        {
            generatedSetterHelperImpl(validarConsultaResult, VALIDARCONSULTARESULT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ValidarConsultaResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO addNewValidarConsultaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO)get_store().add_element_user(VALIDARCONSULTARESULT$0);
                return target;
            }
        }
        
        /**
         * Nils the "ValidarConsultaResult" element
         */
        public void setNilValidarConsultaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO)get_store().find_element_user(VALIDARCONSULTARESULT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO)get_store().add_element_user(VALIDARCONSULTARESULT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "ValidarConsultaResult" element
         */
        public void unsetValidarConsultaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(VALIDARCONSULTARESULT$0, 0);
            }
        }
    }
}
