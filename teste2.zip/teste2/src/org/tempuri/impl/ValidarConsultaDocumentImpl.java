/*
 * An XML document type.
 * Localname: ValidarConsulta
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.ValidarConsultaDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one ValidarConsulta(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class ValidarConsultaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ValidarConsultaDocument
{
    private static final long serialVersionUID = 1L;
    
    public ValidarConsultaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VALIDARCONSULTA$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "ValidarConsulta");
    
    
    /**
     * Gets the "ValidarConsulta" element
     */
    public org.tempuri.ValidarConsultaDocument.ValidarConsulta getValidarConsulta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ValidarConsultaDocument.ValidarConsulta target = null;
            target = (org.tempuri.ValidarConsultaDocument.ValidarConsulta)get_store().find_element_user(VALIDARCONSULTA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ValidarConsulta" element
     */
    public void setValidarConsulta(org.tempuri.ValidarConsultaDocument.ValidarConsulta validarConsulta)
    {
        generatedSetterHelperImpl(validarConsulta, VALIDARCONSULTA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ValidarConsulta" element
     */
    public org.tempuri.ValidarConsultaDocument.ValidarConsulta addNewValidarConsulta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ValidarConsultaDocument.ValidarConsulta target = null;
            target = (org.tempuri.ValidarConsultaDocument.ValidarConsulta)get_store().add_element_user(VALIDARCONSULTA$0);
            return target;
        }
    }
    /**
     * An XML ValidarConsulta(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class ValidarConsultaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ValidarConsultaDocument.ValidarConsulta
    {
        private static final long serialVersionUID = 1L;
        
        public ValidarConsultaImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName DATA$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "data");
        
        
        /**
         * Gets the "data" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO getData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO)get_store().find_element_user(DATA$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "data" element
         */
        public boolean isNilData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO)get_store().find_element_user(DATA$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "data" element
         */
        public boolean isSetData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(DATA$0) != 0;
            }
        }
        
        /**
         * Sets the "data" element
         */
        public void setData(org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO data)
        {
            generatedSetterHelperImpl(data, DATA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "data" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO addNewData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO)get_store().add_element_user(DATA$0);
                return target;
            }
        }
        
        /**
         * Nils the "data" element
         */
        public void setNilData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO)get_store().find_element_user(DATA$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO)get_store().add_element_user(DATA$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "data" element
         */
        public void unsetData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(DATA$0, 0);
            }
        }
    }
}
