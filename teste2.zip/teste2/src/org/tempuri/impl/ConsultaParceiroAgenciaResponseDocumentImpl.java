/*
 * An XML document type.
 * Localname: ConsultaParceiroAgenciaResponse
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.ConsultaParceiroAgenciaResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one ConsultaParceiroAgenciaResponse(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class ConsultaParceiroAgenciaResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultaParceiroAgenciaResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultaParceiroAgenciaResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTAPARCEIROAGENCIARESPONSE$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "ConsultaParceiroAgenciaResponse");
    
    
    /**
     * Gets the "ConsultaParceiroAgenciaResponse" element
     */
    public org.tempuri.ConsultaParceiroAgenciaResponseDocument.ConsultaParceiroAgenciaResponse getConsultaParceiroAgenciaResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultaParceiroAgenciaResponseDocument.ConsultaParceiroAgenciaResponse target = null;
            target = (org.tempuri.ConsultaParceiroAgenciaResponseDocument.ConsultaParceiroAgenciaResponse)get_store().find_element_user(CONSULTAPARCEIROAGENCIARESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultaParceiroAgenciaResponse" element
     */
    public void setConsultaParceiroAgenciaResponse(org.tempuri.ConsultaParceiroAgenciaResponseDocument.ConsultaParceiroAgenciaResponse consultaParceiroAgenciaResponse)
    {
        generatedSetterHelperImpl(consultaParceiroAgenciaResponse, CONSULTAPARCEIROAGENCIARESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultaParceiroAgenciaResponse" element
     */
    public org.tempuri.ConsultaParceiroAgenciaResponseDocument.ConsultaParceiroAgenciaResponse addNewConsultaParceiroAgenciaResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultaParceiroAgenciaResponseDocument.ConsultaParceiroAgenciaResponse target = null;
            target = (org.tempuri.ConsultaParceiroAgenciaResponseDocument.ConsultaParceiroAgenciaResponse)get_store().add_element_user(CONSULTAPARCEIROAGENCIARESPONSE$0);
            return target;
        }
    }
    /**
     * An XML ConsultaParceiroAgenciaResponse(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class ConsultaParceiroAgenciaResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultaParceiroAgenciaResponseDocument.ConsultaParceiroAgenciaResponse
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultaParceiroAgenciaResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CONSULTAPARCEIROAGENCIARESULT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "ConsultaParceiroAgenciaResult");
        
        
        /**
         * Gets the "ConsultaParceiroAgenciaResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO getConsultaParceiroAgenciaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO)get_store().find_element_user(CONSULTAPARCEIROAGENCIARESULT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "ConsultaParceiroAgenciaResult" element
         */
        public boolean isNilConsultaParceiroAgenciaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO)get_store().find_element_user(CONSULTAPARCEIROAGENCIARESULT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "ConsultaParceiroAgenciaResult" element
         */
        public boolean isSetConsultaParceiroAgenciaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CONSULTAPARCEIROAGENCIARESULT$0) != 0;
            }
        }
        
        /**
         * Sets the "ConsultaParceiroAgenciaResult" element
         */
        public void setConsultaParceiroAgenciaResult(org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO consultaParceiroAgenciaResult)
        {
            generatedSetterHelperImpl(consultaParceiroAgenciaResult, CONSULTAPARCEIROAGENCIARESULT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ConsultaParceiroAgenciaResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO addNewConsultaParceiroAgenciaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO)get_store().add_element_user(CONSULTAPARCEIROAGENCIARESULT$0);
                return target;
            }
        }
        
        /**
         * Nils the "ConsultaParceiroAgenciaResult" element
         */
        public void setNilConsultaParceiroAgenciaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO)get_store().find_element_user(CONSULTAPARCEIROAGENCIARESULT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO)get_store().add_element_user(CONSULTAPARCEIROAGENCIARESULT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "ConsultaParceiroAgenciaResult" element
         */
        public void unsetConsultaParceiroAgenciaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CONSULTAPARCEIROAGENCIARESULT$0, 0);
            }
        }
    }
}
