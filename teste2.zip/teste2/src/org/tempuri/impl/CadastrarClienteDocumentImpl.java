/*
 * An XML document type.
 * Localname: CadastrarCliente
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.CadastrarClienteDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one CadastrarCliente(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class CadastrarClienteDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarClienteDocument
{
    private static final long serialVersionUID = 1L;
    
    public CadastrarClienteDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CADASTRARCLIENTE$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "CadastrarCliente");
    
    
    /**
     * Gets the "CadastrarCliente" element
     */
    public org.tempuri.CadastrarClienteDocument.CadastrarCliente getCadastrarCliente()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarClienteDocument.CadastrarCliente target = null;
            target = (org.tempuri.CadastrarClienteDocument.CadastrarCliente)get_store().find_element_user(CADASTRARCLIENTE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "CadastrarCliente" element
     */
    public void setCadastrarCliente(org.tempuri.CadastrarClienteDocument.CadastrarCliente cadastrarCliente)
    {
        generatedSetterHelperImpl(cadastrarCliente, CADASTRARCLIENTE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CadastrarCliente" element
     */
    public org.tempuri.CadastrarClienteDocument.CadastrarCliente addNewCadastrarCliente()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarClienteDocument.CadastrarCliente target = null;
            target = (org.tempuri.CadastrarClienteDocument.CadastrarCliente)get_store().add_element_user(CADASTRARCLIENTE$0);
            return target;
        }
    }
    /**
     * An XML CadastrarCliente(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class CadastrarClienteImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarClienteDocument.CadastrarCliente
    {
        private static final long serialVersionUID = 1L;
        
        public CadastrarClienteImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CLIENTE$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "cliente");
        
        
        /**
         * Gets the "cliente" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO getCliente()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO)get_store().find_element_user(CLIENTE$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "cliente" element
         */
        public boolean isNilCliente()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO)get_store().find_element_user(CLIENTE$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "cliente" element
         */
        public boolean isSetCliente()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CLIENTE$0) != 0;
            }
        }
        
        /**
         * Sets the "cliente" element
         */
        public void setCliente(org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO cliente)
        {
            generatedSetterHelperImpl(cliente, CLIENTE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "cliente" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO addNewCliente()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO)get_store().add_element_user(CLIENTE$0);
                return target;
            }
        }
        
        /**
         * Nils the "cliente" element
         */
        public void setNilCliente()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO)get_store().find_element_user(CLIENTE$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO)get_store().add_element_user(CLIENTE$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "cliente" element
         */
        public void unsetCliente()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CLIENTE$0, 0);
            }
        }
    }
}
