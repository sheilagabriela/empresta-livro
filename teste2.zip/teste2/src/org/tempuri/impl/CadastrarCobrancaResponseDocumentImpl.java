/*
 * An XML document type.
 * Localname: CadastrarCobrancaResponse
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.CadastrarCobrancaResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one CadastrarCobrancaResponse(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class CadastrarCobrancaResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarCobrancaResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public CadastrarCobrancaResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CADASTRARCOBRANCARESPONSE$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "CadastrarCobrancaResponse");
    
    
    /**
     * Gets the "CadastrarCobrancaResponse" element
     */
    public org.tempuri.CadastrarCobrancaResponseDocument.CadastrarCobrancaResponse getCadastrarCobrancaResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarCobrancaResponseDocument.CadastrarCobrancaResponse target = null;
            target = (org.tempuri.CadastrarCobrancaResponseDocument.CadastrarCobrancaResponse)get_store().find_element_user(CADASTRARCOBRANCARESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "CadastrarCobrancaResponse" element
     */
    public void setCadastrarCobrancaResponse(org.tempuri.CadastrarCobrancaResponseDocument.CadastrarCobrancaResponse cadastrarCobrancaResponse)
    {
        generatedSetterHelperImpl(cadastrarCobrancaResponse, CADASTRARCOBRANCARESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CadastrarCobrancaResponse" element
     */
    public org.tempuri.CadastrarCobrancaResponseDocument.CadastrarCobrancaResponse addNewCadastrarCobrancaResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarCobrancaResponseDocument.CadastrarCobrancaResponse target = null;
            target = (org.tempuri.CadastrarCobrancaResponseDocument.CadastrarCobrancaResponse)get_store().add_element_user(CADASTRARCOBRANCARESPONSE$0);
            return target;
        }
    }
    /**
     * An XML CadastrarCobrancaResponse(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class CadastrarCobrancaResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarCobrancaResponseDocument.CadastrarCobrancaResponse
    {
        private static final long serialVersionUID = 1L;
        
        public CadastrarCobrancaResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CADASTRARCOBRANCARESULT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "CadastrarCobrancaResult");
        
        
        /**
         * Gets the "CadastrarCobrancaResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO getCadastrarCobrancaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(CADASTRARCOBRANCARESULT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "CadastrarCobrancaResult" element
         */
        public boolean isNilCadastrarCobrancaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(CADASTRARCOBRANCARESULT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "CadastrarCobrancaResult" element
         */
        public boolean isSetCadastrarCobrancaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CADASTRARCOBRANCARESULT$0) != 0;
            }
        }
        
        /**
         * Sets the "CadastrarCobrancaResult" element
         */
        public void setCadastrarCobrancaResult(org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO cadastrarCobrancaResult)
        {
            generatedSetterHelperImpl(cadastrarCobrancaResult, CADASTRARCOBRANCARESULT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "CadastrarCobrancaResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO addNewCadastrarCobrancaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().add_element_user(CADASTRARCOBRANCARESULT$0);
                return target;
            }
        }
        
        /**
         * Nils the "CadastrarCobrancaResult" element
         */
        public void setNilCadastrarCobrancaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(CADASTRARCOBRANCARESULT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().add_element_user(CADASTRARCOBRANCARESULT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "CadastrarCobrancaResult" element
         */
        public void unsetCadastrarCobrancaResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CADASTRARCOBRANCARESULT$0, 0);
            }
        }
    }
}
