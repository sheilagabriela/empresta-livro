/*
 * An XML document type.
 * Localname: GerarProtocoloSimulacaoFintechResponse
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one GerarProtocoloSimulacaoFintechResponse(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class GerarProtocoloSimulacaoFintechResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public GerarProtocoloSimulacaoFintechResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GERARPROTOCOLOSIMULACAOFINTECHRESPONSE$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "GerarProtocoloSimulacaoFintechResponse");
    
    
    /**
     * Gets the "GerarProtocoloSimulacaoFintechResponse" element
     */
    public org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument.GerarProtocoloSimulacaoFintechResponse getGerarProtocoloSimulacaoFintechResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument.GerarProtocoloSimulacaoFintechResponse target = null;
            target = (org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument.GerarProtocoloSimulacaoFintechResponse)get_store().find_element_user(GERARPROTOCOLOSIMULACAOFINTECHRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "GerarProtocoloSimulacaoFintechResponse" element
     */
    public void setGerarProtocoloSimulacaoFintechResponse(org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument.GerarProtocoloSimulacaoFintechResponse gerarProtocoloSimulacaoFintechResponse)
    {
        generatedSetterHelperImpl(gerarProtocoloSimulacaoFintechResponse, GERARPROTOCOLOSIMULACAOFINTECHRESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "GerarProtocoloSimulacaoFintechResponse" element
     */
    public org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument.GerarProtocoloSimulacaoFintechResponse addNewGerarProtocoloSimulacaoFintechResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument.GerarProtocoloSimulacaoFintechResponse target = null;
            target = (org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument.GerarProtocoloSimulacaoFintechResponse)get_store().add_element_user(GERARPROTOCOLOSIMULACAOFINTECHRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML GerarProtocoloSimulacaoFintechResponse(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class GerarProtocoloSimulacaoFintechResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument.GerarProtocoloSimulacaoFintechResponse
    {
        private static final long serialVersionUID = 1L;
        
        public GerarProtocoloSimulacaoFintechResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName GERARPROTOCOLOSIMULACAOFINTECHRESULT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "GerarProtocoloSimulacaoFintechResult");
        
        
        /**
         * Gets the "GerarProtocoloSimulacaoFintechResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO getGerarProtocoloSimulacaoFintechResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(GERARPROTOCOLOSIMULACAOFINTECHRESULT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "GerarProtocoloSimulacaoFintechResult" element
         */
        public boolean isNilGerarProtocoloSimulacaoFintechResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(GERARPROTOCOLOSIMULACAOFINTECHRESULT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "GerarProtocoloSimulacaoFintechResult" element
         */
        public boolean isSetGerarProtocoloSimulacaoFintechResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(GERARPROTOCOLOSIMULACAOFINTECHRESULT$0) != 0;
            }
        }
        
        /**
         * Sets the "GerarProtocoloSimulacaoFintechResult" element
         */
        public void setGerarProtocoloSimulacaoFintechResult(org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO gerarProtocoloSimulacaoFintechResult)
        {
            generatedSetterHelperImpl(gerarProtocoloSimulacaoFintechResult, GERARPROTOCOLOSIMULACAOFINTECHRESULT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "GerarProtocoloSimulacaoFintechResult" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO addNewGerarProtocoloSimulacaoFintechResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().add_element_user(GERARPROTOCOLOSIMULACAOFINTECHRESULT$0);
                return target;
            }
        }
        
        /**
         * Nils the "GerarProtocoloSimulacaoFintechResult" element
         */
        public void setNilGerarProtocoloSimulacaoFintechResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(GERARPROTOCOLOSIMULACAOFINTECHRESULT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().add_element_user(GERARPROTOCOLOSIMULACAOFINTECHRESULT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "GerarProtocoloSimulacaoFintechResult" element
         */
        public void unsetGerarProtocoloSimulacaoFintechResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(GERARPROTOCOLOSIMULACAOFINTECHRESULT$0, 0);
            }
        }
    }
}
