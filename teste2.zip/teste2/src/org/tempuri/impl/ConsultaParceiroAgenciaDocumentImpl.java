/*
 * An XML document type.
 * Localname: ConsultaParceiroAgencia
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.ConsultaParceiroAgenciaDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one ConsultaParceiroAgencia(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class ConsultaParceiroAgenciaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultaParceiroAgenciaDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultaParceiroAgenciaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTAPARCEIROAGENCIA$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "ConsultaParceiroAgencia");
    
    
    /**
     * Gets the "ConsultaParceiroAgencia" element
     */
    public org.tempuri.ConsultaParceiroAgenciaDocument.ConsultaParceiroAgencia getConsultaParceiroAgencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultaParceiroAgenciaDocument.ConsultaParceiroAgencia target = null;
            target = (org.tempuri.ConsultaParceiroAgenciaDocument.ConsultaParceiroAgencia)get_store().find_element_user(CONSULTAPARCEIROAGENCIA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultaParceiroAgencia" element
     */
    public void setConsultaParceiroAgencia(org.tempuri.ConsultaParceiroAgenciaDocument.ConsultaParceiroAgencia consultaParceiroAgencia)
    {
        generatedSetterHelperImpl(consultaParceiroAgencia, CONSULTAPARCEIROAGENCIA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultaParceiroAgencia" element
     */
    public org.tempuri.ConsultaParceiroAgenciaDocument.ConsultaParceiroAgencia addNewConsultaParceiroAgencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultaParceiroAgenciaDocument.ConsultaParceiroAgencia target = null;
            target = (org.tempuri.ConsultaParceiroAgenciaDocument.ConsultaParceiroAgencia)get_store().add_element_user(CONSULTAPARCEIROAGENCIA$0);
            return target;
        }
    }
    /**
     * An XML ConsultaParceiroAgencia(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class ConsultaParceiroAgenciaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultaParceiroAgenciaDocument.ConsultaParceiroAgencia
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultaParceiroAgenciaImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName PARCEIRO$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "parceiro");
        
        
        /**
         * Gets the "parceiro" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO getParceiro()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO)get_store().find_element_user(PARCEIRO$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "parceiro" element
         */
        public boolean isNilParceiro()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO)get_store().find_element_user(PARCEIRO$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "parceiro" element
         */
        public boolean isSetParceiro()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PARCEIRO$0) != 0;
            }
        }
        
        /**
         * Sets the "parceiro" element
         */
        public void setParceiro(org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parceiro)
        {
            generatedSetterHelperImpl(parceiro, PARCEIRO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "parceiro" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO addNewParceiro()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO)get_store().add_element_user(PARCEIRO$0);
                return target;
            }
        }
        
        /**
         * Nils the "parceiro" element
         */
        public void setNilParceiro()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO)get_store().find_element_user(PARCEIRO$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO)get_store().add_element_user(PARCEIRO$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "parceiro" element
         */
        public void unsetParceiro()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PARCEIRO$0, 0);
            }
        }
    }
}
