/*
 * An XML document type.
 * Localname: CadastrarCobranca
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.CadastrarCobrancaDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one CadastrarCobranca(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class CadastrarCobrancaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarCobrancaDocument
{
    private static final long serialVersionUID = 1L;
    
    public CadastrarCobrancaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CADASTRARCOBRANCA$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "CadastrarCobranca");
    
    
    /**
     * Gets the "CadastrarCobranca" element
     */
    public org.tempuri.CadastrarCobrancaDocument.CadastrarCobranca getCadastrarCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarCobrancaDocument.CadastrarCobranca target = null;
            target = (org.tempuri.CadastrarCobrancaDocument.CadastrarCobranca)get_store().find_element_user(CADASTRARCOBRANCA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "CadastrarCobranca" element
     */
    public void setCadastrarCobranca(org.tempuri.CadastrarCobrancaDocument.CadastrarCobranca cadastrarCobranca)
    {
        generatedSetterHelperImpl(cadastrarCobranca, CADASTRARCOBRANCA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CadastrarCobranca" element
     */
    public org.tempuri.CadastrarCobrancaDocument.CadastrarCobranca addNewCadastrarCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.CadastrarCobrancaDocument.CadastrarCobranca target = null;
            target = (org.tempuri.CadastrarCobrancaDocument.CadastrarCobranca)get_store().add_element_user(CADASTRARCOBRANCA$0);
            return target;
        }
    }
    /**
     * An XML CadastrarCobranca(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class CadastrarCobrancaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.CadastrarCobrancaDocument.CadastrarCobranca
    {
        private static final long serialVersionUID = 1L;
        
        public CadastrarCobrancaImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName COBRANCA$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "cobranca");
        
        
        /**
         * Gets the "cobranca" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO getCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO)get_store().find_element_user(COBRANCA$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "cobranca" element
         */
        public boolean isNilCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO)get_store().find_element_user(COBRANCA$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "cobranca" element
         */
        public boolean isSetCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(COBRANCA$0) != 0;
            }
        }
        
        /**
         * Sets the "cobranca" element
         */
        public void setCobranca(org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO cobranca)
        {
            generatedSetterHelperImpl(cobranca, COBRANCA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "cobranca" element
         */
        public org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO addNewCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO)get_store().add_element_user(COBRANCA$0);
                return target;
            }
        }
        
        /**
         * Nils the "cobranca" element
         */
        public void setNilCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO)get_store().find_element_user(COBRANCA$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO)get_store().add_element_user(COBRANCA$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "cobranca" element
         */
        public void unsetCobranca()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(COBRANCA$0, 0);
            }
        }
    }
}
