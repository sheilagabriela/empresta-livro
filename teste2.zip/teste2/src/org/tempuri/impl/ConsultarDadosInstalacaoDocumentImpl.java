/*
 * An XML document type.
 * Localname: ConsultarDadosInstalacao
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.ConsultarDadosInstalacaoDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri.impl;
/**
 * A document containing one ConsultarDadosInstalacao(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public class ConsultarDadosInstalacaoDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultarDadosInstalacaoDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarDadosInstalacaoDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTARDADOSINSTALACAO$0 = 
        new javax.xml.namespace.QName("http://tempuri.org/", "ConsultarDadosInstalacao");
    
    
    /**
     * Gets the "ConsultarDadosInstalacao" element
     */
    public org.tempuri.ConsultarDadosInstalacaoDocument.ConsultarDadosInstalacao getConsultarDadosInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultarDadosInstalacaoDocument.ConsultarDadosInstalacao target = null;
            target = (org.tempuri.ConsultarDadosInstalacaoDocument.ConsultarDadosInstalacao)get_store().find_element_user(CONSULTARDADOSINSTALACAO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultarDadosInstalacao" element
     */
    public void setConsultarDadosInstalacao(org.tempuri.ConsultarDadosInstalacaoDocument.ConsultarDadosInstalacao consultarDadosInstalacao)
    {
        generatedSetterHelperImpl(consultarDadosInstalacao, CONSULTARDADOSINSTALACAO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultarDadosInstalacao" element
     */
    public org.tempuri.ConsultarDadosInstalacaoDocument.ConsultarDadosInstalacao addNewConsultarDadosInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tempuri.ConsultarDadosInstalacaoDocument.ConsultarDadosInstalacao target = null;
            target = (org.tempuri.ConsultarDadosInstalacaoDocument.ConsultarDadosInstalacao)get_store().add_element_user(CONSULTARDADOSINSTALACAO$0);
            return target;
        }
    }
    /**
     * An XML ConsultarDadosInstalacao(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public static class ConsultarDadosInstalacaoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tempuri.ConsultarDadosInstalacaoDocument.ConsultarDadosInstalacao
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultarDadosInstalacaoImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName INPUT$0 = 
            new javax.xml.namespace.QName("http://tempuri.org/", "input");
        
        
        /**
         * Gets the "input" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO getInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO)get_store().find_element_user(INPUT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "input" element
         */
        public boolean isNilInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO)get_store().find_element_user(INPUT$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "input" element
         */
        public boolean isSetInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(INPUT$0) != 0;
            }
        }
        
        /**
         * Sets the "input" element
         */
        public void setInput(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO input)
        {
            generatedSetterHelperImpl(input, INPUT$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "input" element
         */
        public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO addNewInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO)get_store().add_element_user(INPUT$0);
                return target;
            }
        }
        
        /**
         * Nils the "input" element
         */
        public void setNilInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO target = null;
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO)get_store().find_element_user(INPUT$0, 0);
                if (target == null)
                {
                    target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO)get_store().add_element_user(INPUT$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "input" element
         */
        public void unsetInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(INPUT$0, 0);
            }
        }
    }
}
