/**
 * GMPWebServicesMessageReceiverInOut.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.9  Built on : Nov 16, 2018 (12:05:37 GMT)
 */
package org.tempuri;


/**
 *  GMPWebServicesMessageReceiverInOut message receiver
 */
public class GMPWebServicesMessageReceiverInOut extends org.apache.axis2.receivers.AbstractInOutMessageReceiver {
    //
    private final org.apache.xmlbeans.XmlOptions _xmlOptions;

    {
        _xmlOptions = new org.apache.xmlbeans.XmlOptions();
        _xmlOptions.setSaveNoXmlDecl();
        _xmlOptions.setSaveAggressiveNamespaces();
        _xmlOptions.setSaveNamespacesFirst();
    }

    public void invokeBusinessLogic(
        org.apache.axis2.context.MessageContext msgContext,
        org.apache.axis2.context.MessageContext newMsgContext)
        throws org.apache.axis2.AxisFault {
        try {
            // get the implementation class for the Web Service
            Object obj = getTheImplementationObject(msgContext);

            GMPWebServicesSkeletonInterface skel = (GMPWebServicesSkeletonInterface) obj;

            //Out Envelop
            org.apache.axiom.soap.SOAPEnvelope envelope = null;

            //Find the axisOperation that has been set by the Dispatch phase.
            org.apache.axis2.description.AxisOperation op = msgContext.getOperationContext()
                                                                      .getAxisOperation();

            if (op == null) {
                throw new org.apache.axis2.AxisFault(
                    "Operation is not located, if this is doclit style the SOAP-ACTION should specified via the SOAP Action to use the RawXMLProvider");
            }

            java.lang.String methodName;

            if ((op.getName() != null) &&
                    ((methodName = org.apache.axis2.util.JavaUtils.xmlNameToJavaIdentifier(
                            op.getName().getLocalPart())) != null)) {
                if ("consultaParceiroAgencia".equals(methodName)) {
                    org.tempuri.ConsultaParceiroAgenciaResponseDocument consultaParceiroAgenciaResponse85 =
                        null;
                    org.tempuri.ConsultaParceiroAgenciaDocument wrappedParam = (org.tempuri.ConsultaParceiroAgenciaDocument) fromOM(msgContext.getEnvelope()
                                                                                                                                              .getBody()
                                                                                                                                              .getFirstElement(),
                            org.tempuri.ConsultaParceiroAgenciaDocument.class);

                    consultaParceiroAgenciaResponse85 = skel.consultaParceiroAgencia(wrappedParam);

                    envelope = toEnvelope(getSOAPFactory(msgContext),
                            consultaParceiroAgenciaResponse85, false,
                            new javax.xml.namespace.QName(
                                "http://tempuri.org/",
                                "ConsultaParceiroAgenciaResponse"));
                } else
                 if ("consultarDadosParceiro".equals(methodName)) {
                    org.tempuri.ConsultarDadosParceiroResponseDocument consultarDadosParceiroResponse87 =
                        null;
                    org.tempuri.ConsultarDadosParceiroDocument wrappedParam = (org.tempuri.ConsultarDadosParceiroDocument) fromOM(msgContext.getEnvelope()
                                                                                                                                            .getBody()
                                                                                                                                            .getFirstElement(),
                            org.tempuri.ConsultarDadosParceiroDocument.class);

                    consultarDadosParceiroResponse87 = skel.consultarDadosParceiro(wrappedParam);

                    envelope = toEnvelope(getSOAPFactory(msgContext),
                            consultarDadosParceiroResponse87, false,
                            new javax.xml.namespace.QName(
                                "http://tempuri.org/",
                                "ConsultarDadosParceiroResponse"));
                } else
                 if ("consultarDadosInstalacao".equals(methodName)) {
                    org.tempuri.ConsultarDadosInstalacaoResponseDocument consultarDadosInstalacaoResponse89 =
                        null;
                    org.tempuri.ConsultarDadosInstalacaoDocument wrappedParam = (org.tempuri.ConsultarDadosInstalacaoDocument) fromOM(msgContext.getEnvelope()
                                                                                                                                                .getBody()
                                                                                                                                                .getFirstElement(),
                            org.tempuri.ConsultarDadosInstalacaoDocument.class);

                    consultarDadosInstalacaoResponse89 = skel.consultarDadosInstalacao(wrappedParam);

                    envelope = toEnvelope(getSOAPFactory(msgContext),
                            consultarDadosInstalacaoResponse89, false,
                            new javax.xml.namespace.QName(
                                "http://tempuri.org/",
                                "ConsultarDadosInstalacaoResponse"));
                } else
                 if ("cadastrarDoacao".equals(methodName)) {
                    org.tempuri.CadastrarDoacaoResponseDocument cadastrarDoacaoResponse91 =
                        null;
                    org.tempuri.CadastrarDoacaoDocument wrappedParam = (org.tempuri.CadastrarDoacaoDocument) fromOM(msgContext.getEnvelope()
                                                                                                                              .getBody()
                                                                                                                              .getFirstElement(),
                            org.tempuri.CadastrarDoacaoDocument.class);

                    cadastrarDoacaoResponse91 = skel.cadastrarDoacao(wrappedParam);

                    envelope = toEnvelope(getSOAPFactory(msgContext),
                            cadastrarDoacaoResponse91, false,
                            new javax.xml.namespace.QName(
                                "http://tempuri.org/", "CadastrarDoacaoResponse"));
                } else
                 if ("gerarProtocoloSimulacaoFintech".equals(methodName)) {
                    org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument gerarProtocoloSimulacaoFintechResponse93 =
                        null;
                    org.tempuri.GerarProtocoloSimulacaoFintechDocument wrappedParam =
                        (org.tempuri.GerarProtocoloSimulacaoFintechDocument) fromOM(msgContext.getEnvelope()
                                                                                              .getBody()
                                                                                              .getFirstElement(),
                            org.tempuri.GerarProtocoloSimulacaoFintechDocument.class);

                    gerarProtocoloSimulacaoFintechResponse93 = skel.gerarProtocoloSimulacaoFintech(wrappedParam);

                    envelope = toEnvelope(getSOAPFactory(msgContext),
                            gerarProtocoloSimulacaoFintechResponse93, false,
                            new javax.xml.namespace.QName(
                                "http://tempuri.org/",
                                "GerarProtocoloSimulacaoFintechResponse"));
                } else
                 if ("consultarProdutoParceiro".equals(methodName)) {
                    org.tempuri.ConsultarProdutoParceiroResponseDocument consultarProdutoParceiroResponse95 =
                        null;
                    org.tempuri.ConsultarProdutoParceiroDocument wrappedParam = (org.tempuri.ConsultarProdutoParceiroDocument) fromOM(msgContext.getEnvelope()
                                                                                                                                                .getBody()
                                                                                                                                                .getFirstElement(),
                            org.tempuri.ConsultarProdutoParceiroDocument.class);

                    consultarProdutoParceiroResponse95 = skel.consultarProdutoParceiro(wrappedParam);

                    envelope = toEnvelope(getSOAPFactory(msgContext),
                            consultarProdutoParceiroResponse95, false,
                            new javax.xml.namespace.QName(
                                "http://tempuri.org/",
                                "ConsultarProdutoParceiroResponse"));
                } else
                 if ("excluirDoacao".equals(methodName)) {
                    org.tempuri.ExcluirDoacaoResponseDocument excluirDoacaoResponse97 =
                        null;
                    org.tempuri.ExcluirDoacaoDocument wrappedParam = (org.tempuri.ExcluirDoacaoDocument) fromOM(msgContext.getEnvelope()
                                                                                                                          .getBody()
                                                                                                                          .getFirstElement(),
                            org.tempuri.ExcluirDoacaoDocument.class);

                    excluirDoacaoResponse97 = skel.excluirDoacao(wrappedParam);

                    envelope = toEnvelope(getSOAPFactory(msgContext),
                            excluirDoacaoResponse97, false,
                            new javax.xml.namespace.QName(
                                "http://tempuri.org/", "ExcluirDoacaoResponse"));
                } else
                 if ("cadastrarCliente".equals(methodName)) {
                    org.tempuri.CadastrarClienteResponseDocument cadastrarClienteResponse99 =
                        null;
                    org.tempuri.CadastrarClienteDocument wrappedParam = (org.tempuri.CadastrarClienteDocument) fromOM(msgContext.getEnvelope()
                                                                                                                                .getBody()
                                                                                                                                .getFirstElement(),
                            org.tempuri.CadastrarClienteDocument.class);

                    cadastrarClienteResponse99 = skel.cadastrarCliente(wrappedParam);

                    envelope = toEnvelope(getSOAPFactory(msgContext),
                            cadastrarClienteResponse99, false,
                            new javax.xml.namespace.QName(
                                "http://tempuri.org/",
                                "CadastrarClienteResponse"));
                } else
                 if ("cadastrarCobrancaFintech".equals(methodName)) {
                    org.tempuri.CadastrarCobrancaFintechResponseDocument cadastrarCobrancaFintechResponse101 =
                        null;
                    org.tempuri.CadastrarCobrancaFintechDocument wrappedParam = (org.tempuri.CadastrarCobrancaFintechDocument) fromOM(msgContext.getEnvelope()
                                                                                                                                                .getBody()
                                                                                                                                                .getFirstElement(),
                            org.tempuri.CadastrarCobrancaFintechDocument.class);

                    cadastrarCobrancaFintechResponse101 = skel.cadastrarCobrancaFintech(wrappedParam);

                    envelope = toEnvelope(getSOAPFactory(msgContext),
                            cadastrarCobrancaFintechResponse101, false,
                            new javax.xml.namespace.QName(
                                "http://tempuri.org/",
                                "CadastrarCobrancaFintechResponse"));
                } else
                 if ("cadastrarCobranca".equals(methodName)) {
                    org.tempuri.CadastrarCobrancaResponseDocument cadastrarCobrancaResponse103 =
                        null;
                    org.tempuri.CadastrarCobrancaDocument wrappedParam = (org.tempuri.CadastrarCobrancaDocument) fromOM(msgContext.getEnvelope()
                                                                                                                                  .getBody()
                                                                                                                                  .getFirstElement(),
                            org.tempuri.CadastrarCobrancaDocument.class);

                    cadastrarCobrancaResponse103 = skel.cadastrarCobranca(wrappedParam);

                    envelope = toEnvelope(getSOAPFactory(msgContext),
                            cadastrarCobrancaResponse103, false,
                            new javax.xml.namespace.QName(
                                "http://tempuri.org/",
                                "CadastrarCobrancaResponse"));
                } else
                 if ("enviarNotificacaoSMS".equals(methodName)) {
                    org.tempuri.EnviarNotificacaoSMSResponseDocument enviarNotificacaoSMSResponse105 =
                        null;
                    org.tempuri.EnviarNotificacaoSMSDocument wrappedParam = (org.tempuri.EnviarNotificacaoSMSDocument) fromOM(msgContext.getEnvelope()
                                                                                                                                        .getBody()
                                                                                                                                        .getFirstElement(),
                            org.tempuri.EnviarNotificacaoSMSDocument.class);

                    enviarNotificacaoSMSResponse105 = skel.enviarNotificacaoSMS(wrappedParam);

                    envelope = toEnvelope(getSOAPFactory(msgContext),
                            enviarNotificacaoSMSResponse105, false,
                            new javax.xml.namespace.QName(
                                "http://tempuri.org/",
                                "EnviarNotificacaoSMSResponse"));
                } else
                 if ("validarConsulta".equals(methodName)) {
                    org.tempuri.ValidarConsultaResponseDocument validarConsultaResponse107 =
                        null;
                    org.tempuri.ValidarConsultaDocument wrappedParam = (org.tempuri.ValidarConsultaDocument) fromOM(msgContext.getEnvelope()
                                                                                                                              .getBody()
                                                                                                                              .getFirstElement(),
                            org.tempuri.ValidarConsultaDocument.class);

                    validarConsultaResponse107 = skel.validarConsulta(wrappedParam);

                    envelope = toEnvelope(getSOAPFactory(msgContext),
                            validarConsultaResponse107, false,
                            new javax.xml.namespace.QName(
                                "http://tempuri.org/", "ValidarConsultaResponse"));
                } else
                 if ("consultarDadosFatura".equals(methodName)) {
                    org.tempuri.ConsultarDadosFaturaResponseDocument consultarDadosFaturaResponse109 =
                        null;
                    org.tempuri.ConsultarDadosFaturaDocument wrappedParam = (org.tempuri.ConsultarDadosFaturaDocument) fromOM(msgContext.getEnvelope()
                                                                                                                                        .getBody()
                                                                                                                                        .getFirstElement(),
                            org.tempuri.ConsultarDadosFaturaDocument.class);

                    consultarDadosFaturaResponse109 = skel.consultarDadosFatura(wrappedParam);

                    envelope = toEnvelope(getSOAPFactory(msgContext),
                            consultarDadosFaturaResponse109, false,
                            new javax.xml.namespace.QName(
                                "http://tempuri.org/",
                                "ConsultarDadosFaturaResponse"));
                } else
                 if ("excluirCobranca".equals(methodName)) {
                    org.tempuri.ExcluirCobrancaResponseDocument excluirCobrancaResponse111 =
                        null;
                    org.tempuri.ExcluirCobrancaDocument wrappedParam = (org.tempuri.ExcluirCobrancaDocument) fromOM(msgContext.getEnvelope()
                                                                                                                              .getBody()
                                                                                                                              .getFirstElement(),
                            org.tempuri.ExcluirCobrancaDocument.class);

                    excluirCobrancaResponse111 = skel.excluirCobranca(wrappedParam);

                    envelope = toEnvelope(getSOAPFactory(msgContext),
                            excluirCobrancaResponse111, false,
                            new javax.xml.namespace.QName(
                                "http://tempuri.org/", "ExcluirCobrancaResponse"));
                } else {
                    throw new java.lang.RuntimeException("method not found");
                }

                newMsgContext.setEnvelope(envelope);
            }
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /**
     * Get the {@link org.apache.xmlbeans.XmlOptions} object that the stub uses when
     * serializing objects to XML.
     *
     * @return the options used for serialization
     */
    public org.apache.xmlbeans.XmlOptions _getXmlOptions() {
        return _xmlOptions;
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ConsultaParceiroAgenciaDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ConsultaParceiroAgenciaDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ConsultaParceiroAgenciaResponseDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ConsultaParceiroAgenciaResponseDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ConsultarDadosParceiroDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ConsultarDadosParceiroDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ConsultarDadosParceiroResponseDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ConsultarDadosParceiroResponseDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ConsultarDadosInstalacaoDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ConsultarDadosInstalacaoDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ConsultarDadosInstalacaoResponseDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ConsultarDadosInstalacaoResponseDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.CadastrarDoacaoDocument param, boolean optimizeContent)
        throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.CadastrarDoacaoDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.CadastrarDoacaoResponseDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.CadastrarDoacaoResponseDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.GerarProtocoloSimulacaoFintechDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.GerarProtocoloSimulacaoFintechDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ConsultarProdutoParceiroDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ConsultarProdutoParceiroDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ConsultarProdutoParceiroResponseDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ConsultarProdutoParceiroResponseDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ExcluirDoacaoDocument param, boolean optimizeContent)
        throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ExcluirDoacaoDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ExcluirDoacaoResponseDocument param, boolean optimizeContent)
        throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ExcluirDoacaoResponseDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.CadastrarClienteDocument param, boolean optimizeContent)
        throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.CadastrarClienteDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.CadastrarClienteResponseDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.CadastrarClienteResponseDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.CadastrarCobrancaFintechDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.CadastrarCobrancaFintechDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.CadastrarCobrancaFintechResponseDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.CadastrarCobrancaFintechResponseDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.CadastrarCobrancaDocument param, boolean optimizeContent)
        throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.CadastrarCobrancaDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.CadastrarCobrancaResponseDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.CadastrarCobrancaResponseDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.EnviarNotificacaoSMSDocument param, boolean optimizeContent)
        throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.EnviarNotificacaoSMSDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.EnviarNotificacaoSMSResponseDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.EnviarNotificacaoSMSResponseDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ValidarConsultaDocument param, boolean optimizeContent)
        throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ValidarConsultaDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ValidarConsultaResponseDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ValidarConsultaResponseDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ConsultarDadosFaturaDocument param, boolean optimizeContent)
        throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ConsultarDadosFaturaDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ConsultarDadosFaturaResponseDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ConsultarDadosFaturaResponseDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ExcluirCobrancaDocument param, boolean optimizeContent)
        throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ExcluirCobrancaDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.tempuri.ExcluirCobrancaResponseDocument param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        return toOM(param);
    }

    private org.apache.axiom.om.OMElement toOM(
        final org.tempuri.ExcluirCobrancaResponseDocument param)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.om.OMXMLParserWrapper builder = org.apache.axiom.om.OMXMLBuilderFactory.createOMBuilder(new javax.xml.transform.sax.SAXSource(
                    new org.apache.axis2.xmlbeans.XmlBeansXMLReader(param,
                        _xmlOptions), new org.xml.sax.InputSource()));

        try {
            return builder.getDocumentElement(true);
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.tempuri.ConsultaParceiroAgenciaResponseDocument param,
        boolean optimizeContent, javax.xml.namespace.QName elementQName)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.soap.SOAPEnvelope envelope = factory.getDefaultEnvelope();

        if (param != null) {
            envelope.getBody().addChild(toOM(param, optimizeContent));
        }

        return envelope;
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.tempuri.ConsultarDadosParceiroResponseDocument param,
        boolean optimizeContent, javax.xml.namespace.QName elementQName)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.soap.SOAPEnvelope envelope = factory.getDefaultEnvelope();

        if (param != null) {
            envelope.getBody().addChild(toOM(param, optimizeContent));
        }

        return envelope;
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.tempuri.ConsultarDadosInstalacaoResponseDocument param,
        boolean optimizeContent, javax.xml.namespace.QName elementQName)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.soap.SOAPEnvelope envelope = factory.getDefaultEnvelope();

        if (param != null) {
            envelope.getBody().addChild(toOM(param, optimizeContent));
        }

        return envelope;
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.tempuri.CadastrarDoacaoResponseDocument param,
        boolean optimizeContent, javax.xml.namespace.QName elementQName)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.soap.SOAPEnvelope envelope = factory.getDefaultEnvelope();

        if (param != null) {
            envelope.getBody().addChild(toOM(param, optimizeContent));
        }

        return envelope;
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument param,
        boolean optimizeContent, javax.xml.namespace.QName elementQName)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.soap.SOAPEnvelope envelope = factory.getDefaultEnvelope();

        if (param != null) {
            envelope.getBody().addChild(toOM(param, optimizeContent));
        }

        return envelope;
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.tempuri.ConsultarProdutoParceiroResponseDocument param,
        boolean optimizeContent, javax.xml.namespace.QName elementQName)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.soap.SOAPEnvelope envelope = factory.getDefaultEnvelope();

        if (param != null) {
            envelope.getBody().addChild(toOM(param, optimizeContent));
        }

        return envelope;
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.tempuri.ExcluirDoacaoResponseDocument param,
        boolean optimizeContent, javax.xml.namespace.QName elementQName)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.soap.SOAPEnvelope envelope = factory.getDefaultEnvelope();

        if (param != null) {
            envelope.getBody().addChild(toOM(param, optimizeContent));
        }

        return envelope;
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.tempuri.CadastrarClienteResponseDocument param,
        boolean optimizeContent, javax.xml.namespace.QName elementQName)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.soap.SOAPEnvelope envelope = factory.getDefaultEnvelope();

        if (param != null) {
            envelope.getBody().addChild(toOM(param, optimizeContent));
        }

        return envelope;
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.tempuri.CadastrarCobrancaFintechResponseDocument param,
        boolean optimizeContent, javax.xml.namespace.QName elementQName)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.soap.SOAPEnvelope envelope = factory.getDefaultEnvelope();

        if (param != null) {
            envelope.getBody().addChild(toOM(param, optimizeContent));
        }

        return envelope;
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.tempuri.CadastrarCobrancaResponseDocument param,
        boolean optimizeContent, javax.xml.namespace.QName elementQName)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.soap.SOAPEnvelope envelope = factory.getDefaultEnvelope();

        if (param != null) {
            envelope.getBody().addChild(toOM(param, optimizeContent));
        }

        return envelope;
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.tempuri.EnviarNotificacaoSMSResponseDocument param,
        boolean optimizeContent, javax.xml.namespace.QName elementQName)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.soap.SOAPEnvelope envelope = factory.getDefaultEnvelope();

        if (param != null) {
            envelope.getBody().addChild(toOM(param, optimizeContent));
        }

        return envelope;
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.tempuri.ValidarConsultaResponseDocument param,
        boolean optimizeContent, javax.xml.namespace.QName elementQName)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.soap.SOAPEnvelope envelope = factory.getDefaultEnvelope();

        if (param != null) {
            envelope.getBody().addChild(toOM(param, optimizeContent));
        }

        return envelope;
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.tempuri.ConsultarDadosFaturaResponseDocument param,
        boolean optimizeContent, javax.xml.namespace.QName elementQName)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.soap.SOAPEnvelope envelope = factory.getDefaultEnvelope();

        if (param != null) {
            envelope.getBody().addChild(toOM(param, optimizeContent));
        }

        return envelope;
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.tempuri.ExcluirCobrancaResponseDocument param,
        boolean optimizeContent, javax.xml.namespace.QName elementQName)
        throws org.apache.axis2.AxisFault {
        org.apache.axiom.soap.SOAPEnvelope envelope = factory.getDefaultEnvelope();

        if (param != null) {
            envelope.getBody().addChild(toOM(param, optimizeContent));
        }

        return envelope;
    }

    /**
     *  get the default envelope
     */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory) {
        return factory.getDefaultEnvelope();
    }

    public org.apache.xmlbeans.XmlObject fromOM(
        org.apache.axiom.om.OMElement param, java.lang.Class type)
        throws org.apache.axis2.AxisFault {
        try {
            if (org.tempuri.ConsultaParceiroAgenciaDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ConsultaParceiroAgenciaDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.ConsultaParceiroAgenciaResponseDocument.class.equals(
                        type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ConsultaParceiroAgenciaResponseDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.ConsultarDadosParceiroDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ConsultarDadosParceiroDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.ConsultarDadosParceiroResponseDocument.class.equals(
                        type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ConsultarDadosParceiroResponseDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.ConsultarDadosInstalacaoDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ConsultarDadosInstalacaoDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.ConsultarDadosInstalacaoResponseDocument.class.equals(
                        type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ConsultarDadosInstalacaoResponseDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.CadastrarDoacaoDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.CadastrarDoacaoDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.CadastrarDoacaoResponseDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.CadastrarDoacaoResponseDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.GerarProtocoloSimulacaoFintechDocument.class.equals(
                        type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.GerarProtocoloSimulacaoFintechDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument.class.equals(
                        type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.ConsultarProdutoParceiroDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ConsultarProdutoParceiroDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.ConsultarProdutoParceiroResponseDocument.class.equals(
                        type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ConsultarProdutoParceiroResponseDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.ExcluirDoacaoDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ExcluirDoacaoDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.ExcluirDoacaoResponseDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ExcluirDoacaoResponseDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.CadastrarClienteDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.CadastrarClienteDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.CadastrarClienteResponseDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.CadastrarClienteResponseDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.CadastrarCobrancaFintechDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.CadastrarCobrancaFintechDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.CadastrarCobrancaFintechResponseDocument.class.equals(
                        type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.CadastrarCobrancaFintechResponseDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.CadastrarCobrancaDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.CadastrarCobrancaDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.CadastrarCobrancaResponseDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.CadastrarCobrancaResponseDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.EnviarNotificacaoSMSDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.EnviarNotificacaoSMSDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.EnviarNotificacaoSMSResponseDocument.class.equals(
                        type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.EnviarNotificacaoSMSResponseDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.ValidarConsultaDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ValidarConsultaDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.ValidarConsultaResponseDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ValidarConsultaResponseDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.ConsultarDadosFaturaDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ConsultarDadosFaturaDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.ConsultarDadosFaturaResponseDocument.class.equals(
                        type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ConsultarDadosFaturaResponseDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.ExcluirCobrancaDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ExcluirCobrancaDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }

            if (org.tempuri.ExcluirCobrancaResponseDocument.class.equals(type)) {
                org.apache.axiom.om.OMXMLStreamReaderConfiguration configuration =
                    new org.apache.axiom.om.OMXMLStreamReaderConfiguration();
                configuration.setPreserveNamespaceContext(true);

                return org.tempuri.ExcluirCobrancaResponseDocument.Factory.parse(param.getXMLStreamReader(
                        false, configuration));
            }
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }

        return null;
    }

    private org.apache.axis2.AxisFault createAxisFault(java.lang.Exception e) {
        org.apache.axis2.AxisFault f;
        Throwable cause = e.getCause();

        if (cause != null) {
            f = new org.apache.axis2.AxisFault(e.getMessage(), cause);
        } else {
            f = new org.apache.axis2.AxisFault(e.getMessage());
        }

        return f;
    }
} //end of class
