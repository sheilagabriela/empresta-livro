/**
 * GMPWebServicesCallbackHandler.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.9  Built on : Nov 16, 2018 (12:05:37 GMT)
 */
package org.tempuri;


/**
 *  GMPWebServicesCallbackHandler Callback class, Users can extend this class and implement
 *  their own receiveResult and receiveError methods.
 */
public abstract class GMPWebServicesCallbackHandler {
    protected Object clientData;

    /**
     * User can pass in any object that needs to be accessed once the NonBlocking
     * Web service call is finished and appropriate method of this CallBack is called.
     * @param clientData Object mechanism by which the user can pass in user data
     * that will be avilable at the time this callback is called.
     */
    public GMPWebServicesCallbackHandler(Object clientData) {
        this.clientData = clientData;
    }

    /**
     * Please use this constructor if you don't want to set any clientData
     */
    public GMPWebServicesCallbackHandler() {
        this.clientData = null;
    }

    /**
     * Get the client data
     */
    public Object getClientData() {
        return clientData;
    }

    /**
     * auto generated Axis2 call back method for consultaParceiroAgencia method
     * override this method for handling normal response from consultaParceiroAgencia operation
     */
    public void receiveResultconsultaParceiroAgencia(
        org.tempuri.ConsultaParceiroAgenciaResponseDocument result) {
    }

    /**
     * auto generated Axis2 Error handler
     * override this method for handling error response from consultaParceiroAgencia operation
     */
    public void receiveErrorconsultaParceiroAgencia(java.lang.Exception e) {
    }

    /**
     * auto generated Axis2 call back method for consultarDadosParceiro method
     * override this method for handling normal response from consultarDadosParceiro operation
     */
    public void receiveResultconsultarDadosParceiro(
        org.tempuri.ConsultarDadosParceiroResponseDocument result) {
    }

    /**
     * auto generated Axis2 Error handler
     * override this method for handling error response from consultarDadosParceiro operation
     */
    public void receiveErrorconsultarDadosParceiro(java.lang.Exception e) {
    }

    /**
     * auto generated Axis2 call back method for consultarDadosInstalacao method
     * override this method for handling normal response from consultarDadosInstalacao operation
     */
    public void receiveResultconsultarDadosInstalacao(
        org.tempuri.ConsultarDadosInstalacaoResponseDocument result) {
    }

    /**
     * auto generated Axis2 Error handler
     * override this method for handling error response from consultarDadosInstalacao operation
     */
    public void receiveErrorconsultarDadosInstalacao(java.lang.Exception e) {
    }

    /**
     * auto generated Axis2 call back method for cadastrarDoacao method
     * override this method for handling normal response from cadastrarDoacao operation
     */
    public void receiveResultcadastrarDoacao(
        org.tempuri.CadastrarDoacaoResponseDocument result) {
    }

    /**
     * auto generated Axis2 Error handler
     * override this method for handling error response from cadastrarDoacao operation
     */
    public void receiveErrorcadastrarDoacao(java.lang.Exception e) {
    }

    /**
     * auto generated Axis2 call back method for gerarProtocoloSimulacaoFintech method
     * override this method for handling normal response from gerarProtocoloSimulacaoFintech operation
     */
    public void receiveResultgerarProtocoloSimulacaoFintech(
        org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument result) {
    }

    /**
     * auto generated Axis2 Error handler
     * override this method for handling error response from gerarProtocoloSimulacaoFintech operation
     */
    public void receiveErrorgerarProtocoloSimulacaoFintech(
        java.lang.Exception e) {
    }

    /**
     * auto generated Axis2 call back method for consultarProdutoParceiro method
     * override this method for handling normal response from consultarProdutoParceiro operation
     */
    public void receiveResultconsultarProdutoParceiro(
        org.tempuri.ConsultarProdutoParceiroResponseDocument result) {
    }

    /**
     * auto generated Axis2 Error handler
     * override this method for handling error response from consultarProdutoParceiro operation
     */
    public void receiveErrorconsultarProdutoParceiro(java.lang.Exception e) {
    }

    /**
     * auto generated Axis2 call back method for excluirDoacao method
     * override this method for handling normal response from excluirDoacao operation
     */
    public void receiveResultexcluirDoacao(
        org.tempuri.ExcluirDoacaoResponseDocument result) {
    }

    /**
     * auto generated Axis2 Error handler
     * override this method for handling error response from excluirDoacao operation
     */
    public void receiveErrorexcluirDoacao(java.lang.Exception e) {
    }

    /**
     * auto generated Axis2 call back method for cadastrarCliente method
     * override this method for handling normal response from cadastrarCliente operation
     */
    public void receiveResultcadastrarCliente(
        org.tempuri.CadastrarClienteResponseDocument result) {
    }

    /**
     * auto generated Axis2 Error handler
     * override this method for handling error response from cadastrarCliente operation
     */
    public void receiveErrorcadastrarCliente(java.lang.Exception e) {
    }

    /**
     * auto generated Axis2 call back method for cadastrarCobrancaFintech method
     * override this method for handling normal response from cadastrarCobrancaFintech operation
     */
    public void receiveResultcadastrarCobrancaFintech(
        org.tempuri.CadastrarCobrancaFintechResponseDocument result) {
    }

    /**
     * auto generated Axis2 Error handler
     * override this method for handling error response from cadastrarCobrancaFintech operation
     */
    public void receiveErrorcadastrarCobrancaFintech(java.lang.Exception e) {
    }

    /**
     * auto generated Axis2 call back method for cadastrarCobranca method
     * override this method for handling normal response from cadastrarCobranca operation
     */
    public void receiveResultcadastrarCobranca(
        org.tempuri.CadastrarCobrancaResponseDocument result) {
    }

    /**
     * auto generated Axis2 Error handler
     * override this method for handling error response from cadastrarCobranca operation
     */
    public void receiveErrorcadastrarCobranca(java.lang.Exception e) {
    }

    /**
     * auto generated Axis2 call back method for enviarNotificacaoSMS method
     * override this method for handling normal response from enviarNotificacaoSMS operation
     */
    public void receiveResultenviarNotificacaoSMS(
        org.tempuri.EnviarNotificacaoSMSResponseDocument result) {
    }

    /**
     * auto generated Axis2 Error handler
     * override this method for handling error response from enviarNotificacaoSMS operation
     */
    public void receiveErrorenviarNotificacaoSMS(java.lang.Exception e) {
    }

    /**
     * auto generated Axis2 call back method for validarConsulta method
     * override this method for handling normal response from validarConsulta operation
     */
    public void receiveResultvalidarConsulta(
        org.tempuri.ValidarConsultaResponseDocument result) {
    }

    /**
     * auto generated Axis2 Error handler
     * override this method for handling error response from validarConsulta operation
     */
    public void receiveErrorvalidarConsulta(java.lang.Exception e) {
    }

    /**
     * auto generated Axis2 call back method for consultarDadosFatura method
     * override this method for handling normal response from consultarDadosFatura operation
     */
    public void receiveResultconsultarDadosFatura(
        org.tempuri.ConsultarDadosFaturaResponseDocument result) {
    }

    /**
     * auto generated Axis2 Error handler
     * override this method for handling error response from consultarDadosFatura operation
     */
    public void receiveErrorconsultarDadosFatura(java.lang.Exception e) {
    }

    /**
     * auto generated Axis2 call back method for excluirCobranca method
     * override this method for handling normal response from excluirCobranca operation
     */
    public void receiveResultexcluirCobranca(
        org.tempuri.ExcluirCobrancaResponseDocument result) {
    }

    /**
     * auto generated Axis2 Error handler
     * override this method for handling error response from excluirCobranca operation
     */
    public void receiveErrorexcluirCobranca(java.lang.Exception e) {
    }
}
