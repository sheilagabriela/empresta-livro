/*
 * An XML document type.
 * Localname: CadastrarClienteResponse
 * Namespace: http://tempuri.org/
 * Java type: org.tempuri.CadastrarClienteResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tempuri;


/**
 * A document containing one CadastrarClienteResponse(@http://tempuri.org/) element.
 *
 * This is a complex type.
 */
public interface CadastrarClienteResponseDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CadastrarClienteResponseDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3965ADB232D1D9A0AB9A333DE5AD2A31").resolveHandle("cadastrarclienteresponse8480doctype");
    
    /**
     * Gets the "CadastrarClienteResponse" element
     */
    org.tempuri.CadastrarClienteResponseDocument.CadastrarClienteResponse getCadastrarClienteResponse();
    
    /**
     * Sets the "CadastrarClienteResponse" element
     */
    void setCadastrarClienteResponse(org.tempuri.CadastrarClienteResponseDocument.CadastrarClienteResponse cadastrarClienteResponse);
    
    /**
     * Appends and returns a new empty "CadastrarClienteResponse" element
     */
    org.tempuri.CadastrarClienteResponseDocument.CadastrarClienteResponse addNewCadastrarClienteResponse();
    
    /**
     * An XML CadastrarClienteResponse(@http://tempuri.org/).
     *
     * This is a complex type.
     */
    public interface CadastrarClienteResponse extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CadastrarClienteResponse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3965ADB232D1D9A0AB9A333DE5AD2A31").resolveHandle("cadastrarclienteresponse6210elemtype");
        
        /**
         * Gets the "CadastrarClienteResult" element
         */
        org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO getCadastrarClienteResult();
        
        /**
         * Tests for nil "CadastrarClienteResult" element
         */
        boolean isNilCadastrarClienteResult();
        
        /**
         * True if has "CadastrarClienteResult" element
         */
        boolean isSetCadastrarClienteResult();
        
        /**
         * Sets the "CadastrarClienteResult" element
         */
        void setCadastrarClienteResult(org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO cadastrarClienteResult);
        
        /**
         * Appends and returns a new empty "CadastrarClienteResult" element
         */
        org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO addNewCadastrarClienteResult();
        
        /**
         * Nils the "CadastrarClienteResult" element
         */
        void setNilCadastrarClienteResult();
        
        /**
         * Unsets the "CadastrarClienteResult" element
         */
        void unsetCadastrarClienteResult();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tempuri.CadastrarClienteResponseDocument.CadastrarClienteResponse newInstance() {
              return (org.tempuri.CadastrarClienteResponseDocument.CadastrarClienteResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tempuri.CadastrarClienteResponseDocument.CadastrarClienteResponse newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tempuri.CadastrarClienteResponseDocument.CadastrarClienteResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tempuri.CadastrarClienteResponseDocument newInstance() {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tempuri.CadastrarClienteResponseDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tempuri.CadastrarClienteResponseDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tempuri.CadastrarClienteResponseDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tempuri.CadastrarClienteResponseDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tempuri.CadastrarClienteResponseDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tempuri.CadastrarClienteResponseDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tempuri.CadastrarClienteResponseDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tempuri.CadastrarClienteResponseDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tempuri.CadastrarClienteResponseDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tempuri.CadastrarClienteResponseDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tempuri.CadastrarClienteResponseDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tempuri.CadastrarClienteResponseDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tempuri.CadastrarClienteResponseDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tempuri.CadastrarClienteResponseDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tempuri.CadastrarClienteResponseDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tempuri.CadastrarClienteResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tempuri.CadastrarClienteResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tempuri.CadastrarClienteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
