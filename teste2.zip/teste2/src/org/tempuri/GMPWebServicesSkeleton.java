/**
 * GMPWebServicesSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.9  Built on : Nov 16, 2018 (12:05:37 GMT)
 */
package org.tempuri;

/**
 *  GMPWebServicesSkeleton java skeleton for the axisService
 */
public class GMPWebServicesSkeleton implements GMPWebServicesSkeletonInterface {
    /**
     * Auto generated method signature
     *
     * @param consultaParceiroAgencia0
     * @return consultaParceiroAgenciaResponse1
     */
    public org.tempuri.ConsultaParceiroAgenciaResponseDocument consultaParceiroAgencia(
        org.tempuri.ConsultaParceiroAgenciaDocument consultaParceiroAgencia0) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#consultaParceiroAgencia");
    }

    /**
     * Auto generated method signature
     *
     * @param consultarDadosParceiro2
     * @return consultarDadosParceiroResponse3
     */
    public org.tempuri.ConsultarDadosParceiroResponseDocument consultarDadosParceiro(
        org.tempuri.ConsultarDadosParceiroDocument consultarDadosParceiro2) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#consultarDadosParceiro");
    }

    /**
     * Auto generated method signature
     *
     * @param consultarDadosInstalacao4
     * @return consultarDadosInstalacaoResponse5
     */
    public org.tempuri.ConsultarDadosInstalacaoResponseDocument consultarDadosInstalacao(
        org.tempuri.ConsultarDadosInstalacaoDocument consultarDadosInstalacao4) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#consultarDadosInstalacao");
    }

    /**
     * Auto generated method signature
     *
     * @param cadastrarDoacao6
     * @return cadastrarDoacaoResponse7
     */
    public org.tempuri.CadastrarDoacaoResponseDocument cadastrarDoacao(
        org.tempuri.CadastrarDoacaoDocument cadastrarDoacao6) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#cadastrarDoacao");
    }

    /**
     * Auto generated method signature
     *
     * @param gerarProtocoloSimulacaoFintech8
     * @return gerarProtocoloSimulacaoFintechResponse9
     */
    public org.tempuri.GerarProtocoloSimulacaoFintechResponseDocument gerarProtocoloSimulacaoFintech(
        org.tempuri.GerarProtocoloSimulacaoFintechDocument gerarProtocoloSimulacaoFintech8) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#gerarProtocoloSimulacaoFintech");
    }

    /**
     * Auto generated method signature
     *
     * @param consultarProdutoParceiro10
     * @return consultarProdutoParceiroResponse11
     */
    public org.tempuri.ConsultarProdutoParceiroResponseDocument consultarProdutoParceiro(
        org.tempuri.ConsultarProdutoParceiroDocument consultarProdutoParceiro10) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#consultarProdutoParceiro");
    }

    /**
     * Auto generated method signature
     *
     * @param excluirDoacao12
     * @return excluirDoacaoResponse13
     */
    public org.tempuri.ExcluirDoacaoResponseDocument excluirDoacao(
        org.tempuri.ExcluirDoacaoDocument excluirDoacao12) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#excluirDoacao");
    }

    /**
     * Auto generated method signature
     *
     * @param cadastrarCliente14
     * @return cadastrarClienteResponse15
     */
    public org.tempuri.CadastrarClienteResponseDocument cadastrarCliente(
        org.tempuri.CadastrarClienteDocument cadastrarCliente14) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#cadastrarCliente");
    }

    /**
     * Auto generated method signature
     *
     * @param cadastrarCobrancaFintech16
     * @return cadastrarCobrancaFintechResponse17
     */
    public org.tempuri.CadastrarCobrancaFintechResponseDocument cadastrarCobrancaFintech(
        org.tempuri.CadastrarCobrancaFintechDocument cadastrarCobrancaFintech16) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#cadastrarCobrancaFintech");
    }

    /**
     * Auto generated method signature
     *
     * @param cadastrarCobranca18
     * @return cadastrarCobrancaResponse19
     */
    public org.tempuri.CadastrarCobrancaResponseDocument cadastrarCobranca(
        org.tempuri.CadastrarCobrancaDocument cadastrarCobranca18) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#cadastrarCobranca");
    }

    /**
     * Auto generated method signature
     *
     * @param enviarNotificacaoSMS20
     * @return enviarNotificacaoSMSResponse21
     */
    public org.tempuri.EnviarNotificacaoSMSResponseDocument enviarNotificacaoSMS(
        org.tempuri.EnviarNotificacaoSMSDocument enviarNotificacaoSMS20) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#enviarNotificacaoSMS");
    }

    /**
     * Auto generated method signature
     *
     * @param validarConsulta22
     * @return validarConsultaResponse23
     */
    public org.tempuri.ValidarConsultaResponseDocument validarConsulta(
        org.tempuri.ValidarConsultaDocument validarConsulta22) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#validarConsulta");
    }

    /**
     * Auto generated method signature
     *
     * @param consultarDadosFatura24
     * @return consultarDadosFaturaResponse25
     */
    public org.tempuri.ConsultarDadosFaturaResponseDocument consultarDadosFatura(
        org.tempuri.ConsultarDadosFaturaDocument consultarDadosFatura24) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#consultarDadosFatura");
    }

    /**
     * Auto generated method signature
     *
     * @param excluirCobranca26
     * @return excluirCobrancaResponse27
     */
    public org.tempuri.ExcluirCobrancaResponseDocument excluirCobranca(
        org.tempuri.ExcluirCobrancaDocument excluirCobranca26) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#excluirCobranca");
    }
}
