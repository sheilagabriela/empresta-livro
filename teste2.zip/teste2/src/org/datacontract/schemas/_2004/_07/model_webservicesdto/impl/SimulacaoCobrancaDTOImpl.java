/*
 * XML Type:  SimulacaoCobrancaDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML SimulacaoCobrancaDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class SimulacaoCobrancaDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.ServiceRequestPaiDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO
{
    private static final long serialVersionUID = 1L;
    
    public SimulacaoCobrancaDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INFOSIMULACAO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "InfoSimulacao");
    private static final javax.xml.namespace.QName INSTALACAO$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Instalacao");
    private static final javax.xml.namespace.QName PN$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "PN");
    private static final javax.xml.namespace.QName PRODUTO$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Produto");
    
    
    /**
     * Gets the "InfoSimulacao" element
     */
    public java.lang.String getInfoSimulacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INFOSIMULACAO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "InfoSimulacao" element
     */
    public org.apache.xmlbeans.XmlString xgetInfoSimulacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INFOSIMULACAO$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "InfoSimulacao" element
     */
    public boolean isNilInfoSimulacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INFOSIMULACAO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "InfoSimulacao" element
     */
    public boolean isSetInfoSimulacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INFOSIMULACAO$0) != 0;
        }
    }
    
    /**
     * Sets the "InfoSimulacao" element
     */
    public void setInfoSimulacao(java.lang.String infoSimulacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INFOSIMULACAO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INFOSIMULACAO$0);
            }
            target.setStringValue(infoSimulacao);
        }
    }
    
    /**
     * Sets (as xml) the "InfoSimulacao" element
     */
    public void xsetInfoSimulacao(org.apache.xmlbeans.XmlString infoSimulacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INFOSIMULACAO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INFOSIMULACAO$0);
            }
            target.set(infoSimulacao);
        }
    }
    
    /**
     * Nils the "InfoSimulacao" element
     */
    public void setNilInfoSimulacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INFOSIMULACAO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INFOSIMULACAO$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "InfoSimulacao" element
     */
    public void unsetInfoSimulacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INFOSIMULACAO$0, 0);
        }
    }
    
    /**
     * Gets the "Instalacao" element
     */
    public java.lang.String getInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALACAO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Instalacao" element
     */
    public org.apache.xmlbeans.XmlString xgetInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Instalacao" element
     */
    public boolean isNilInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Instalacao" element
     */
    public boolean isSetInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INSTALACAO$2) != 0;
        }
    }
    
    /**
     * Sets the "Instalacao" element
     */
    public void setInstalacao(java.lang.String instalacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALACAO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSTALACAO$2);
            }
            target.setStringValue(instalacao);
        }
    }
    
    /**
     * Sets (as xml) the "Instalacao" element
     */
    public void xsetInstalacao(org.apache.xmlbeans.XmlString instalacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INSTALACAO$2);
            }
            target.set(instalacao);
        }
    }
    
    /**
     * Nils the "Instalacao" element
     */
    public void setNilInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INSTALACAO$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Instalacao" element
     */
    public void unsetInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INSTALACAO$2, 0);
        }
    }
    
    /**
     * Gets the "PN" element
     */
    public java.lang.String getPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PN$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "PN" element
     */
    public org.apache.xmlbeans.XmlString xgetPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "PN" element
     */
    public boolean isNilPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "PN" element
     */
    public boolean isSetPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PN$4) != 0;
        }
    }
    
    /**
     * Sets the "PN" element
     */
    public void setPN(java.lang.String pn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PN$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PN$4);
            }
            target.setStringValue(pn);
        }
    }
    
    /**
     * Sets (as xml) the "PN" element
     */
    public void xsetPN(org.apache.xmlbeans.XmlString pn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PN$4);
            }
            target.set(pn);
        }
    }
    
    /**
     * Nils the "PN" element
     */
    public void setNilPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PN$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "PN" element
     */
    public void unsetPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PN$4, 0);
        }
    }
    
    /**
     * Gets the "Produto" element
     */
    public java.lang.String getProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRODUTO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Produto" element
     */
    public org.apache.xmlbeans.XmlString xgetProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PRODUTO$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Produto" element
     */
    public boolean isNilProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PRODUTO$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Produto" element
     */
    public boolean isSetProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRODUTO$6) != 0;
        }
    }
    
    /**
     * Sets the "Produto" element
     */
    public void setProduto(java.lang.String produto)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRODUTO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PRODUTO$6);
            }
            target.setStringValue(produto);
        }
    }
    
    /**
     * Sets (as xml) the "Produto" element
     */
    public void xsetProduto(org.apache.xmlbeans.XmlString produto)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PRODUTO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PRODUTO$6);
            }
            target.set(produto);
        }
    }
    
    /**
     * Nils the "Produto" element
     */
    public void setNilProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PRODUTO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PRODUTO$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Produto" element
     */
    public void unsetProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRODUTO$6, 0);
        }
    }
}
