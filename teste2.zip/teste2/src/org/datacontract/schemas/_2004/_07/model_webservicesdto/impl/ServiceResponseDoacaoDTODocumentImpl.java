/*
 * An XML document type.
 * Localname: ServiceResponseDoacaoDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one ServiceResponseDoacaoDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class ServiceResponseDoacaoDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public ServiceResponseDoacaoDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICERESPONSEDOACAODTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ServiceResponseDoacaoDTO");
    
    
    /**
     * Gets the "ServiceResponseDoacaoDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO getServiceResponseDoacaoDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO)get_store().find_element_user(SERVICERESPONSEDOACAODTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ServiceResponseDoacaoDTO" element
     */
    public boolean isNilServiceResponseDoacaoDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO)get_store().find_element_user(SERVICERESPONSEDOACAODTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ServiceResponseDoacaoDTO" element
     */
    public void setServiceResponseDoacaoDTO(org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO serviceResponseDoacaoDTO)
    {
        generatedSetterHelperImpl(serviceResponseDoacaoDTO, SERVICERESPONSEDOACAODTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ServiceResponseDoacaoDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO addNewServiceResponseDoacaoDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO)get_store().add_element_user(SERVICERESPONSEDOACAODTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "ServiceResponseDoacaoDTO" element
     */
    public void setNilServiceResponseDoacaoDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO)get_store().find_element_user(SERVICERESPONSEDOACAODTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO)get_store().add_element_user(SERVICERESPONSEDOACAODTO$0);
            }
            target.setNil();
        }
    }
}
