/*
 * XML Type:  ServiceResponseDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ServiceResponseDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ServiceResponseDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.ServiceResponsePaiDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO
{
    private static final long serialVersionUID = 1L;
    
    public ServiceResponseDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
