/*
 * XML Type:  CadastroDoacaoDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML CadastroDoacaoDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class CadastroDoacaoDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.CobrancaDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO
{
    private static final long serialVersionUID = 1L;
    
    public CadastroDoacaoDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CPF$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "CPF");
    private static final javax.xml.namespace.QName CODDISTRIBUIDORA$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "CodDistribuidora");
    private static final javax.xml.namespace.QName DATANASCIMENTO$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "DataNascimento");
    private static final javax.xml.namespace.QName EMAIL$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Email");
    private static final javax.xml.namespace.QName NOMEANEXO$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "NomeAnexo");
    private static final javax.xml.namespace.QName RG$10 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "RG");
    private static final javax.xml.namespace.QName TELEFONECELULAR$12 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "TelefoneCelular");
    private static final javax.xml.namespace.QName TELEFONEFIXO$14 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "TelefoneFixo");
    private static final javax.xml.namespace.QName TERMOCONFIRMACAO$16 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "TermoConfirmacao");
    private static final javax.xml.namespace.QName VALOR$18 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Valor");
    
    
    /**
     * Gets the "CPF" element
     */
    public java.lang.String getCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CPF" element
     */
    public org.apache.xmlbeans.XmlString xgetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPF$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CPF" element
     */
    public boolean isNilCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPF$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CPF" element
     */
    public boolean isSetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPF$0) != 0;
        }
    }
    
    /**
     * Sets the "CPF" element
     */
    public void setCPF(java.lang.String cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPF$0);
            }
            target.setStringValue(cpf);
        }
    }
    
    /**
     * Sets (as xml) the "CPF" element
     */
    public void xsetCPF(org.apache.xmlbeans.XmlString cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPF$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CPF$0);
            }
            target.set(cpf);
        }
    }
    
    /**
     * Nils the "CPF" element
     */
    public void setNilCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPF$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CPF$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CPF" element
     */
    public void unsetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPF$0, 0);
        }
    }
    
    /**
     * Gets the "CodDistribuidora" element
     */
    public java.lang.String getCodDistribuidora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODDISTRIBUIDORA$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodDistribuidora" element
     */
    public org.apache.xmlbeans.XmlString xgetCodDistribuidora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODDISTRIBUIDORA$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodDistribuidora" element
     */
    public boolean isNilCodDistribuidora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODDISTRIBUIDORA$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodDistribuidora" element
     */
    public boolean isSetCodDistribuidora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODDISTRIBUIDORA$2) != 0;
        }
    }
    
    /**
     * Sets the "CodDistribuidora" element
     */
    public void setCodDistribuidora(java.lang.String codDistribuidora)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODDISTRIBUIDORA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODDISTRIBUIDORA$2);
            }
            target.setStringValue(codDistribuidora);
        }
    }
    
    /**
     * Sets (as xml) the "CodDistribuidora" element
     */
    public void xsetCodDistribuidora(org.apache.xmlbeans.XmlString codDistribuidora)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODDISTRIBUIDORA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODDISTRIBUIDORA$2);
            }
            target.set(codDistribuidora);
        }
    }
    
    /**
     * Nils the "CodDistribuidora" element
     */
    public void setNilCodDistribuidora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODDISTRIBUIDORA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODDISTRIBUIDORA$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodDistribuidora" element
     */
    public void unsetCodDistribuidora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODDISTRIBUIDORA$2, 0);
        }
    }
    
    /**
     * Gets the "DataNascimento" element
     */
    public java.lang.String getDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATANASCIMENTO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataNascimento" element
     */
    public org.apache.xmlbeans.XmlString xgetDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATANASCIMENTO$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataNascimento" element
     */
    public boolean isNilDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATANASCIMENTO$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataNascimento" element
     */
    public boolean isSetDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATANASCIMENTO$4) != 0;
        }
    }
    
    /**
     * Sets the "DataNascimento" element
     */
    public void setDataNascimento(java.lang.String dataNascimento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATANASCIMENTO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATANASCIMENTO$4);
            }
            target.setStringValue(dataNascimento);
        }
    }
    
    /**
     * Sets (as xml) the "DataNascimento" element
     */
    public void xsetDataNascimento(org.apache.xmlbeans.XmlString dataNascimento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATANASCIMENTO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATANASCIMENTO$4);
            }
            target.set(dataNascimento);
        }
    }
    
    /**
     * Nils the "DataNascimento" element
     */
    public void setNilDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATANASCIMENTO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATANASCIMENTO$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataNascimento" element
     */
    public void unsetDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATANASCIMENTO$4, 0);
        }
    }
    
    /**
     * Gets the "Email" element
     */
    public java.lang.String getEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Email" element
     */
    public org.apache.xmlbeans.XmlString xgetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EMAIL$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Email" element
     */
    public boolean isNilEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EMAIL$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Email" element
     */
    public boolean isSetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EMAIL$6) != 0;
        }
    }
    
    /**
     * Sets the "Email" element
     */
    public void setEmail(java.lang.String email)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EMAIL$6);
            }
            target.setStringValue(email);
        }
    }
    
    /**
     * Sets (as xml) the "Email" element
     */
    public void xsetEmail(org.apache.xmlbeans.XmlString email)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EMAIL$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EMAIL$6);
            }
            target.set(email);
        }
    }
    
    /**
     * Nils the "Email" element
     */
    public void setNilEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EMAIL$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EMAIL$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Email" element
     */
    public void unsetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EMAIL$6, 0);
        }
    }
    
    /**
     * Gets the "NomeAnexo" element
     */
    public java.lang.String getNomeAnexo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMEANEXO$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NomeAnexo" element
     */
    public org.apache.xmlbeans.XmlString xgetNomeAnexo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEANEXO$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "NomeAnexo" element
     */
    public boolean isNilNomeAnexo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEANEXO$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NomeAnexo" element
     */
    public boolean isSetNomeAnexo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOMEANEXO$8) != 0;
        }
    }
    
    /**
     * Sets the "NomeAnexo" element
     */
    public void setNomeAnexo(java.lang.String nomeAnexo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMEANEXO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOMEANEXO$8);
            }
            target.setStringValue(nomeAnexo);
        }
    }
    
    /**
     * Sets (as xml) the "NomeAnexo" element
     */
    public void xsetNomeAnexo(org.apache.xmlbeans.XmlString nomeAnexo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEANEXO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMEANEXO$8);
            }
            target.set(nomeAnexo);
        }
    }
    
    /**
     * Nils the "NomeAnexo" element
     */
    public void setNilNomeAnexo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEANEXO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMEANEXO$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NomeAnexo" element
     */
    public void unsetNomeAnexo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOMEANEXO$8, 0);
        }
    }
    
    /**
     * Gets the "RG" element
     */
    public java.lang.String getRG()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RG$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "RG" element
     */
    public org.apache.xmlbeans.XmlString xgetRG()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RG$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "RG" element
     */
    public boolean isNilRG()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RG$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "RG" element
     */
    public boolean isSetRG()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RG$10) != 0;
        }
    }
    
    /**
     * Sets the "RG" element
     */
    public void setRG(java.lang.String rg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RG$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RG$10);
            }
            target.setStringValue(rg);
        }
    }
    
    /**
     * Sets (as xml) the "RG" element
     */
    public void xsetRG(org.apache.xmlbeans.XmlString rg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RG$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RG$10);
            }
            target.set(rg);
        }
    }
    
    /**
     * Nils the "RG" element
     */
    public void setNilRG()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RG$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RG$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "RG" element
     */
    public void unsetRG()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RG$10, 0);
        }
    }
    
    /**
     * Gets the "TelefoneCelular" element
     */
    public java.lang.String getTelefoneCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TELEFONECELULAR$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "TelefoneCelular" element
     */
    public org.apache.xmlbeans.XmlString xgetTelefoneCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONECELULAR$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "TelefoneCelular" element
     */
    public boolean isNilTelefoneCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONECELULAR$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "TelefoneCelular" element
     */
    public boolean isSetTelefoneCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TELEFONECELULAR$12) != 0;
        }
    }
    
    /**
     * Sets the "TelefoneCelular" element
     */
    public void setTelefoneCelular(java.lang.String telefoneCelular)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TELEFONECELULAR$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TELEFONECELULAR$12);
            }
            target.setStringValue(telefoneCelular);
        }
    }
    
    /**
     * Sets (as xml) the "TelefoneCelular" element
     */
    public void xsetTelefoneCelular(org.apache.xmlbeans.XmlString telefoneCelular)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONECELULAR$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TELEFONECELULAR$12);
            }
            target.set(telefoneCelular);
        }
    }
    
    /**
     * Nils the "TelefoneCelular" element
     */
    public void setNilTelefoneCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONECELULAR$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TELEFONECELULAR$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "TelefoneCelular" element
     */
    public void unsetTelefoneCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TELEFONECELULAR$12, 0);
        }
    }
    
    /**
     * Gets the "TelefoneFixo" element
     */
    public java.lang.String getTelefoneFixo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TELEFONEFIXO$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "TelefoneFixo" element
     */
    public org.apache.xmlbeans.XmlString xgetTelefoneFixo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONEFIXO$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "TelefoneFixo" element
     */
    public boolean isNilTelefoneFixo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONEFIXO$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "TelefoneFixo" element
     */
    public boolean isSetTelefoneFixo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TELEFONEFIXO$14) != 0;
        }
    }
    
    /**
     * Sets the "TelefoneFixo" element
     */
    public void setTelefoneFixo(java.lang.String telefoneFixo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TELEFONEFIXO$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TELEFONEFIXO$14);
            }
            target.setStringValue(telefoneFixo);
        }
    }
    
    /**
     * Sets (as xml) the "TelefoneFixo" element
     */
    public void xsetTelefoneFixo(org.apache.xmlbeans.XmlString telefoneFixo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONEFIXO$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TELEFONEFIXO$14);
            }
            target.set(telefoneFixo);
        }
    }
    
    /**
     * Nils the "TelefoneFixo" element
     */
    public void setNilTelefoneFixo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONEFIXO$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TELEFONEFIXO$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "TelefoneFixo" element
     */
    public void unsetTelefoneFixo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TELEFONEFIXO$14, 0);
        }
    }
    
    /**
     * Gets the "TermoConfirmacao" element
     */
    public java.lang.String getTermoConfirmacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TERMOCONFIRMACAO$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "TermoConfirmacao" element
     */
    public org.apache.xmlbeans.XmlString xgetTermoConfirmacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TERMOCONFIRMACAO$16, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "TermoConfirmacao" element
     */
    public boolean isNilTermoConfirmacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TERMOCONFIRMACAO$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "TermoConfirmacao" element
     */
    public boolean isSetTermoConfirmacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TERMOCONFIRMACAO$16) != 0;
        }
    }
    
    /**
     * Sets the "TermoConfirmacao" element
     */
    public void setTermoConfirmacao(java.lang.String termoConfirmacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TERMOCONFIRMACAO$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TERMOCONFIRMACAO$16);
            }
            target.setStringValue(termoConfirmacao);
        }
    }
    
    /**
     * Sets (as xml) the "TermoConfirmacao" element
     */
    public void xsetTermoConfirmacao(org.apache.xmlbeans.XmlString termoConfirmacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TERMOCONFIRMACAO$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TERMOCONFIRMACAO$16);
            }
            target.set(termoConfirmacao);
        }
    }
    
    /**
     * Nils the "TermoConfirmacao" element
     */
    public void setNilTermoConfirmacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TERMOCONFIRMACAO$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TERMOCONFIRMACAO$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "TermoConfirmacao" element
     */
    public void unsetTermoConfirmacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TERMOCONFIRMACAO$16, 0);
        }
    }
    
    /**
     * Gets the "Valor" element
     */
    public java.lang.String getValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALOR$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Valor" element
     */
    public org.apache.xmlbeans.XmlString xgetValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALOR$18, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Valor" element
     */
    public boolean isNilValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALOR$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Valor" element
     */
    public boolean isSetValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALOR$18) != 0;
        }
    }
    
    /**
     * Sets the "Valor" element
     */
    public void setValor(java.lang.String valor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALOR$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALOR$18);
            }
            target.setStringValue(valor);
        }
    }
    
    /**
     * Sets (as xml) the "Valor" element
     */
    public void xsetValor(org.apache.xmlbeans.XmlString valor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALOR$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VALOR$18);
            }
            target.set(valor);
        }
    }
    
    /**
     * Nils the "Valor" element
     */
    public void setNilValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALOR$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VALOR$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Valor" element
     */
    public void unsetValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALOR$18, 0);
        }
    }
}
