/*
 * XML Type:  CadastroClienteDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto;


/**
 * An XML CadastroClienteDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public interface CadastroClienteDTO extends org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CadastroClienteDTO.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3965ADB232D1D9A0AB9A333DE5AD2A31").resolveHandle("cadastroclientedtoe735type");
    
    /**
     * Gets the "CNPJ" element
     */
    java.lang.String getCNPJ();
    
    /**
     * Gets (as xml) the "CNPJ" element
     */
    org.apache.xmlbeans.XmlString xgetCNPJ();
    
    /**
     * Tests for nil "CNPJ" element
     */
    boolean isNilCNPJ();
    
    /**
     * True if has "CNPJ" element
     */
    boolean isSetCNPJ();
    
    /**
     * Sets the "CNPJ" element
     */
    void setCNPJ(java.lang.String cnpj);
    
    /**
     * Sets (as xml) the "CNPJ" element
     */
    void xsetCNPJ(org.apache.xmlbeans.XmlString cnpj);
    
    /**
     * Nils the "CNPJ" element
     */
    void setNilCNPJ();
    
    /**
     * Unsets the "CNPJ" element
     */
    void unsetCNPJ();
    
    /**
     * Gets the "CPF" element
     */
    java.lang.String getCPF();
    
    /**
     * Gets (as xml) the "CPF" element
     */
    org.apache.xmlbeans.XmlString xgetCPF();
    
    /**
     * Tests for nil "CPF" element
     */
    boolean isNilCPF();
    
    /**
     * True if has "CPF" element
     */
    boolean isSetCPF();
    
    /**
     * Sets the "CPF" element
     */
    void setCPF(java.lang.String cpf);
    
    /**
     * Sets (as xml) the "CPF" element
     */
    void xsetCPF(org.apache.xmlbeans.XmlString cpf);
    
    /**
     * Nils the "CPF" element
     */
    void setNilCPF();
    
    /**
     * Unsets the "CPF" element
     */
    void unsetCPF();
    
    /**
     * Gets the "CPFConjuge" element
     */
    java.lang.String getCPFConjuge();
    
    /**
     * Gets (as xml) the "CPFConjuge" element
     */
    org.apache.xmlbeans.XmlString xgetCPFConjuge();
    
    /**
     * Tests for nil "CPFConjuge" element
     */
    boolean isNilCPFConjuge();
    
    /**
     * True if has "CPFConjuge" element
     */
    boolean isSetCPFConjuge();
    
    /**
     * Sets the "CPFConjuge" element
     */
    void setCPFConjuge(java.lang.String cpfConjuge);
    
    /**
     * Sets (as xml) the "CPFConjuge" element
     */
    void xsetCPFConjuge(org.apache.xmlbeans.XmlString cpfConjuge);
    
    /**
     * Nils the "CPFConjuge" element
     */
    void setNilCPFConjuge();
    
    /**
     * Unsets the "CPFConjuge" element
     */
    void unsetCPFConjuge();
    
    /**
     * Gets the "CpfResponsavel" element
     */
    java.lang.String getCpfResponsavel();
    
    /**
     * Gets (as xml) the "CpfResponsavel" element
     */
    org.apache.xmlbeans.XmlString xgetCpfResponsavel();
    
    /**
     * Tests for nil "CpfResponsavel" element
     */
    boolean isNilCpfResponsavel();
    
    /**
     * True if has "CpfResponsavel" element
     */
    boolean isSetCpfResponsavel();
    
    /**
     * Sets the "CpfResponsavel" element
     */
    void setCpfResponsavel(java.lang.String cpfResponsavel);
    
    /**
     * Sets (as xml) the "CpfResponsavel" element
     */
    void xsetCpfResponsavel(org.apache.xmlbeans.XmlString cpfResponsavel);
    
    /**
     * Nils the "CpfResponsavel" element
     */
    void setNilCpfResponsavel();
    
    /**
     * Unsets the "CpfResponsavel" element
     */
    void unsetCpfResponsavel();
    
    /**
     * Gets the "DataAbertura" element
     */
    java.lang.String getDataAbertura();
    
    /**
     * Gets (as xml) the "DataAbertura" element
     */
    org.apache.xmlbeans.XmlString xgetDataAbertura();
    
    /**
     * Tests for nil "DataAbertura" element
     */
    boolean isNilDataAbertura();
    
    /**
     * True if has "DataAbertura" element
     */
    boolean isSetDataAbertura();
    
    /**
     * Sets the "DataAbertura" element
     */
    void setDataAbertura(java.lang.String dataAbertura);
    
    /**
     * Sets (as xml) the "DataAbertura" element
     */
    void xsetDataAbertura(org.apache.xmlbeans.XmlString dataAbertura);
    
    /**
     * Nils the "DataAbertura" element
     */
    void setNilDataAbertura();
    
    /**
     * Unsets the "DataAbertura" element
     */
    void unsetDataAbertura();
    
    /**
     * Gets the "DataNascimento" element
     */
    java.lang.String getDataNascimento();
    
    /**
     * Gets (as xml) the "DataNascimento" element
     */
    org.apache.xmlbeans.XmlString xgetDataNascimento();
    
    /**
     * Tests for nil "DataNascimento" element
     */
    boolean isNilDataNascimento();
    
    /**
     * True if has "DataNascimento" element
     */
    boolean isSetDataNascimento();
    
    /**
     * Sets the "DataNascimento" element
     */
    void setDataNascimento(java.lang.String dataNascimento);
    
    /**
     * Sets (as xml) the "DataNascimento" element
     */
    void xsetDataNascimento(org.apache.xmlbeans.XmlString dataNascimento);
    
    /**
     * Nils the "DataNascimento" element
     */
    void setNilDataNascimento();
    
    /**
     * Unsets the "DataNascimento" element
     */
    void unsetDataNascimento();
    
    /**
     * Gets the "Email" element
     */
    java.lang.String getEmail();
    
    /**
     * Gets (as xml) the "Email" element
     */
    org.apache.xmlbeans.XmlString xgetEmail();
    
    /**
     * Tests for nil "Email" element
     */
    boolean isNilEmail();
    
    /**
     * True if has "Email" element
     */
    boolean isSetEmail();
    
    /**
     * Sets the "Email" element
     */
    void setEmail(java.lang.String email);
    
    /**
     * Sets (as xml) the "Email" element
     */
    void xsetEmail(org.apache.xmlbeans.XmlString email);
    
    /**
     * Nils the "Email" element
     */
    void setNilEmail();
    
    /**
     * Unsets the "Email" element
     */
    void unsetEmail();
    
    /**
     * Gets the "InscricaoEstadual" element
     */
    java.lang.String getInscricaoEstadual();
    
    /**
     * Gets (as xml) the "InscricaoEstadual" element
     */
    org.apache.xmlbeans.XmlString xgetInscricaoEstadual();
    
    /**
     * Tests for nil "InscricaoEstadual" element
     */
    boolean isNilInscricaoEstadual();
    
    /**
     * True if has "InscricaoEstadual" element
     */
    boolean isSetInscricaoEstadual();
    
    /**
     * Sets the "InscricaoEstadual" element
     */
    void setInscricaoEstadual(java.lang.String inscricaoEstadual);
    
    /**
     * Sets (as xml) the "InscricaoEstadual" element
     */
    void xsetInscricaoEstadual(org.apache.xmlbeans.XmlString inscricaoEstadual);
    
    /**
     * Nils the "InscricaoEstadual" element
     */
    void setNilInscricaoEstadual();
    
    /**
     * Unsets the "InscricaoEstadual" element
     */
    void unsetInscricaoEstadual();
    
    /**
     * Gets the "Instalacao" element
     */
    java.lang.String getInstalacao();
    
    /**
     * Gets (as xml) the "Instalacao" element
     */
    org.apache.xmlbeans.XmlString xgetInstalacao();
    
    /**
     * Tests for nil "Instalacao" element
     */
    boolean isNilInstalacao();
    
    /**
     * Sets the "Instalacao" element
     */
    void setInstalacao(java.lang.String instalacao);
    
    /**
     * Sets (as xml) the "Instalacao" element
     */
    void xsetInstalacao(org.apache.xmlbeans.XmlString instalacao);
    
    /**
     * Nils the "Instalacao" element
     */
    void setNilInstalacao();
    
    /**
     * Gets the "NomeConjuge" element
     */
    java.lang.String getNomeConjuge();
    
    /**
     * Gets (as xml) the "NomeConjuge" element
     */
    org.apache.xmlbeans.XmlString xgetNomeConjuge();
    
    /**
     * Tests for nil "NomeConjuge" element
     */
    boolean isNilNomeConjuge();
    
    /**
     * True if has "NomeConjuge" element
     */
    boolean isSetNomeConjuge();
    
    /**
     * Sets the "NomeConjuge" element
     */
    void setNomeConjuge(java.lang.String nomeConjuge);
    
    /**
     * Sets (as xml) the "NomeConjuge" element
     */
    void xsetNomeConjuge(org.apache.xmlbeans.XmlString nomeConjuge);
    
    /**
     * Nils the "NomeConjuge" element
     */
    void setNilNomeConjuge();
    
    /**
     * Unsets the "NomeConjuge" element
     */
    void unsetNomeConjuge();
    
    /**
     * Gets the "NomeContato" element
     */
    java.lang.String getNomeContato();
    
    /**
     * Gets (as xml) the "NomeContato" element
     */
    org.apache.xmlbeans.XmlString xgetNomeContato();
    
    /**
     * Tests for nil "NomeContato" element
     */
    boolean isNilNomeContato();
    
    /**
     * True if has "NomeContato" element
     */
    boolean isSetNomeContato();
    
    /**
     * Sets the "NomeContato" element
     */
    void setNomeContato(java.lang.String nomeContato);
    
    /**
     * Sets (as xml) the "NomeContato" element
     */
    void xsetNomeContato(org.apache.xmlbeans.XmlString nomeContato);
    
    /**
     * Nils the "NomeContato" element
     */
    void setNilNomeContato();
    
    /**
     * Unsets the "NomeContato" element
     */
    void unsetNomeContato();
    
    /**
     * Gets the "NomeResponsavel" element
     */
    java.lang.String getNomeResponsavel();
    
    /**
     * Gets (as xml) the "NomeResponsavel" element
     */
    org.apache.xmlbeans.XmlString xgetNomeResponsavel();
    
    /**
     * Tests for nil "NomeResponsavel" element
     */
    boolean isNilNomeResponsavel();
    
    /**
     * True if has "NomeResponsavel" element
     */
    boolean isSetNomeResponsavel();
    
    /**
     * Sets the "NomeResponsavel" element
     */
    void setNomeResponsavel(java.lang.String nomeResponsavel);
    
    /**
     * Sets (as xml) the "NomeResponsavel" element
     */
    void xsetNomeResponsavel(org.apache.xmlbeans.XmlString nomeResponsavel);
    
    /**
     * Nils the "NomeResponsavel" element
     */
    void setNilNomeResponsavel();
    
    /**
     * Unsets the "NomeResponsavel" element
     */
    void unsetNomeResponsavel();
    
    /**
     * Gets the "Operacao" element
     */
    int getOperacao();
    
    /**
     * Gets (as xml) the "Operacao" element
     */
    org.apache.xmlbeans.XmlInt xgetOperacao();
    
    /**
     * Sets the "Operacao" element
     */
    void setOperacao(int operacao);
    
    /**
     * Sets (as xml) the "Operacao" element
     */
    void xsetOperacao(org.apache.xmlbeans.XmlInt operacao);
    
    /**
     * Gets the "PF_PJ" element
     */
    int getPFPJ();
    
    /**
     * Gets (as xml) the "PF_PJ" element
     */
    org.apache.xmlbeans.XmlInt xgetPFPJ();
    
    /**
     * Sets the "PF_PJ" element
     */
    void setPFPJ(int pfpj);
    
    /**
     * Sets (as xml) the "PF_PJ" element
     */
    void xsetPFPJ(org.apache.xmlbeans.XmlInt pfpj);
    
    /**
     * Gets the "PN" element
     */
    java.lang.String getPN();
    
    /**
     * Gets (as xml) the "PN" element
     */
    org.apache.xmlbeans.XmlString xgetPN();
    
    /**
     * Tests for nil "PN" element
     */
    boolean isNilPN();
    
    /**
     * Sets the "PN" element
     */
    void setPN(java.lang.String pn);
    
    /**
     * Sets (as xml) the "PN" element
     */
    void xsetPN(org.apache.xmlbeans.XmlString pn);
    
    /**
     * Nils the "PN" element
     */
    void setNilPN();
    
    /**
     * Gets the "RG" element
     */
    java.lang.String getRG();
    
    /**
     * Gets (as xml) the "RG" element
     */
    org.apache.xmlbeans.XmlString xgetRG();
    
    /**
     * Tests for nil "RG" element
     */
    boolean isNilRG();
    
    /**
     * True if has "RG" element
     */
    boolean isSetRG();
    
    /**
     * Sets the "RG" element
     */
    void setRG(java.lang.String rg);
    
    /**
     * Sets (as xml) the "RG" element
     */
    void xsetRG(org.apache.xmlbeans.XmlString rg);
    
    /**
     * Nils the "RG" element
     */
    void setNilRG();
    
    /**
     * Unsets the "RG" element
     */
    void unsetRG();
    
    /**
     * Gets the "RGConjuge" element
     */
    java.lang.String getRGConjuge();
    
    /**
     * Gets (as xml) the "RGConjuge" element
     */
    org.apache.xmlbeans.XmlString xgetRGConjuge();
    
    /**
     * Tests for nil "RGConjuge" element
     */
    boolean isNilRGConjuge();
    
    /**
     * True if has "RGConjuge" element
     */
    boolean isSetRGConjuge();
    
    /**
     * Sets the "RGConjuge" element
     */
    void setRGConjuge(java.lang.String rgConjuge);
    
    /**
     * Sets (as xml) the "RGConjuge" element
     */
    void xsetRGConjuge(org.apache.xmlbeans.XmlString rgConjuge);
    
    /**
     * Nils the "RGConjuge" element
     */
    void setNilRGConjuge();
    
    /**
     * Unsets the "RGConjuge" element
     */
    void unsetRGConjuge();
    
    /**
     * Gets the "RgResponsavel" element
     */
    java.lang.String getRgResponsavel();
    
    /**
     * Gets (as xml) the "RgResponsavel" element
     */
    org.apache.xmlbeans.XmlString xgetRgResponsavel();
    
    /**
     * Tests for nil "RgResponsavel" element
     */
    boolean isNilRgResponsavel();
    
    /**
     * True if has "RgResponsavel" element
     */
    boolean isSetRgResponsavel();
    
    /**
     * Sets the "RgResponsavel" element
     */
    void setRgResponsavel(java.lang.String rgResponsavel);
    
    /**
     * Sets (as xml) the "RgResponsavel" element
     */
    void xsetRgResponsavel(org.apache.xmlbeans.XmlString rgResponsavel);
    
    /**
     * Nils the "RgResponsavel" element
     */
    void setNilRgResponsavel();
    
    /**
     * Unsets the "RgResponsavel" element
     */
    void unsetRgResponsavel();
    
    /**
     * Gets the "TelefoneCelular" element
     */
    java.lang.String getTelefoneCelular();
    
    /**
     * Gets (as xml) the "TelefoneCelular" element
     */
    org.apache.xmlbeans.XmlString xgetTelefoneCelular();
    
    /**
     * Tests for nil "TelefoneCelular" element
     */
    boolean isNilTelefoneCelular();
    
    /**
     * True if has "TelefoneCelular" element
     */
    boolean isSetTelefoneCelular();
    
    /**
     * Sets the "TelefoneCelular" element
     */
    void setTelefoneCelular(java.lang.String telefoneCelular);
    
    /**
     * Sets (as xml) the "TelefoneCelular" element
     */
    void xsetTelefoneCelular(org.apache.xmlbeans.XmlString telefoneCelular);
    
    /**
     * Nils the "TelefoneCelular" element
     */
    void setNilTelefoneCelular();
    
    /**
     * Unsets the "TelefoneCelular" element
     */
    void unsetTelefoneCelular();
    
    /**
     * Gets the "TelefoneContato" element
     */
    java.lang.String getTelefoneContato();
    
    /**
     * Gets (as xml) the "TelefoneContato" element
     */
    org.apache.xmlbeans.XmlString xgetTelefoneContato();
    
    /**
     * Tests for nil "TelefoneContato" element
     */
    boolean isNilTelefoneContato();
    
    /**
     * True if has "TelefoneContato" element
     */
    boolean isSetTelefoneContato();
    
    /**
     * Sets the "TelefoneContato" element
     */
    void setTelefoneContato(java.lang.String telefoneContato);
    
    /**
     * Sets (as xml) the "TelefoneContato" element
     */
    void xsetTelefoneContato(org.apache.xmlbeans.XmlString telefoneContato);
    
    /**
     * Nils the "TelefoneContato" element
     */
    void setNilTelefoneContato();
    
    /**
     * Unsets the "TelefoneContato" element
     */
    void unsetTelefoneContato();
    
    /**
     * Gets the "TelefoneFixo" element
     */
    java.lang.String getTelefoneFixo();
    
    /**
     * Gets (as xml) the "TelefoneFixo" element
     */
    org.apache.xmlbeans.XmlString xgetTelefoneFixo();
    
    /**
     * Tests for nil "TelefoneFixo" element
     */
    boolean isNilTelefoneFixo();
    
    /**
     * True if has "TelefoneFixo" element
     */
    boolean isSetTelefoneFixo();
    
    /**
     * Sets the "TelefoneFixo" element
     */
    void setTelefoneFixo(java.lang.String telefoneFixo);
    
    /**
     * Sets (as xml) the "TelefoneFixo" element
     */
    void xsetTelefoneFixo(org.apache.xmlbeans.XmlString telefoneFixo);
    
    /**
     * Nils the "TelefoneFixo" element
     */
    void setNilTelefoneFixo();
    
    /**
     * Unsets the "TelefoneFixo" element
     */
    void unsetTelefoneFixo();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO newInstance() {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
