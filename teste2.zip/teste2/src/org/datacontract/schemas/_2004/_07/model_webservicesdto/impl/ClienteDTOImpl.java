/*
 * XML Type:  ClienteDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ClienteDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ClienteDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.ServiceResponsePaiDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO
{
    private static final long serialVersionUID = 1L;
    
    public ClienteDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName BAIRRO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Bairro");
    private static final javax.xml.namespace.QName CEP$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Cep");
    private static final javax.xml.namespace.QName CIDADE$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Cidade");
    private static final javax.xml.namespace.QName COMPLEMENTO$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Complemento");
    private static final javax.xml.namespace.QName DATAINCLUSAOCADASTRO$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "DataInclusaoCadastro");
    private static final javax.xml.namespace.QName LOGRADOURO$10 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Logradouro");
    private static final javax.xml.namespace.QName NOME$12 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Nome");
    private static final javax.xml.namespace.QName NUMERO$14 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Numero");
    private static final javax.xml.namespace.QName PN$16 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "PN");
    private static final javax.xml.namespace.QName PRODUTOS$18 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Produtos");
    private static final javax.xml.namespace.QName UF$20 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Uf");
    
    
    /**
     * Gets the "Bairro" element
     */
    public java.lang.String getBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BAIRRO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Bairro" element
     */
    public org.apache.xmlbeans.XmlString xgetBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BAIRRO$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Bairro" element
     */
    public boolean isNilBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BAIRRO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Bairro" element
     */
    public boolean isSetBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(BAIRRO$0) != 0;
        }
    }
    
    /**
     * Sets the "Bairro" element
     */
    public void setBairro(java.lang.String bairro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BAIRRO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(BAIRRO$0);
            }
            target.setStringValue(bairro);
        }
    }
    
    /**
     * Sets (as xml) the "Bairro" element
     */
    public void xsetBairro(org.apache.xmlbeans.XmlString bairro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BAIRRO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(BAIRRO$0);
            }
            target.set(bairro);
        }
    }
    
    /**
     * Nils the "Bairro" element
     */
    public void setNilBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BAIRRO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(BAIRRO$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Bairro" element
     */
    public void unsetBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(BAIRRO$0, 0);
        }
    }
    
    /**
     * Gets the "Cep" element
     */
    public java.lang.String getCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Cep" element
     */
    public org.apache.xmlbeans.XmlString xgetCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CEP$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Cep" element
     */
    public boolean isNilCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CEP$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Cep" element
     */
    public boolean isSetCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CEP$2) != 0;
        }
    }
    
    /**
     * Sets the "Cep" element
     */
    public void setCep(java.lang.String cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CEP$2);
            }
            target.setStringValue(cep);
        }
    }
    
    /**
     * Sets (as xml) the "Cep" element
     */
    public void xsetCep(org.apache.xmlbeans.XmlString cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CEP$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CEP$2);
            }
            target.set(cep);
        }
    }
    
    /**
     * Nils the "Cep" element
     */
    public void setNilCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CEP$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CEP$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Cep" element
     */
    public void unsetCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CEP$2, 0);
        }
    }
    
    /**
     * Gets the "Cidade" element
     */
    public java.lang.String getCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CIDADE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Cidade" element
     */
    public org.apache.xmlbeans.XmlString xgetCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CIDADE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Cidade" element
     */
    public boolean isNilCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CIDADE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Cidade" element
     */
    public boolean isSetCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CIDADE$4) != 0;
        }
    }
    
    /**
     * Sets the "Cidade" element
     */
    public void setCidade(java.lang.String cidade)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CIDADE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CIDADE$4);
            }
            target.setStringValue(cidade);
        }
    }
    
    /**
     * Sets (as xml) the "Cidade" element
     */
    public void xsetCidade(org.apache.xmlbeans.XmlString cidade)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CIDADE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CIDADE$4);
            }
            target.set(cidade);
        }
    }
    
    /**
     * Nils the "Cidade" element
     */
    public void setNilCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CIDADE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CIDADE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Cidade" element
     */
    public void unsetCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CIDADE$4, 0);
        }
    }
    
    /**
     * Gets the "Complemento" element
     */
    public java.lang.String getComplemento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMPLEMENTO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Complemento" element
     */
    public org.apache.xmlbeans.XmlString xgetComplemento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(COMPLEMENTO$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Complemento" element
     */
    public boolean isNilComplemento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(COMPLEMENTO$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Complemento" element
     */
    public boolean isSetComplemento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(COMPLEMENTO$6) != 0;
        }
    }
    
    /**
     * Sets the "Complemento" element
     */
    public void setComplemento(java.lang.String complemento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMPLEMENTO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(COMPLEMENTO$6);
            }
            target.setStringValue(complemento);
        }
    }
    
    /**
     * Sets (as xml) the "Complemento" element
     */
    public void xsetComplemento(org.apache.xmlbeans.XmlString complemento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(COMPLEMENTO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(COMPLEMENTO$6);
            }
            target.set(complemento);
        }
    }
    
    /**
     * Nils the "Complemento" element
     */
    public void setNilComplemento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(COMPLEMENTO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(COMPLEMENTO$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Complemento" element
     */
    public void unsetComplemento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(COMPLEMENTO$6, 0);
        }
    }
    
    /**
     * Gets the "DataInclusaoCadastro" element
     */
    public java.lang.String getDataInclusaoCadastro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAINCLUSAOCADASTRO$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataInclusaoCadastro" element
     */
    public org.apache.xmlbeans.XmlString xgetDataInclusaoCadastro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAINCLUSAOCADASTRO$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataInclusaoCadastro" element
     */
    public boolean isNilDataInclusaoCadastro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAINCLUSAOCADASTRO$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataInclusaoCadastro" element
     */
    public boolean isSetDataInclusaoCadastro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATAINCLUSAOCADASTRO$8) != 0;
        }
    }
    
    /**
     * Sets the "DataInclusaoCadastro" element
     */
    public void setDataInclusaoCadastro(java.lang.String dataInclusaoCadastro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAINCLUSAOCADASTRO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAINCLUSAOCADASTRO$8);
            }
            target.setStringValue(dataInclusaoCadastro);
        }
    }
    
    /**
     * Sets (as xml) the "DataInclusaoCadastro" element
     */
    public void xsetDataInclusaoCadastro(org.apache.xmlbeans.XmlString dataInclusaoCadastro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAINCLUSAOCADASTRO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATAINCLUSAOCADASTRO$8);
            }
            target.set(dataInclusaoCadastro);
        }
    }
    
    /**
     * Nils the "DataInclusaoCadastro" element
     */
    public void setNilDataInclusaoCadastro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAINCLUSAOCADASTRO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATAINCLUSAOCADASTRO$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataInclusaoCadastro" element
     */
    public void unsetDataInclusaoCadastro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATAINCLUSAOCADASTRO$8, 0);
        }
    }
    
    /**
     * Gets the "Logradouro" element
     */
    public java.lang.String getLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LOGRADOURO$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Logradouro" element
     */
    public org.apache.xmlbeans.XmlString xgetLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(LOGRADOURO$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Logradouro" element
     */
    public boolean isNilLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(LOGRADOURO$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Logradouro" element
     */
    public boolean isSetLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LOGRADOURO$10) != 0;
        }
    }
    
    /**
     * Sets the "Logradouro" element
     */
    public void setLogradouro(java.lang.String logradouro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LOGRADOURO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(LOGRADOURO$10);
            }
            target.setStringValue(logradouro);
        }
    }
    
    /**
     * Sets (as xml) the "Logradouro" element
     */
    public void xsetLogradouro(org.apache.xmlbeans.XmlString logradouro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(LOGRADOURO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(LOGRADOURO$10);
            }
            target.set(logradouro);
        }
    }
    
    /**
     * Nils the "Logradouro" element
     */
    public void setNilLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(LOGRADOURO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(LOGRADOURO$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Logradouro" element
     */
    public void unsetLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LOGRADOURO$10, 0);
        }
    }
    
    /**
     * Gets the "Nome" element
     */
    public java.lang.String getNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOME$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Nome" element
     */
    public org.apache.xmlbeans.XmlString xgetNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOME$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Nome" element
     */
    public boolean isNilNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOME$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Nome" element
     */
    public boolean isSetNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOME$12) != 0;
        }
    }
    
    /**
     * Sets the "Nome" element
     */
    public void setNome(java.lang.String nome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOME$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOME$12);
            }
            target.setStringValue(nome);
        }
    }
    
    /**
     * Sets (as xml) the "Nome" element
     */
    public void xsetNome(org.apache.xmlbeans.XmlString nome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOME$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOME$12);
            }
            target.set(nome);
        }
    }
    
    /**
     * Nils the "Nome" element
     */
    public void setNilNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOME$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOME$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Nome" element
     */
    public void unsetNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOME$12, 0);
        }
    }
    
    /**
     * Gets the "Numero" element
     */
    public java.lang.String getNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERO$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Numero" element
     */
    public org.apache.xmlbeans.XmlString xgetNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMERO$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Numero" element
     */
    public boolean isNilNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMERO$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Numero" element
     */
    public boolean isSetNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMERO$14) != 0;
        }
    }
    
    /**
     * Sets the "Numero" element
     */
    public void setNumero(java.lang.String numero)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERO$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMERO$14);
            }
            target.setStringValue(numero);
        }
    }
    
    /**
     * Sets (as xml) the "Numero" element
     */
    public void xsetNumero(org.apache.xmlbeans.XmlString numero)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMERO$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMERO$14);
            }
            target.set(numero);
        }
    }
    
    /**
     * Nils the "Numero" element
     */
    public void setNilNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMERO$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMERO$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Numero" element
     */
    public void unsetNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMERO$14, 0);
        }
    }
    
    /**
     * Gets the "PN" element
     */
    public java.lang.String getPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PN$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "PN" element
     */
    public org.apache.xmlbeans.XmlString xgetPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$16, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "PN" element
     */
    public boolean isNilPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "PN" element
     */
    public boolean isSetPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PN$16) != 0;
        }
    }
    
    /**
     * Sets the "PN" element
     */
    public void setPN(java.lang.String pn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PN$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PN$16);
            }
            target.setStringValue(pn);
        }
    }
    
    /**
     * Sets (as xml) the "PN" element
     */
    public void xsetPN(org.apache.xmlbeans.XmlString pn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PN$16);
            }
            target.set(pn);
        }
    }
    
    /**
     * Nils the "PN" element
     */
    public void setNilPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PN$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "PN" element
     */
    public void unsetPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PN$16, 0);
        }
    }
    
    /**
     * Gets the "Produtos" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO getProdutos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO)get_store().find_element_user(PRODUTOS$18, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Produtos" element
     */
    public boolean isNilProdutos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO)get_store().find_element_user(PRODUTOS$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Produtos" element
     */
    public boolean isSetProdutos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRODUTOS$18) != 0;
        }
    }
    
    /**
     * Sets the "Produtos" element
     */
    public void setProdutos(org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO produtos)
    {
        generatedSetterHelperImpl(produtos, PRODUTOS$18, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Produtos" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO addNewProdutos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO)get_store().add_element_user(PRODUTOS$18);
            return target;
        }
    }
    
    /**
     * Nils the "Produtos" element
     */
    public void setNilProdutos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO)get_store().find_element_user(PRODUTOS$18, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO)get_store().add_element_user(PRODUTOS$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Produtos" element
     */
    public void unsetProdutos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRODUTOS$18, 0);
        }
    }
    
    /**
     * Gets the "Uf" element
     */
    public java.lang.String getUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UF$20, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Uf" element
     */
    public org.apache.xmlbeans.XmlString xgetUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(UF$20, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Uf" element
     */
    public boolean isNilUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(UF$20, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Uf" element
     */
    public boolean isSetUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(UF$20) != 0;
        }
    }
    
    /**
     * Sets the "Uf" element
     */
    public void setUf(java.lang.String uf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UF$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(UF$20);
            }
            target.setStringValue(uf);
        }
    }
    
    /**
     * Sets (as xml) the "Uf" element
     */
    public void xsetUf(org.apache.xmlbeans.XmlString uf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(UF$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(UF$20);
            }
            target.set(uf);
        }
    }
    
    /**
     * Nils the "Uf" element
     */
    public void setNilUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(UF$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(UF$20);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Uf" element
     */
    public void unsetUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(UF$20, 0);
        }
    }
}
