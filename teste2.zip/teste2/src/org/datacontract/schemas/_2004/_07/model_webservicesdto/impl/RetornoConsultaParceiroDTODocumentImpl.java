/*
 * An XML document type.
 * Localname: RetornoConsultaParceiroDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one RetornoConsultaParceiroDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class RetornoConsultaParceiroDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public RetornoConsultaParceiroDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RETORNOCONSULTAPARCEIRODTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "RetornoConsultaParceiroDTO");
    
    
    /**
     * Gets the "RetornoConsultaParceiroDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO getRetornoConsultaParceiroDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO)get_store().find_element_user(RETORNOCONSULTAPARCEIRODTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "RetornoConsultaParceiroDTO" element
     */
    public boolean isNilRetornoConsultaParceiroDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO)get_store().find_element_user(RETORNOCONSULTAPARCEIRODTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "RetornoConsultaParceiroDTO" element
     */
    public void setRetornoConsultaParceiroDTO(org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO retornoConsultaParceiroDTO)
    {
        generatedSetterHelperImpl(retornoConsultaParceiroDTO, RETORNOCONSULTAPARCEIRODTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "RetornoConsultaParceiroDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO addNewRetornoConsultaParceiroDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO)get_store().add_element_user(RETORNOCONSULTAPARCEIRODTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "RetornoConsultaParceiroDTO" element
     */
    public void setNilRetornoConsultaParceiroDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO)get_store().find_element_user(RETORNOCONSULTAPARCEIRODTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO)get_store().add_element_user(RETORNOCONSULTAPARCEIRODTO$0);
            }
            target.setNil();
        }
    }
}
