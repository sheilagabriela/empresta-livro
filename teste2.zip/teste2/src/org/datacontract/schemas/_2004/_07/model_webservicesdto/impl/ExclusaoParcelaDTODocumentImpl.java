/*
 * An XML document type.
 * Localname: ExclusaoParcelaDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one ExclusaoParcelaDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class ExclusaoParcelaDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public ExclusaoParcelaDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EXCLUSAOPARCELADTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ExclusaoParcelaDTO");
    
    
    /**
     * Gets the "ExclusaoParcelaDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO getExclusaoParcelaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO)get_store().find_element_user(EXCLUSAOPARCELADTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ExclusaoParcelaDTO" element
     */
    public boolean isNilExclusaoParcelaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO)get_store().find_element_user(EXCLUSAOPARCELADTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ExclusaoParcelaDTO" element
     */
    public void setExclusaoParcelaDTO(org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO exclusaoParcelaDTO)
    {
        generatedSetterHelperImpl(exclusaoParcelaDTO, EXCLUSAOPARCELADTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ExclusaoParcelaDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO addNewExclusaoParcelaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO)get_store().add_element_user(EXCLUSAOPARCELADTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "ExclusaoParcelaDTO" element
     */
    public void setNilExclusaoParcelaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO)get_store().find_element_user(EXCLUSAOPARCELADTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO)get_store().add_element_user(EXCLUSAOPARCELADTO$0);
            }
            target.setNil();
        }
    }
}
