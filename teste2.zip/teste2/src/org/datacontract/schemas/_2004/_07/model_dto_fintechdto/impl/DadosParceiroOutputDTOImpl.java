/*
 * XML Type:  DadosParceiroOutputDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * An XML DadosParceiroOutputDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public class DadosParceiroOutputDTOImpl extends org.datacontract.schemas._2004._07.model_dto_fintechdto.impl.FintechBaseDTOImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO
{
    private static final long serialVersionUID = 1L;
    
    public DadosParceiroOutputDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CNAE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "CNAE");
    private static final javax.xml.namespace.QName CELULAR$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Celular");
    private static final javax.xml.namespace.QName CODTIPOPESSOA$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "CodTipoPessoa");
    private static final javax.xml.namespace.QName DATANASCIMENTO$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DataNascimento");
    private static final javax.xml.namespace.QName EMAIL$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Email");
    private static final javax.xml.namespace.QName NOME$10 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Nome");
    private static final javax.xml.namespace.QName NOMEFANTASIA$12 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "NomeFantasia");
    private static final javax.xml.namespace.QName NUMERODOCUMENTO$14 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "NumeroDocumento");
    private static final javax.xml.namespace.QName RAZAOSOCIAL1$16 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "RazaoSocial1");
    private static final javax.xml.namespace.QName RAZAOSOCIAL2$18 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "RazaoSocial2");
    private static final javax.xml.namespace.QName SOBRENOME$20 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Sobrenome");
    private static final javax.xml.namespace.QName TELEFONE$22 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Telefone");
    private static final javax.xml.namespace.QName TIPODOCUMENTO$24 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "TipoDocumento");
    
    
    /**
     * Gets the "CNAE" element
     */
    public java.lang.String getCNAE()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNAE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CNAE" element
     */
    public org.apache.xmlbeans.XmlString xgetCNAE()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNAE$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CNAE" element
     */
    public boolean isNilCNAE()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNAE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CNAE" element
     */
    public boolean isSetCNAE()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CNAE$0) != 0;
        }
    }
    
    /**
     * Sets the "CNAE" element
     */
    public void setCNAE(java.lang.String cnae)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNAE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CNAE$0);
            }
            target.setStringValue(cnae);
        }
    }
    
    /**
     * Sets (as xml) the "CNAE" element
     */
    public void xsetCNAE(org.apache.xmlbeans.XmlString cnae)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNAE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CNAE$0);
            }
            target.set(cnae);
        }
    }
    
    /**
     * Nils the "CNAE" element
     */
    public void setNilCNAE()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNAE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CNAE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CNAE" element
     */
    public void unsetCNAE()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CNAE$0, 0);
        }
    }
    
    /**
     * Gets the "Celular" element
     */
    public java.lang.String getCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CELULAR$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Celular" element
     */
    public org.apache.xmlbeans.XmlString xgetCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CELULAR$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Celular" element
     */
    public boolean isNilCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CELULAR$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Celular" element
     */
    public boolean isSetCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CELULAR$2) != 0;
        }
    }
    
    /**
     * Sets the "Celular" element
     */
    public void setCelular(java.lang.String celular)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CELULAR$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CELULAR$2);
            }
            target.setStringValue(celular);
        }
    }
    
    /**
     * Sets (as xml) the "Celular" element
     */
    public void xsetCelular(org.apache.xmlbeans.XmlString celular)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CELULAR$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CELULAR$2);
            }
            target.set(celular);
        }
    }
    
    /**
     * Nils the "Celular" element
     */
    public void setNilCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CELULAR$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CELULAR$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Celular" element
     */
    public void unsetCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CELULAR$2, 0);
        }
    }
    
    /**
     * Gets the "CodTipoPessoa" element
     */
    public java.lang.String getCodTipoPessoa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODTIPOPESSOA$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodTipoPessoa" element
     */
    public org.apache.xmlbeans.XmlString xgetCodTipoPessoa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODTIPOPESSOA$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodTipoPessoa" element
     */
    public boolean isNilCodTipoPessoa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODTIPOPESSOA$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodTipoPessoa" element
     */
    public boolean isSetCodTipoPessoa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODTIPOPESSOA$4) != 0;
        }
    }
    
    /**
     * Sets the "CodTipoPessoa" element
     */
    public void setCodTipoPessoa(java.lang.String codTipoPessoa)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODTIPOPESSOA$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODTIPOPESSOA$4);
            }
            target.setStringValue(codTipoPessoa);
        }
    }
    
    /**
     * Sets (as xml) the "CodTipoPessoa" element
     */
    public void xsetCodTipoPessoa(org.apache.xmlbeans.XmlString codTipoPessoa)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODTIPOPESSOA$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODTIPOPESSOA$4);
            }
            target.set(codTipoPessoa);
        }
    }
    
    /**
     * Nils the "CodTipoPessoa" element
     */
    public void setNilCodTipoPessoa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODTIPOPESSOA$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODTIPOPESSOA$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodTipoPessoa" element
     */
    public void unsetCodTipoPessoa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODTIPOPESSOA$4, 0);
        }
    }
    
    /**
     * Gets the "DataNascimento" element
     */
    public java.util.Calendar getDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATANASCIMENTO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataNascimento" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATANASCIMENTO$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataNascimento" element
     */
    public boolean isNilDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATANASCIMENTO$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataNascimento" element
     */
    public boolean isSetDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATANASCIMENTO$6) != 0;
        }
    }
    
    /**
     * Sets the "DataNascimento" element
     */
    public void setDataNascimento(java.util.Calendar dataNascimento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATANASCIMENTO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATANASCIMENTO$6);
            }
            target.setCalendarValue(dataNascimento);
        }
    }
    
    /**
     * Sets (as xml) the "DataNascimento" element
     */
    public void xsetDataNascimento(org.apache.xmlbeans.XmlDateTime dataNascimento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATANASCIMENTO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATANASCIMENTO$6);
            }
            target.set(dataNascimento);
        }
    }
    
    /**
     * Nils the "DataNascimento" element
     */
    public void setNilDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATANASCIMENTO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATANASCIMENTO$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataNascimento" element
     */
    public void unsetDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATANASCIMENTO$6, 0);
        }
    }
    
    /**
     * Gets the "Email" element
     */
    public java.lang.String getEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Email" element
     */
    public org.apache.xmlbeans.XmlString xgetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EMAIL$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Email" element
     */
    public boolean isNilEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EMAIL$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Email" element
     */
    public boolean isSetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EMAIL$8) != 0;
        }
    }
    
    /**
     * Sets the "Email" element
     */
    public void setEmail(java.lang.String email)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EMAIL$8);
            }
            target.setStringValue(email);
        }
    }
    
    /**
     * Sets (as xml) the "Email" element
     */
    public void xsetEmail(org.apache.xmlbeans.XmlString email)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EMAIL$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EMAIL$8);
            }
            target.set(email);
        }
    }
    
    /**
     * Nils the "Email" element
     */
    public void setNilEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EMAIL$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EMAIL$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Email" element
     */
    public void unsetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EMAIL$8, 0);
        }
    }
    
    /**
     * Gets the "Nome" element
     */
    public java.lang.String getNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOME$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Nome" element
     */
    public org.apache.xmlbeans.XmlString xgetNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOME$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Nome" element
     */
    public boolean isNilNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOME$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Nome" element
     */
    public boolean isSetNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOME$10) != 0;
        }
    }
    
    /**
     * Sets the "Nome" element
     */
    public void setNome(java.lang.String nome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOME$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOME$10);
            }
            target.setStringValue(nome);
        }
    }
    
    /**
     * Sets (as xml) the "Nome" element
     */
    public void xsetNome(org.apache.xmlbeans.XmlString nome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOME$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOME$10);
            }
            target.set(nome);
        }
    }
    
    /**
     * Nils the "Nome" element
     */
    public void setNilNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOME$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOME$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Nome" element
     */
    public void unsetNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOME$10, 0);
        }
    }
    
    /**
     * Gets the "NomeFantasia" element
     */
    public java.lang.String getNomeFantasia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMEFANTASIA$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NomeFantasia" element
     */
    public org.apache.xmlbeans.XmlString xgetNomeFantasia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEFANTASIA$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "NomeFantasia" element
     */
    public boolean isNilNomeFantasia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEFANTASIA$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NomeFantasia" element
     */
    public boolean isSetNomeFantasia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOMEFANTASIA$12) != 0;
        }
    }
    
    /**
     * Sets the "NomeFantasia" element
     */
    public void setNomeFantasia(java.lang.String nomeFantasia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMEFANTASIA$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOMEFANTASIA$12);
            }
            target.setStringValue(nomeFantasia);
        }
    }
    
    /**
     * Sets (as xml) the "NomeFantasia" element
     */
    public void xsetNomeFantasia(org.apache.xmlbeans.XmlString nomeFantasia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEFANTASIA$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMEFANTASIA$12);
            }
            target.set(nomeFantasia);
        }
    }
    
    /**
     * Nils the "NomeFantasia" element
     */
    public void setNilNomeFantasia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEFANTASIA$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMEFANTASIA$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NomeFantasia" element
     */
    public void unsetNomeFantasia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOMEFANTASIA$12, 0);
        }
    }
    
    /**
     * Gets the "NumeroDocumento" element
     */
    public java.lang.String getNumeroDocumento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERODOCUMENTO$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NumeroDocumento" element
     */
    public org.apache.xmlbeans.XmlString xgetNumeroDocumento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMERODOCUMENTO$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "NumeroDocumento" element
     */
    public boolean isNilNumeroDocumento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMERODOCUMENTO$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NumeroDocumento" element
     */
    public boolean isSetNumeroDocumento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMERODOCUMENTO$14) != 0;
        }
    }
    
    /**
     * Sets the "NumeroDocumento" element
     */
    public void setNumeroDocumento(java.lang.String numeroDocumento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERODOCUMENTO$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMERODOCUMENTO$14);
            }
            target.setStringValue(numeroDocumento);
        }
    }
    
    /**
     * Sets (as xml) the "NumeroDocumento" element
     */
    public void xsetNumeroDocumento(org.apache.xmlbeans.XmlString numeroDocumento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMERODOCUMENTO$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMERODOCUMENTO$14);
            }
            target.set(numeroDocumento);
        }
    }
    
    /**
     * Nils the "NumeroDocumento" element
     */
    public void setNilNumeroDocumento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMERODOCUMENTO$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMERODOCUMENTO$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NumeroDocumento" element
     */
    public void unsetNumeroDocumento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMERODOCUMENTO$14, 0);
        }
    }
    
    /**
     * Gets the "RazaoSocial1" element
     */
    public java.lang.String getRazaoSocial1()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RAZAOSOCIAL1$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "RazaoSocial1" element
     */
    public org.apache.xmlbeans.XmlString xgetRazaoSocial1()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RAZAOSOCIAL1$16, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "RazaoSocial1" element
     */
    public boolean isNilRazaoSocial1()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RAZAOSOCIAL1$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "RazaoSocial1" element
     */
    public boolean isSetRazaoSocial1()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RAZAOSOCIAL1$16) != 0;
        }
    }
    
    /**
     * Sets the "RazaoSocial1" element
     */
    public void setRazaoSocial1(java.lang.String razaoSocial1)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RAZAOSOCIAL1$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RAZAOSOCIAL1$16);
            }
            target.setStringValue(razaoSocial1);
        }
    }
    
    /**
     * Sets (as xml) the "RazaoSocial1" element
     */
    public void xsetRazaoSocial1(org.apache.xmlbeans.XmlString razaoSocial1)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RAZAOSOCIAL1$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RAZAOSOCIAL1$16);
            }
            target.set(razaoSocial1);
        }
    }
    
    /**
     * Nils the "RazaoSocial1" element
     */
    public void setNilRazaoSocial1()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RAZAOSOCIAL1$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RAZAOSOCIAL1$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "RazaoSocial1" element
     */
    public void unsetRazaoSocial1()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RAZAOSOCIAL1$16, 0);
        }
    }
    
    /**
     * Gets the "RazaoSocial2" element
     */
    public java.lang.String getRazaoSocial2()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RAZAOSOCIAL2$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "RazaoSocial2" element
     */
    public org.apache.xmlbeans.XmlString xgetRazaoSocial2()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RAZAOSOCIAL2$18, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "RazaoSocial2" element
     */
    public boolean isNilRazaoSocial2()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RAZAOSOCIAL2$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "RazaoSocial2" element
     */
    public boolean isSetRazaoSocial2()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RAZAOSOCIAL2$18) != 0;
        }
    }
    
    /**
     * Sets the "RazaoSocial2" element
     */
    public void setRazaoSocial2(java.lang.String razaoSocial2)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RAZAOSOCIAL2$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RAZAOSOCIAL2$18);
            }
            target.setStringValue(razaoSocial2);
        }
    }
    
    /**
     * Sets (as xml) the "RazaoSocial2" element
     */
    public void xsetRazaoSocial2(org.apache.xmlbeans.XmlString razaoSocial2)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RAZAOSOCIAL2$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RAZAOSOCIAL2$18);
            }
            target.set(razaoSocial2);
        }
    }
    
    /**
     * Nils the "RazaoSocial2" element
     */
    public void setNilRazaoSocial2()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RAZAOSOCIAL2$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RAZAOSOCIAL2$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "RazaoSocial2" element
     */
    public void unsetRazaoSocial2()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RAZAOSOCIAL2$18, 0);
        }
    }
    
    /**
     * Gets the "Sobrenome" element
     */
    public java.lang.String getSobrenome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SOBRENOME$20, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Sobrenome" element
     */
    public org.apache.xmlbeans.XmlString xgetSobrenome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SOBRENOME$20, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Sobrenome" element
     */
    public boolean isNilSobrenome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SOBRENOME$20, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Sobrenome" element
     */
    public boolean isSetSobrenome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SOBRENOME$20) != 0;
        }
    }
    
    /**
     * Sets the "Sobrenome" element
     */
    public void setSobrenome(java.lang.String sobrenome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SOBRENOME$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SOBRENOME$20);
            }
            target.setStringValue(sobrenome);
        }
    }
    
    /**
     * Sets (as xml) the "Sobrenome" element
     */
    public void xsetSobrenome(org.apache.xmlbeans.XmlString sobrenome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SOBRENOME$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SOBRENOME$20);
            }
            target.set(sobrenome);
        }
    }
    
    /**
     * Nils the "Sobrenome" element
     */
    public void setNilSobrenome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SOBRENOME$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SOBRENOME$20);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Sobrenome" element
     */
    public void unsetSobrenome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SOBRENOME$20, 0);
        }
    }
    
    /**
     * Gets the "Telefone" element
     */
    public java.lang.String getTelefone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TELEFONE$22, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Telefone" element
     */
    public org.apache.xmlbeans.XmlString xgetTelefone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONE$22, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Telefone" element
     */
    public boolean isNilTelefone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONE$22, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Telefone" element
     */
    public boolean isSetTelefone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TELEFONE$22) != 0;
        }
    }
    
    /**
     * Sets the "Telefone" element
     */
    public void setTelefone(java.lang.String telefone)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TELEFONE$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TELEFONE$22);
            }
            target.setStringValue(telefone);
        }
    }
    
    /**
     * Sets (as xml) the "Telefone" element
     */
    public void xsetTelefone(org.apache.xmlbeans.XmlString telefone)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONE$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TELEFONE$22);
            }
            target.set(telefone);
        }
    }
    
    /**
     * Nils the "Telefone" element
     */
    public void setNilTelefone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONE$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TELEFONE$22);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Telefone" element
     */
    public void unsetTelefone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TELEFONE$22, 0);
        }
    }
    
    /**
     * Gets the "TipoDocumento" element
     */
    public java.lang.String getTipoDocumento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIPODOCUMENTO$24, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "TipoDocumento" element
     */
    public org.apache.xmlbeans.XmlString xgetTipoDocumento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIPODOCUMENTO$24, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "TipoDocumento" element
     */
    public boolean isNilTipoDocumento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIPODOCUMENTO$24, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "TipoDocumento" element
     */
    public boolean isSetTipoDocumento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TIPODOCUMENTO$24) != 0;
        }
    }
    
    /**
     * Sets the "TipoDocumento" element
     */
    public void setTipoDocumento(java.lang.String tipoDocumento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIPODOCUMENTO$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TIPODOCUMENTO$24);
            }
            target.setStringValue(tipoDocumento);
        }
    }
    
    /**
     * Sets (as xml) the "TipoDocumento" element
     */
    public void xsetTipoDocumento(org.apache.xmlbeans.XmlString tipoDocumento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIPODOCUMENTO$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TIPODOCUMENTO$24);
            }
            target.set(tipoDocumento);
        }
    }
    
    /**
     * Nils the "TipoDocumento" element
     */
    public void setNilTipoDocumento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIPODOCUMENTO$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TIPODOCUMENTO$24);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "TipoDocumento" element
     */
    public void unsetTipoDocumento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TIPODOCUMENTO$24, 0);
        }
    }
}
