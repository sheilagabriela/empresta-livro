/*
 * An XML document type.
 * Localname: ExclusaoCobrancaDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one ExclusaoCobrancaDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class ExclusaoCobrancaDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public ExclusaoCobrancaDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EXCLUSAOCOBRANCADTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ExclusaoCobrancaDTO");
    
    
    /**
     * Gets the "ExclusaoCobrancaDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO getExclusaoCobrancaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO)get_store().find_element_user(EXCLUSAOCOBRANCADTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ExclusaoCobrancaDTO" element
     */
    public boolean isNilExclusaoCobrancaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO)get_store().find_element_user(EXCLUSAOCOBRANCADTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ExclusaoCobrancaDTO" element
     */
    public void setExclusaoCobrancaDTO(org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO exclusaoCobrancaDTO)
    {
        generatedSetterHelperImpl(exclusaoCobrancaDTO, EXCLUSAOCOBRANCADTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ExclusaoCobrancaDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO addNewExclusaoCobrancaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO)get_store().add_element_user(EXCLUSAOCOBRANCADTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "ExclusaoCobrancaDTO" element
     */
    public void setNilExclusaoCobrancaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO)get_store().find_element_user(EXCLUSAOCOBRANCADTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO)get_store().add_element_user(EXCLUSAOCOBRANCADTO$0);
            }
            target.setNil();
        }
    }
}
