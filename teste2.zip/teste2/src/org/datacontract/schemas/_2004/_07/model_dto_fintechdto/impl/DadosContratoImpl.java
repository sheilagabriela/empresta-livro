/*
 * XML Type:  DadosContrato
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * An XML DadosContrato(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public class DadosContratoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato
{
    private static final long serialVersionUID = 1L;
    
    public DadosContratoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CODEMPRESA$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "CodEmpresa");
    private static final javax.xml.namespace.QName CONTACONTRATO$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "ContaContrato");
    private static final javax.xml.namespace.QName DATADESLIGAMENTO$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DataDesligamento");
    private static final javax.xml.namespace.QName DATALIGACAO$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DataLigacao");
    private static final javax.xml.namespace.QName INSTALACAO$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Instalacao");
    private static final javax.xml.namespace.QName NOMEEMPRESA$10 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "NomeEmpresa");
    private static final javax.xml.namespace.QName PARCEIRO$12 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Parceiro");
    
    
    /**
     * Gets the "CodEmpresa" element
     */
    public java.lang.String getCodEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEMPRESA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodEmpresa" element
     */
    public org.apache.xmlbeans.XmlString xgetCodEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEMPRESA$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodEmpresa" element
     */
    public boolean isNilCodEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEMPRESA$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodEmpresa" element
     */
    public boolean isSetCodEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODEMPRESA$0) != 0;
        }
    }
    
    /**
     * Sets the "CodEmpresa" element
     */
    public void setCodEmpresa(java.lang.String codEmpresa)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEMPRESA$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODEMPRESA$0);
            }
            target.setStringValue(codEmpresa);
        }
    }
    
    /**
     * Sets (as xml) the "CodEmpresa" element
     */
    public void xsetCodEmpresa(org.apache.xmlbeans.XmlString codEmpresa)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEMPRESA$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEMPRESA$0);
            }
            target.set(codEmpresa);
        }
    }
    
    /**
     * Nils the "CodEmpresa" element
     */
    public void setNilCodEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEMPRESA$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEMPRESA$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodEmpresa" element
     */
    public void unsetCodEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODEMPRESA$0, 0);
        }
    }
    
    /**
     * Gets the "ContaContrato" element
     */
    public java.lang.String getContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTACONTRATO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ContaContrato" element
     */
    public org.apache.xmlbeans.XmlString xgetContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTACONTRATO$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ContaContrato" element
     */
    public boolean isNilContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTACONTRATO$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ContaContrato" element
     */
    public boolean isSetContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONTACONTRATO$2) != 0;
        }
    }
    
    /**
     * Sets the "ContaContrato" element
     */
    public void setContaContrato(java.lang.String contaContrato)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTACONTRATO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONTACONTRATO$2);
            }
            target.setStringValue(contaContrato);
        }
    }
    
    /**
     * Sets (as xml) the "ContaContrato" element
     */
    public void xsetContaContrato(org.apache.xmlbeans.XmlString contaContrato)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTACONTRATO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONTACONTRATO$2);
            }
            target.set(contaContrato);
        }
    }
    
    /**
     * Nils the "ContaContrato" element
     */
    public void setNilContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTACONTRATO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONTACONTRATO$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ContaContrato" element
     */
    public void unsetContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONTACONTRATO$2, 0);
        }
    }
    
    /**
     * Gets the "DataDesligamento" element
     */
    public java.util.Calendar getDataDesligamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATADESLIGAMENTO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataDesligamento" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetDataDesligamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATADESLIGAMENTO$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataDesligamento" element
     */
    public boolean isNilDataDesligamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATADESLIGAMENTO$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataDesligamento" element
     */
    public boolean isSetDataDesligamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATADESLIGAMENTO$4) != 0;
        }
    }
    
    /**
     * Sets the "DataDesligamento" element
     */
    public void setDataDesligamento(java.util.Calendar dataDesligamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATADESLIGAMENTO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATADESLIGAMENTO$4);
            }
            target.setCalendarValue(dataDesligamento);
        }
    }
    
    /**
     * Sets (as xml) the "DataDesligamento" element
     */
    public void xsetDataDesligamento(org.apache.xmlbeans.XmlDateTime dataDesligamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATADESLIGAMENTO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATADESLIGAMENTO$4);
            }
            target.set(dataDesligamento);
        }
    }
    
    /**
     * Nils the "DataDesligamento" element
     */
    public void setNilDataDesligamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATADESLIGAMENTO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATADESLIGAMENTO$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataDesligamento" element
     */
    public void unsetDataDesligamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATADESLIGAMENTO$4, 0);
        }
    }
    
    /**
     * Gets the "DataLigacao" element
     */
    public java.util.Calendar getDataLigacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATALIGACAO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataLigacao" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetDataLigacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATALIGACAO$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataLigacao" element
     */
    public boolean isNilDataLigacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATALIGACAO$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataLigacao" element
     */
    public boolean isSetDataLigacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATALIGACAO$6) != 0;
        }
    }
    
    /**
     * Sets the "DataLigacao" element
     */
    public void setDataLigacao(java.util.Calendar dataLigacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATALIGACAO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATALIGACAO$6);
            }
            target.setCalendarValue(dataLigacao);
        }
    }
    
    /**
     * Sets (as xml) the "DataLigacao" element
     */
    public void xsetDataLigacao(org.apache.xmlbeans.XmlDateTime dataLigacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATALIGACAO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATALIGACAO$6);
            }
            target.set(dataLigacao);
        }
    }
    
    /**
     * Nils the "DataLigacao" element
     */
    public void setNilDataLigacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATALIGACAO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATALIGACAO$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataLigacao" element
     */
    public void unsetDataLigacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATALIGACAO$6, 0);
        }
    }
    
    /**
     * Gets the "Instalacao" element
     */
    public java.lang.String getInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALACAO$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Instalacao" element
     */
    public org.apache.xmlbeans.XmlString xgetInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Instalacao" element
     */
    public boolean isNilInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Instalacao" element
     */
    public boolean isSetInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INSTALACAO$8) != 0;
        }
    }
    
    /**
     * Sets the "Instalacao" element
     */
    public void setInstalacao(java.lang.String instalacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALACAO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSTALACAO$8);
            }
            target.setStringValue(instalacao);
        }
    }
    
    /**
     * Sets (as xml) the "Instalacao" element
     */
    public void xsetInstalacao(org.apache.xmlbeans.XmlString instalacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INSTALACAO$8);
            }
            target.set(instalacao);
        }
    }
    
    /**
     * Nils the "Instalacao" element
     */
    public void setNilInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INSTALACAO$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Instalacao" element
     */
    public void unsetInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INSTALACAO$8, 0);
        }
    }
    
    /**
     * Gets the "NomeEmpresa" element
     */
    public java.lang.String getNomeEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMEEMPRESA$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NomeEmpresa" element
     */
    public org.apache.xmlbeans.XmlString xgetNomeEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEEMPRESA$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "NomeEmpresa" element
     */
    public boolean isNilNomeEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEEMPRESA$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NomeEmpresa" element
     */
    public boolean isSetNomeEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOMEEMPRESA$10) != 0;
        }
    }
    
    /**
     * Sets the "NomeEmpresa" element
     */
    public void setNomeEmpresa(java.lang.String nomeEmpresa)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMEEMPRESA$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOMEEMPRESA$10);
            }
            target.setStringValue(nomeEmpresa);
        }
    }
    
    /**
     * Sets (as xml) the "NomeEmpresa" element
     */
    public void xsetNomeEmpresa(org.apache.xmlbeans.XmlString nomeEmpresa)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEEMPRESA$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMEEMPRESA$10);
            }
            target.set(nomeEmpresa);
        }
    }
    
    /**
     * Nils the "NomeEmpresa" element
     */
    public void setNilNomeEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEEMPRESA$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMEEMPRESA$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NomeEmpresa" element
     */
    public void unsetNomeEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOMEEMPRESA$10, 0);
        }
    }
    
    /**
     * Gets the "Parceiro" element
     */
    public java.lang.String getParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PARCEIRO$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Parceiro" element
     */
    public org.apache.xmlbeans.XmlString xgetParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PARCEIRO$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Parceiro" element
     */
    public boolean isNilParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PARCEIRO$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Parceiro" element
     */
    public boolean isSetParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PARCEIRO$12) != 0;
        }
    }
    
    /**
     * Sets the "Parceiro" element
     */
    public void setParceiro(java.lang.String parceiro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PARCEIRO$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PARCEIRO$12);
            }
            target.setStringValue(parceiro);
        }
    }
    
    /**
     * Sets (as xml) the "Parceiro" element
     */
    public void xsetParceiro(org.apache.xmlbeans.XmlString parceiro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PARCEIRO$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PARCEIRO$12);
            }
            target.set(parceiro);
        }
    }
    
    /**
     * Nils the "Parceiro" element
     */
    public void setNilParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PARCEIRO$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PARCEIRO$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Parceiro" element
     */
    public void unsetParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PARCEIRO$12, 0);
        }
    }
}
