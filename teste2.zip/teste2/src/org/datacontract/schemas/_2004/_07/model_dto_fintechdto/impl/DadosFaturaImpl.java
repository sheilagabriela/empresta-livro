/*
 * XML Type:  DadosFatura
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * An XML DadosFatura(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public class DadosFaturaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura
{
    private static final long serialVersionUID = 1L;
    
    public DadosFaturaImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName BOLETO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Boleto");
    private static final javax.xml.namespace.QName CODIGOBARRAS$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "CodigoBarras");
    private static final javax.xml.namespace.QName CONTACONTRATO$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "ContaContrato");
    private static final javax.xml.namespace.QName CONTAENVIADACOBRADORA$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "ContaEnviadaCobradora");
    private static final javax.xml.namespace.QName CONTRATO$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Contrato");
    private static final javax.xml.namespace.QName DATACOMPENSACAO$10 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DataCompensacao");
    private static final javax.xml.namespace.QName DATAFATURA$12 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DataFatura");
    private static final javax.xml.namespace.QName DATAFIMFORNECIMENTO$14 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DataFimFornecimento");
    private static final javax.xml.namespace.QName DATAINICIOFORNECIMENTO$16 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DataInicioFornecimento");
    private static final javax.xml.namespace.QName DATALIMITE$18 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DataLimite");
    private static final javax.xml.namespace.QName DATAPAGAMENTO$20 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DataPagamento");
    private static final javax.xml.namespace.QName DATAVENCIMENTO$22 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DataVencimento");
    private static final javax.xml.namespace.QName DOCCCCONTRATUAL$24 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DocCCContratual");
    private static final javax.xml.namespace.QName DOCREFERENCIA$26 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DocReferencia");
    private static final javax.xml.namespace.QName DTSOLICIT2AVIA$28 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DtSolicit2aVia");
    private static final javax.xml.namespace.QName EXISTEPARCELAMENTO$30 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "ExisteParcelamento");
    private static final javax.xml.namespace.QName EXISTEREAVISO$32 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "ExisteReaviso");
    private static final javax.xml.namespace.QName FORMAPAGAMENTO$34 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "FormaPagamento");
    private static final javax.xml.namespace.QName MESREFERENCIA$36 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "MesReferencia");
    private static final javax.xml.namespace.QName NUMEROCONTA$38 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "NumeroConta");
    private static final javax.xml.namespace.QName OPERACAOPARTIDA$40 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "OperacaoPartida");
    private static final javax.xml.namespace.QName PARCELA$42 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Parcela");
    private static final javax.xml.namespace.QName STATUS$44 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Status");
    private static final javax.xml.namespace.QName SUBOPERACAOPARTIDA$46 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "SubOperacaoPartida");
    private static final javax.xml.namespace.QName TIPOFATURA$48 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "TipoFatura");
    private static final javax.xml.namespace.QName TIPOPARTIDA$50 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "TipoPartida");
    private static final javax.xml.namespace.QName VALOR$52 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Valor");
    private static final javax.xml.namespace.QName VALORFATURA$54 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "ValorFatura");
    
    
    /**
     * Gets the "Boleto" element
     */
    public java.lang.String getBoleto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BOLETO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Boleto" element
     */
    public org.apache.xmlbeans.XmlString xgetBoleto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BOLETO$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Boleto" element
     */
    public boolean isNilBoleto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BOLETO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Boleto" element
     */
    public boolean isSetBoleto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(BOLETO$0) != 0;
        }
    }
    
    /**
     * Sets the "Boleto" element
     */
    public void setBoleto(java.lang.String boleto)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BOLETO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(BOLETO$0);
            }
            target.setStringValue(boleto);
        }
    }
    
    /**
     * Sets (as xml) the "Boleto" element
     */
    public void xsetBoleto(org.apache.xmlbeans.XmlString boleto)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BOLETO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(BOLETO$0);
            }
            target.set(boleto);
        }
    }
    
    /**
     * Nils the "Boleto" element
     */
    public void setNilBoleto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BOLETO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(BOLETO$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Boleto" element
     */
    public void unsetBoleto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(BOLETO$0, 0);
        }
    }
    
    /**
     * Gets the "CodigoBarras" element
     */
    public java.lang.String getCodigoBarras()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOBARRAS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoBarras" element
     */
    public org.apache.xmlbeans.XmlString xgetCodigoBarras()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOBARRAS$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodigoBarras" element
     */
    public boolean isNilCodigoBarras()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOBARRAS$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodigoBarras" element
     */
    public boolean isSetCodigoBarras()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGOBARRAS$2) != 0;
        }
    }
    
    /**
     * Sets the "CodigoBarras" element
     */
    public void setCodigoBarras(java.lang.String codigoBarras)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOBARRAS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOBARRAS$2);
            }
            target.setStringValue(codigoBarras);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoBarras" element
     */
    public void xsetCodigoBarras(org.apache.xmlbeans.XmlString codigoBarras)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOBARRAS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODIGOBARRAS$2);
            }
            target.set(codigoBarras);
        }
    }
    
    /**
     * Nils the "CodigoBarras" element
     */
    public void setNilCodigoBarras()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOBARRAS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODIGOBARRAS$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodigoBarras" element
     */
    public void unsetCodigoBarras()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGOBARRAS$2, 0);
        }
    }
    
    /**
     * Gets the "ContaContrato" element
     */
    public java.lang.String getContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTACONTRATO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ContaContrato" element
     */
    public org.apache.xmlbeans.XmlString xgetContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTACONTRATO$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ContaContrato" element
     */
    public boolean isNilContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTACONTRATO$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ContaContrato" element
     */
    public boolean isSetContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONTACONTRATO$4) != 0;
        }
    }
    
    /**
     * Sets the "ContaContrato" element
     */
    public void setContaContrato(java.lang.String contaContrato)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTACONTRATO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONTACONTRATO$4);
            }
            target.setStringValue(contaContrato);
        }
    }
    
    /**
     * Sets (as xml) the "ContaContrato" element
     */
    public void xsetContaContrato(org.apache.xmlbeans.XmlString contaContrato)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTACONTRATO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONTACONTRATO$4);
            }
            target.set(contaContrato);
        }
    }
    
    /**
     * Nils the "ContaContrato" element
     */
    public void setNilContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTACONTRATO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONTACONTRATO$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ContaContrato" element
     */
    public void unsetContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONTACONTRATO$4, 0);
        }
    }
    
    /**
     * Gets the "ContaEnviadaCobradora" element
     */
    public java.lang.String getContaEnviadaCobradora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTAENVIADACOBRADORA$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ContaEnviadaCobradora" element
     */
    public org.apache.xmlbeans.XmlString xgetContaEnviadaCobradora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTAENVIADACOBRADORA$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ContaEnviadaCobradora" element
     */
    public boolean isNilContaEnviadaCobradora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTAENVIADACOBRADORA$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ContaEnviadaCobradora" element
     */
    public boolean isSetContaEnviadaCobradora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONTAENVIADACOBRADORA$6) != 0;
        }
    }
    
    /**
     * Sets the "ContaEnviadaCobradora" element
     */
    public void setContaEnviadaCobradora(java.lang.String contaEnviadaCobradora)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTAENVIADACOBRADORA$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONTAENVIADACOBRADORA$6);
            }
            target.setStringValue(contaEnviadaCobradora);
        }
    }
    
    /**
     * Sets (as xml) the "ContaEnviadaCobradora" element
     */
    public void xsetContaEnviadaCobradora(org.apache.xmlbeans.XmlString contaEnviadaCobradora)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTAENVIADACOBRADORA$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONTAENVIADACOBRADORA$6);
            }
            target.set(contaEnviadaCobradora);
        }
    }
    
    /**
     * Nils the "ContaEnviadaCobradora" element
     */
    public void setNilContaEnviadaCobradora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTAENVIADACOBRADORA$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONTAENVIADACOBRADORA$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ContaEnviadaCobradora" element
     */
    public void unsetContaEnviadaCobradora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONTAENVIADACOBRADORA$6, 0);
        }
    }
    
    /**
     * Gets the "Contrato" element
     */
    public java.lang.String getContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTRATO$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Contrato" element
     */
    public org.apache.xmlbeans.XmlString xgetContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTRATO$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Contrato" element
     */
    public boolean isNilContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTRATO$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Contrato" element
     */
    public boolean isSetContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONTRATO$8) != 0;
        }
    }
    
    /**
     * Sets the "Contrato" element
     */
    public void setContrato(java.lang.String contrato)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTRATO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONTRATO$8);
            }
            target.setStringValue(contrato);
        }
    }
    
    /**
     * Sets (as xml) the "Contrato" element
     */
    public void xsetContrato(org.apache.xmlbeans.XmlString contrato)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTRATO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONTRATO$8);
            }
            target.set(contrato);
        }
    }
    
    /**
     * Nils the "Contrato" element
     */
    public void setNilContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTRATO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONTRATO$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Contrato" element
     */
    public void unsetContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONTRATO$8, 0);
        }
    }
    
    /**
     * Gets the "DataCompensacao" element
     */
    public java.util.Calendar getDataCompensacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATACOMPENSACAO$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataCompensacao" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetDataCompensacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATACOMPENSACAO$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataCompensacao" element
     */
    public boolean isNilDataCompensacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATACOMPENSACAO$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataCompensacao" element
     */
    public boolean isSetDataCompensacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATACOMPENSACAO$10) != 0;
        }
    }
    
    /**
     * Sets the "DataCompensacao" element
     */
    public void setDataCompensacao(java.util.Calendar dataCompensacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATACOMPENSACAO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATACOMPENSACAO$10);
            }
            target.setCalendarValue(dataCompensacao);
        }
    }
    
    /**
     * Sets (as xml) the "DataCompensacao" element
     */
    public void xsetDataCompensacao(org.apache.xmlbeans.XmlDateTime dataCompensacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATACOMPENSACAO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATACOMPENSACAO$10);
            }
            target.set(dataCompensacao);
        }
    }
    
    /**
     * Nils the "DataCompensacao" element
     */
    public void setNilDataCompensacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATACOMPENSACAO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATACOMPENSACAO$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataCompensacao" element
     */
    public void unsetDataCompensacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATACOMPENSACAO$10, 0);
        }
    }
    
    /**
     * Gets the "DataFatura" element
     */
    public java.util.Calendar getDataFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAFATURA$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataFatura" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetDataFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAFATURA$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataFatura" element
     */
    public boolean isNilDataFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAFATURA$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataFatura" element
     */
    public boolean isSetDataFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATAFATURA$12) != 0;
        }
    }
    
    /**
     * Sets the "DataFatura" element
     */
    public void setDataFatura(java.util.Calendar dataFatura)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAFATURA$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAFATURA$12);
            }
            target.setCalendarValue(dataFatura);
        }
    }
    
    /**
     * Sets (as xml) the "DataFatura" element
     */
    public void xsetDataFatura(org.apache.xmlbeans.XmlDateTime dataFatura)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAFATURA$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATAFATURA$12);
            }
            target.set(dataFatura);
        }
    }
    
    /**
     * Nils the "DataFatura" element
     */
    public void setNilDataFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAFATURA$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATAFATURA$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataFatura" element
     */
    public void unsetDataFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATAFATURA$12, 0);
        }
    }
    
    /**
     * Gets the "DataFimFornecimento" element
     */
    public java.util.Calendar getDataFimFornecimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAFIMFORNECIMENTO$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataFimFornecimento" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetDataFimFornecimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAFIMFORNECIMENTO$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataFimFornecimento" element
     */
    public boolean isNilDataFimFornecimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAFIMFORNECIMENTO$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataFimFornecimento" element
     */
    public boolean isSetDataFimFornecimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATAFIMFORNECIMENTO$14) != 0;
        }
    }
    
    /**
     * Sets the "DataFimFornecimento" element
     */
    public void setDataFimFornecimento(java.util.Calendar dataFimFornecimento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAFIMFORNECIMENTO$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAFIMFORNECIMENTO$14);
            }
            target.setCalendarValue(dataFimFornecimento);
        }
    }
    
    /**
     * Sets (as xml) the "DataFimFornecimento" element
     */
    public void xsetDataFimFornecimento(org.apache.xmlbeans.XmlDateTime dataFimFornecimento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAFIMFORNECIMENTO$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATAFIMFORNECIMENTO$14);
            }
            target.set(dataFimFornecimento);
        }
    }
    
    /**
     * Nils the "DataFimFornecimento" element
     */
    public void setNilDataFimFornecimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAFIMFORNECIMENTO$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATAFIMFORNECIMENTO$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataFimFornecimento" element
     */
    public void unsetDataFimFornecimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATAFIMFORNECIMENTO$14, 0);
        }
    }
    
    /**
     * Gets the "DataInicioFornecimento" element
     */
    public java.util.Calendar getDataInicioFornecimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAINICIOFORNECIMENTO$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataInicioFornecimento" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetDataInicioFornecimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAINICIOFORNECIMENTO$16, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataInicioFornecimento" element
     */
    public boolean isNilDataInicioFornecimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAINICIOFORNECIMENTO$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataInicioFornecimento" element
     */
    public boolean isSetDataInicioFornecimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATAINICIOFORNECIMENTO$16) != 0;
        }
    }
    
    /**
     * Sets the "DataInicioFornecimento" element
     */
    public void setDataInicioFornecimento(java.util.Calendar dataInicioFornecimento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAINICIOFORNECIMENTO$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAINICIOFORNECIMENTO$16);
            }
            target.setCalendarValue(dataInicioFornecimento);
        }
    }
    
    /**
     * Sets (as xml) the "DataInicioFornecimento" element
     */
    public void xsetDataInicioFornecimento(org.apache.xmlbeans.XmlDateTime dataInicioFornecimento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAINICIOFORNECIMENTO$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATAINICIOFORNECIMENTO$16);
            }
            target.set(dataInicioFornecimento);
        }
    }
    
    /**
     * Nils the "DataInicioFornecimento" element
     */
    public void setNilDataInicioFornecimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAINICIOFORNECIMENTO$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATAINICIOFORNECIMENTO$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataInicioFornecimento" element
     */
    public void unsetDataInicioFornecimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATAINICIOFORNECIMENTO$16, 0);
        }
    }
    
    /**
     * Gets the "DataLimite" element
     */
    public java.util.Calendar getDataLimite()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATALIMITE$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataLimite" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetDataLimite()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATALIMITE$18, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataLimite" element
     */
    public boolean isNilDataLimite()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATALIMITE$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataLimite" element
     */
    public boolean isSetDataLimite()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATALIMITE$18) != 0;
        }
    }
    
    /**
     * Sets the "DataLimite" element
     */
    public void setDataLimite(java.util.Calendar dataLimite)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATALIMITE$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATALIMITE$18);
            }
            target.setCalendarValue(dataLimite);
        }
    }
    
    /**
     * Sets (as xml) the "DataLimite" element
     */
    public void xsetDataLimite(org.apache.xmlbeans.XmlDateTime dataLimite)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATALIMITE$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATALIMITE$18);
            }
            target.set(dataLimite);
        }
    }
    
    /**
     * Nils the "DataLimite" element
     */
    public void setNilDataLimite()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATALIMITE$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATALIMITE$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataLimite" element
     */
    public void unsetDataLimite()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATALIMITE$18, 0);
        }
    }
    
    /**
     * Gets the "DataPagamento" element
     */
    public java.util.Calendar getDataPagamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAPAGAMENTO$20, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataPagamento" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetDataPagamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAPAGAMENTO$20, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataPagamento" element
     */
    public boolean isNilDataPagamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAPAGAMENTO$20, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataPagamento" element
     */
    public boolean isSetDataPagamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATAPAGAMENTO$20) != 0;
        }
    }
    
    /**
     * Sets the "DataPagamento" element
     */
    public void setDataPagamento(java.util.Calendar dataPagamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAPAGAMENTO$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAPAGAMENTO$20);
            }
            target.setCalendarValue(dataPagamento);
        }
    }
    
    /**
     * Sets (as xml) the "DataPagamento" element
     */
    public void xsetDataPagamento(org.apache.xmlbeans.XmlDateTime dataPagamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAPAGAMENTO$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATAPAGAMENTO$20);
            }
            target.set(dataPagamento);
        }
    }
    
    /**
     * Nils the "DataPagamento" element
     */
    public void setNilDataPagamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAPAGAMENTO$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATAPAGAMENTO$20);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataPagamento" element
     */
    public void unsetDataPagamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATAPAGAMENTO$20, 0);
        }
    }
    
    /**
     * Gets the "DataVencimento" element
     */
    public java.util.Calendar getDataVencimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAVENCIMENTO$22, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataVencimento" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetDataVencimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAVENCIMENTO$22, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataVencimento" element
     */
    public boolean isNilDataVencimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAVENCIMENTO$22, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataVencimento" element
     */
    public boolean isSetDataVencimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATAVENCIMENTO$22) != 0;
        }
    }
    
    /**
     * Sets the "DataVencimento" element
     */
    public void setDataVencimento(java.util.Calendar dataVencimento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAVENCIMENTO$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAVENCIMENTO$22);
            }
            target.setCalendarValue(dataVencimento);
        }
    }
    
    /**
     * Sets (as xml) the "DataVencimento" element
     */
    public void xsetDataVencimento(org.apache.xmlbeans.XmlDateTime dataVencimento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAVENCIMENTO$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATAVENCIMENTO$22);
            }
            target.set(dataVencimento);
        }
    }
    
    /**
     * Nils the "DataVencimento" element
     */
    public void setNilDataVencimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAVENCIMENTO$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATAVENCIMENTO$22);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataVencimento" element
     */
    public void unsetDataVencimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATAVENCIMENTO$22, 0);
        }
    }
    
    /**
     * Gets the "DocCCContratual" element
     */
    public java.lang.String getDocCCContratual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DOCCCCONTRATUAL$24, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DocCCContratual" element
     */
    public org.apache.xmlbeans.XmlString xgetDocCCContratual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCCCCONTRATUAL$24, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DocCCContratual" element
     */
    public boolean isNilDocCCContratual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCCCCONTRATUAL$24, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DocCCContratual" element
     */
    public boolean isSetDocCCContratual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCCCCONTRATUAL$24) != 0;
        }
    }
    
    /**
     * Sets the "DocCCContratual" element
     */
    public void setDocCCContratual(java.lang.String docCCContratual)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DOCCCCONTRATUAL$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DOCCCCONTRATUAL$24);
            }
            target.setStringValue(docCCContratual);
        }
    }
    
    /**
     * Sets (as xml) the "DocCCContratual" element
     */
    public void xsetDocCCContratual(org.apache.xmlbeans.XmlString docCCContratual)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCCCCONTRATUAL$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DOCCCCONTRATUAL$24);
            }
            target.set(docCCContratual);
        }
    }
    
    /**
     * Nils the "DocCCContratual" element
     */
    public void setNilDocCCContratual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCCCCONTRATUAL$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DOCCCCONTRATUAL$24);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DocCCContratual" element
     */
    public void unsetDocCCContratual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCCCCONTRATUAL$24, 0);
        }
    }
    
    /**
     * Gets the "DocReferencia" element
     */
    public java.lang.String getDocReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DOCREFERENCIA$26, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DocReferencia" element
     */
    public org.apache.xmlbeans.XmlString xgetDocReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCREFERENCIA$26, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DocReferencia" element
     */
    public boolean isNilDocReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCREFERENCIA$26, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DocReferencia" element
     */
    public boolean isSetDocReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCREFERENCIA$26) != 0;
        }
    }
    
    /**
     * Sets the "DocReferencia" element
     */
    public void setDocReferencia(java.lang.String docReferencia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DOCREFERENCIA$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DOCREFERENCIA$26);
            }
            target.setStringValue(docReferencia);
        }
    }
    
    /**
     * Sets (as xml) the "DocReferencia" element
     */
    public void xsetDocReferencia(org.apache.xmlbeans.XmlString docReferencia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCREFERENCIA$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DOCREFERENCIA$26);
            }
            target.set(docReferencia);
        }
    }
    
    /**
     * Nils the "DocReferencia" element
     */
    public void setNilDocReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCREFERENCIA$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DOCREFERENCIA$26);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DocReferencia" element
     */
    public void unsetDocReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCREFERENCIA$26, 0);
        }
    }
    
    /**
     * Gets the "DtSolicit2aVia" element
     */
    public java.lang.String getDtSolicit2AVia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTSOLICIT2AVIA$28, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DtSolicit2aVia" element
     */
    public org.apache.xmlbeans.XmlString xgetDtSolicit2AVia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DTSOLICIT2AVIA$28, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DtSolicit2aVia" element
     */
    public boolean isNilDtSolicit2AVia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DTSOLICIT2AVIA$28, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DtSolicit2aVia" element
     */
    public boolean isSetDtSolicit2AVia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DTSOLICIT2AVIA$28) != 0;
        }
    }
    
    /**
     * Sets the "DtSolicit2aVia" element
     */
    public void setDtSolicit2AVia(java.lang.String dtSolicit2AVia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTSOLICIT2AVIA$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DTSOLICIT2AVIA$28);
            }
            target.setStringValue(dtSolicit2AVia);
        }
    }
    
    /**
     * Sets (as xml) the "DtSolicit2aVia" element
     */
    public void xsetDtSolicit2AVia(org.apache.xmlbeans.XmlString dtSolicit2AVia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DTSOLICIT2AVIA$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DTSOLICIT2AVIA$28);
            }
            target.set(dtSolicit2AVia);
        }
    }
    
    /**
     * Nils the "DtSolicit2aVia" element
     */
    public void setNilDtSolicit2AVia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DTSOLICIT2AVIA$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DTSOLICIT2AVIA$28);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DtSolicit2aVia" element
     */
    public void unsetDtSolicit2AVia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DTSOLICIT2AVIA$28, 0);
        }
    }
    
    /**
     * Gets the "ExisteParcelamento" element
     */
    public java.lang.String getExisteParcelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXISTEPARCELAMENTO$30, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ExisteParcelamento" element
     */
    public org.apache.xmlbeans.XmlString xgetExisteParcelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXISTEPARCELAMENTO$30, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ExisteParcelamento" element
     */
    public boolean isNilExisteParcelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXISTEPARCELAMENTO$30, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ExisteParcelamento" element
     */
    public boolean isSetExisteParcelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXISTEPARCELAMENTO$30) != 0;
        }
    }
    
    /**
     * Sets the "ExisteParcelamento" element
     */
    public void setExisteParcelamento(java.lang.String existeParcelamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXISTEPARCELAMENTO$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EXISTEPARCELAMENTO$30);
            }
            target.setStringValue(existeParcelamento);
        }
    }
    
    /**
     * Sets (as xml) the "ExisteParcelamento" element
     */
    public void xsetExisteParcelamento(org.apache.xmlbeans.XmlString existeParcelamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXISTEPARCELAMENTO$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EXISTEPARCELAMENTO$30);
            }
            target.set(existeParcelamento);
        }
    }
    
    /**
     * Nils the "ExisteParcelamento" element
     */
    public void setNilExisteParcelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXISTEPARCELAMENTO$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EXISTEPARCELAMENTO$30);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ExisteParcelamento" element
     */
    public void unsetExisteParcelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXISTEPARCELAMENTO$30, 0);
        }
    }
    
    /**
     * Gets the "ExisteReaviso" element
     */
    public java.lang.String getExisteReaviso()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXISTEREAVISO$32, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ExisteReaviso" element
     */
    public org.apache.xmlbeans.XmlString xgetExisteReaviso()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXISTEREAVISO$32, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ExisteReaviso" element
     */
    public boolean isNilExisteReaviso()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXISTEREAVISO$32, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ExisteReaviso" element
     */
    public boolean isSetExisteReaviso()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXISTEREAVISO$32) != 0;
        }
    }
    
    /**
     * Sets the "ExisteReaviso" element
     */
    public void setExisteReaviso(java.lang.String existeReaviso)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXISTEREAVISO$32, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EXISTEREAVISO$32);
            }
            target.setStringValue(existeReaviso);
        }
    }
    
    /**
     * Sets (as xml) the "ExisteReaviso" element
     */
    public void xsetExisteReaviso(org.apache.xmlbeans.XmlString existeReaviso)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXISTEREAVISO$32, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EXISTEREAVISO$32);
            }
            target.set(existeReaviso);
        }
    }
    
    /**
     * Nils the "ExisteReaviso" element
     */
    public void setNilExisteReaviso()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXISTEREAVISO$32, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EXISTEREAVISO$32);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ExisteReaviso" element
     */
    public void unsetExisteReaviso()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXISTEREAVISO$32, 0);
        }
    }
    
    /**
     * Gets the "FormaPagamento" element
     */
    public java.lang.String getFormaPagamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FORMAPAGAMENTO$34, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "FormaPagamento" element
     */
    public org.apache.xmlbeans.XmlString xgetFormaPagamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FORMAPAGAMENTO$34, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "FormaPagamento" element
     */
    public boolean isNilFormaPagamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FORMAPAGAMENTO$34, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "FormaPagamento" element
     */
    public boolean isSetFormaPagamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FORMAPAGAMENTO$34) != 0;
        }
    }
    
    /**
     * Sets the "FormaPagamento" element
     */
    public void setFormaPagamento(java.lang.String formaPagamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FORMAPAGAMENTO$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FORMAPAGAMENTO$34);
            }
            target.setStringValue(formaPagamento);
        }
    }
    
    /**
     * Sets (as xml) the "FormaPagamento" element
     */
    public void xsetFormaPagamento(org.apache.xmlbeans.XmlString formaPagamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FORMAPAGAMENTO$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(FORMAPAGAMENTO$34);
            }
            target.set(formaPagamento);
        }
    }
    
    /**
     * Nils the "FormaPagamento" element
     */
    public void setNilFormaPagamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FORMAPAGAMENTO$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(FORMAPAGAMENTO$34);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "FormaPagamento" element
     */
    public void unsetFormaPagamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FORMAPAGAMENTO$34, 0);
        }
    }
    
    /**
     * Gets the "MesReferencia" element
     */
    public java.lang.String getMesReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MESREFERENCIA$36, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "MesReferencia" element
     */
    public org.apache.xmlbeans.XmlString xgetMesReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MESREFERENCIA$36, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "MesReferencia" element
     */
    public boolean isNilMesReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MESREFERENCIA$36, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "MesReferencia" element
     */
    public boolean isSetMesReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MESREFERENCIA$36) != 0;
        }
    }
    
    /**
     * Sets the "MesReferencia" element
     */
    public void setMesReferencia(java.lang.String mesReferencia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MESREFERENCIA$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MESREFERENCIA$36);
            }
            target.setStringValue(mesReferencia);
        }
    }
    
    /**
     * Sets (as xml) the "MesReferencia" element
     */
    public void xsetMesReferencia(org.apache.xmlbeans.XmlString mesReferencia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MESREFERENCIA$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MESREFERENCIA$36);
            }
            target.set(mesReferencia);
        }
    }
    
    /**
     * Nils the "MesReferencia" element
     */
    public void setNilMesReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MESREFERENCIA$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MESREFERENCIA$36);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "MesReferencia" element
     */
    public void unsetMesReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MESREFERENCIA$36, 0);
        }
    }
    
    /**
     * Gets the "NumeroConta" element
     */
    public java.lang.String getNumeroConta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROCONTA$38, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NumeroConta" element
     */
    public org.apache.xmlbeans.XmlString xgetNumeroConta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMEROCONTA$38, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "NumeroConta" element
     */
    public boolean isNilNumeroConta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMEROCONTA$38, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NumeroConta" element
     */
    public boolean isSetNumeroConta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMEROCONTA$38) != 0;
        }
    }
    
    /**
     * Sets the "NumeroConta" element
     */
    public void setNumeroConta(java.lang.String numeroConta)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROCONTA$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMEROCONTA$38);
            }
            target.setStringValue(numeroConta);
        }
    }
    
    /**
     * Sets (as xml) the "NumeroConta" element
     */
    public void xsetNumeroConta(org.apache.xmlbeans.XmlString numeroConta)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMEROCONTA$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMEROCONTA$38);
            }
            target.set(numeroConta);
        }
    }
    
    /**
     * Nils the "NumeroConta" element
     */
    public void setNilNumeroConta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMEROCONTA$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMEROCONTA$38);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NumeroConta" element
     */
    public void unsetNumeroConta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMEROCONTA$38, 0);
        }
    }
    
    /**
     * Gets the "OperacaoPartida" element
     */
    public java.lang.String getOperacaoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPERACAOPARTIDA$40, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "OperacaoPartida" element
     */
    public org.apache.xmlbeans.XmlString xgetOperacaoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OPERACAOPARTIDA$40, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "OperacaoPartida" element
     */
    public boolean isNilOperacaoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OPERACAOPARTIDA$40, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "OperacaoPartida" element
     */
    public boolean isSetOperacaoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OPERACAOPARTIDA$40) != 0;
        }
    }
    
    /**
     * Sets the "OperacaoPartida" element
     */
    public void setOperacaoPartida(java.lang.String operacaoPartida)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPERACAOPARTIDA$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OPERACAOPARTIDA$40);
            }
            target.setStringValue(operacaoPartida);
        }
    }
    
    /**
     * Sets (as xml) the "OperacaoPartida" element
     */
    public void xsetOperacaoPartida(org.apache.xmlbeans.XmlString operacaoPartida)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OPERACAOPARTIDA$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(OPERACAOPARTIDA$40);
            }
            target.set(operacaoPartida);
        }
    }
    
    /**
     * Nils the "OperacaoPartida" element
     */
    public void setNilOperacaoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OPERACAOPARTIDA$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(OPERACAOPARTIDA$40);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "OperacaoPartida" element
     */
    public void unsetOperacaoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OPERACAOPARTIDA$40, 0);
        }
    }
    
    /**
     * Gets the "Parcela" element
     */
    public java.lang.String getParcela()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PARCELA$42, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Parcela" element
     */
    public org.apache.xmlbeans.XmlString xgetParcela()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PARCELA$42, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Parcela" element
     */
    public boolean isNilParcela()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PARCELA$42, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Parcela" element
     */
    public boolean isSetParcela()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PARCELA$42) != 0;
        }
    }
    
    /**
     * Sets the "Parcela" element
     */
    public void setParcela(java.lang.String parcela)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PARCELA$42, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PARCELA$42);
            }
            target.setStringValue(parcela);
        }
    }
    
    /**
     * Sets (as xml) the "Parcela" element
     */
    public void xsetParcela(org.apache.xmlbeans.XmlString parcela)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PARCELA$42, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PARCELA$42);
            }
            target.set(parcela);
        }
    }
    
    /**
     * Nils the "Parcela" element
     */
    public void setNilParcela()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PARCELA$42, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PARCELA$42);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Parcela" element
     */
    public void unsetParcela()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PARCELA$42, 0);
        }
    }
    
    /**
     * Gets the "Status" element
     */
    public java.lang.String getStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STATUS$44, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Status" element
     */
    public org.apache.xmlbeans.XmlString xgetStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(STATUS$44, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Status" element
     */
    public boolean isNilStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(STATUS$44, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Status" element
     */
    public boolean isSetStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(STATUS$44) != 0;
        }
    }
    
    /**
     * Sets the "Status" element
     */
    public void setStatus(java.lang.String status)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STATUS$44, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(STATUS$44);
            }
            target.setStringValue(status);
        }
    }
    
    /**
     * Sets (as xml) the "Status" element
     */
    public void xsetStatus(org.apache.xmlbeans.XmlString status)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(STATUS$44, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(STATUS$44);
            }
            target.set(status);
        }
    }
    
    /**
     * Nils the "Status" element
     */
    public void setNilStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(STATUS$44, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(STATUS$44);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Status" element
     */
    public void unsetStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(STATUS$44, 0);
        }
    }
    
    /**
     * Gets the "SubOperacaoPartida" element
     */
    public java.lang.String getSubOperacaoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUBOPERACAOPARTIDA$46, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "SubOperacaoPartida" element
     */
    public org.apache.xmlbeans.XmlString xgetSubOperacaoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUBOPERACAOPARTIDA$46, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "SubOperacaoPartida" element
     */
    public boolean isNilSubOperacaoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUBOPERACAOPARTIDA$46, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "SubOperacaoPartida" element
     */
    public boolean isSetSubOperacaoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUBOPERACAOPARTIDA$46) != 0;
        }
    }
    
    /**
     * Sets the "SubOperacaoPartida" element
     */
    public void setSubOperacaoPartida(java.lang.String subOperacaoPartida)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUBOPERACAOPARTIDA$46, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SUBOPERACAOPARTIDA$46);
            }
            target.setStringValue(subOperacaoPartida);
        }
    }
    
    /**
     * Sets (as xml) the "SubOperacaoPartida" element
     */
    public void xsetSubOperacaoPartida(org.apache.xmlbeans.XmlString subOperacaoPartida)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUBOPERACAOPARTIDA$46, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SUBOPERACAOPARTIDA$46);
            }
            target.set(subOperacaoPartida);
        }
    }
    
    /**
     * Nils the "SubOperacaoPartida" element
     */
    public void setNilSubOperacaoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUBOPERACAOPARTIDA$46, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SUBOPERACAOPARTIDA$46);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "SubOperacaoPartida" element
     */
    public void unsetSubOperacaoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUBOPERACAOPARTIDA$46, 0);
        }
    }
    
    /**
     * Gets the "TipoFatura" element
     */
    public java.lang.String getTipoFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIPOFATURA$48, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "TipoFatura" element
     */
    public org.apache.xmlbeans.XmlString xgetTipoFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIPOFATURA$48, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "TipoFatura" element
     */
    public boolean isNilTipoFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIPOFATURA$48, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "TipoFatura" element
     */
    public boolean isSetTipoFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TIPOFATURA$48) != 0;
        }
    }
    
    /**
     * Sets the "TipoFatura" element
     */
    public void setTipoFatura(java.lang.String tipoFatura)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIPOFATURA$48, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TIPOFATURA$48);
            }
            target.setStringValue(tipoFatura);
        }
    }
    
    /**
     * Sets (as xml) the "TipoFatura" element
     */
    public void xsetTipoFatura(org.apache.xmlbeans.XmlString tipoFatura)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIPOFATURA$48, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TIPOFATURA$48);
            }
            target.set(tipoFatura);
        }
    }
    
    /**
     * Nils the "TipoFatura" element
     */
    public void setNilTipoFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIPOFATURA$48, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TIPOFATURA$48);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "TipoFatura" element
     */
    public void unsetTipoFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TIPOFATURA$48, 0);
        }
    }
    
    /**
     * Gets the "TipoPartida" element
     */
    public java.lang.String getTipoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIPOPARTIDA$50, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "TipoPartida" element
     */
    public org.apache.xmlbeans.XmlString xgetTipoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIPOPARTIDA$50, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "TipoPartida" element
     */
    public boolean isNilTipoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIPOPARTIDA$50, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "TipoPartida" element
     */
    public boolean isSetTipoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TIPOPARTIDA$50) != 0;
        }
    }
    
    /**
     * Sets the "TipoPartida" element
     */
    public void setTipoPartida(java.lang.String tipoPartida)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIPOPARTIDA$50, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TIPOPARTIDA$50);
            }
            target.setStringValue(tipoPartida);
        }
    }
    
    /**
     * Sets (as xml) the "TipoPartida" element
     */
    public void xsetTipoPartida(org.apache.xmlbeans.XmlString tipoPartida)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIPOPARTIDA$50, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TIPOPARTIDA$50);
            }
            target.set(tipoPartida);
        }
    }
    
    /**
     * Nils the "TipoPartida" element
     */
    public void setNilTipoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIPOPARTIDA$50, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TIPOPARTIDA$50);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "TipoPartida" element
     */
    public void unsetTipoPartida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TIPOPARTIDA$50, 0);
        }
    }
    
    /**
     * Gets the "Valor" element
     */
    public java.lang.String getValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALOR$52, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Valor" element
     */
    public org.apache.xmlbeans.XmlString xgetValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALOR$52, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Valor" element
     */
    public boolean isNilValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALOR$52, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Valor" element
     */
    public boolean isSetValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALOR$52) != 0;
        }
    }
    
    /**
     * Sets the "Valor" element
     */
    public void setValor(java.lang.String valor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALOR$52, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALOR$52);
            }
            target.setStringValue(valor);
        }
    }
    
    /**
     * Sets (as xml) the "Valor" element
     */
    public void xsetValor(org.apache.xmlbeans.XmlString valor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALOR$52, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VALOR$52);
            }
            target.set(valor);
        }
    }
    
    /**
     * Nils the "Valor" element
     */
    public void setNilValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALOR$52, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VALOR$52);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Valor" element
     */
    public void unsetValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALOR$52, 0);
        }
    }
    
    /**
     * Gets the "ValorFatura" element
     */
    public java.lang.String getValorFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORFATURA$54, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorFatura" element
     */
    public org.apache.xmlbeans.XmlString xgetValorFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALORFATURA$54, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ValorFatura" element
     */
    public boolean isNilValorFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALORFATURA$54, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ValorFatura" element
     */
    public boolean isSetValorFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORFATURA$54) != 0;
        }
    }
    
    /**
     * Sets the "ValorFatura" element
     */
    public void setValorFatura(java.lang.String valorFatura)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORFATURA$54, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORFATURA$54);
            }
            target.setStringValue(valorFatura);
        }
    }
    
    /**
     * Sets (as xml) the "ValorFatura" element
     */
    public void xsetValorFatura(org.apache.xmlbeans.XmlString valorFatura)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALORFATURA$54, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VALORFATURA$54);
            }
            target.set(valorFatura);
        }
    }
    
    /**
     * Nils the "ValorFatura" element
     */
    public void setNilValorFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALORFATURA$54, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VALORFATURA$54);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ValorFatura" element
     */
    public void unsetValorFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORFATURA$54, 0);
        }
    }
}
