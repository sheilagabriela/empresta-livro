/*
 * XML Type:  ClienteDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto;


/**
 * An XML ClienteDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public interface ClienteDTO extends org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTO
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ClienteDTO.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3965ADB232D1D9A0AB9A333DE5AD2A31").resolveHandle("clientedto2caetype");
    
    /**
     * Gets the "Bairro" element
     */
    java.lang.String getBairro();
    
    /**
     * Gets (as xml) the "Bairro" element
     */
    org.apache.xmlbeans.XmlString xgetBairro();
    
    /**
     * Tests for nil "Bairro" element
     */
    boolean isNilBairro();
    
    /**
     * True if has "Bairro" element
     */
    boolean isSetBairro();
    
    /**
     * Sets the "Bairro" element
     */
    void setBairro(java.lang.String bairro);
    
    /**
     * Sets (as xml) the "Bairro" element
     */
    void xsetBairro(org.apache.xmlbeans.XmlString bairro);
    
    /**
     * Nils the "Bairro" element
     */
    void setNilBairro();
    
    /**
     * Unsets the "Bairro" element
     */
    void unsetBairro();
    
    /**
     * Gets the "Cep" element
     */
    java.lang.String getCep();
    
    /**
     * Gets (as xml) the "Cep" element
     */
    org.apache.xmlbeans.XmlString xgetCep();
    
    /**
     * Tests for nil "Cep" element
     */
    boolean isNilCep();
    
    /**
     * True if has "Cep" element
     */
    boolean isSetCep();
    
    /**
     * Sets the "Cep" element
     */
    void setCep(java.lang.String cep);
    
    /**
     * Sets (as xml) the "Cep" element
     */
    void xsetCep(org.apache.xmlbeans.XmlString cep);
    
    /**
     * Nils the "Cep" element
     */
    void setNilCep();
    
    /**
     * Unsets the "Cep" element
     */
    void unsetCep();
    
    /**
     * Gets the "Cidade" element
     */
    java.lang.String getCidade();
    
    /**
     * Gets (as xml) the "Cidade" element
     */
    org.apache.xmlbeans.XmlString xgetCidade();
    
    /**
     * Tests for nil "Cidade" element
     */
    boolean isNilCidade();
    
    /**
     * True if has "Cidade" element
     */
    boolean isSetCidade();
    
    /**
     * Sets the "Cidade" element
     */
    void setCidade(java.lang.String cidade);
    
    /**
     * Sets (as xml) the "Cidade" element
     */
    void xsetCidade(org.apache.xmlbeans.XmlString cidade);
    
    /**
     * Nils the "Cidade" element
     */
    void setNilCidade();
    
    /**
     * Unsets the "Cidade" element
     */
    void unsetCidade();
    
    /**
     * Gets the "Complemento" element
     */
    java.lang.String getComplemento();
    
    /**
     * Gets (as xml) the "Complemento" element
     */
    org.apache.xmlbeans.XmlString xgetComplemento();
    
    /**
     * Tests for nil "Complemento" element
     */
    boolean isNilComplemento();
    
    /**
     * True if has "Complemento" element
     */
    boolean isSetComplemento();
    
    /**
     * Sets the "Complemento" element
     */
    void setComplemento(java.lang.String complemento);
    
    /**
     * Sets (as xml) the "Complemento" element
     */
    void xsetComplemento(org.apache.xmlbeans.XmlString complemento);
    
    /**
     * Nils the "Complemento" element
     */
    void setNilComplemento();
    
    /**
     * Unsets the "Complemento" element
     */
    void unsetComplemento();
    
    /**
     * Gets the "DataInclusaoCadastro" element
     */
    java.lang.String getDataInclusaoCadastro();
    
    /**
     * Gets (as xml) the "DataInclusaoCadastro" element
     */
    org.apache.xmlbeans.XmlString xgetDataInclusaoCadastro();
    
    /**
     * Tests for nil "DataInclusaoCadastro" element
     */
    boolean isNilDataInclusaoCadastro();
    
    /**
     * True if has "DataInclusaoCadastro" element
     */
    boolean isSetDataInclusaoCadastro();
    
    /**
     * Sets the "DataInclusaoCadastro" element
     */
    void setDataInclusaoCadastro(java.lang.String dataInclusaoCadastro);
    
    /**
     * Sets (as xml) the "DataInclusaoCadastro" element
     */
    void xsetDataInclusaoCadastro(org.apache.xmlbeans.XmlString dataInclusaoCadastro);
    
    /**
     * Nils the "DataInclusaoCadastro" element
     */
    void setNilDataInclusaoCadastro();
    
    /**
     * Unsets the "DataInclusaoCadastro" element
     */
    void unsetDataInclusaoCadastro();
    
    /**
     * Gets the "Logradouro" element
     */
    java.lang.String getLogradouro();
    
    /**
     * Gets (as xml) the "Logradouro" element
     */
    org.apache.xmlbeans.XmlString xgetLogradouro();
    
    /**
     * Tests for nil "Logradouro" element
     */
    boolean isNilLogradouro();
    
    /**
     * True if has "Logradouro" element
     */
    boolean isSetLogradouro();
    
    /**
     * Sets the "Logradouro" element
     */
    void setLogradouro(java.lang.String logradouro);
    
    /**
     * Sets (as xml) the "Logradouro" element
     */
    void xsetLogradouro(org.apache.xmlbeans.XmlString logradouro);
    
    /**
     * Nils the "Logradouro" element
     */
    void setNilLogradouro();
    
    /**
     * Unsets the "Logradouro" element
     */
    void unsetLogradouro();
    
    /**
     * Gets the "Nome" element
     */
    java.lang.String getNome();
    
    /**
     * Gets (as xml) the "Nome" element
     */
    org.apache.xmlbeans.XmlString xgetNome();
    
    /**
     * Tests for nil "Nome" element
     */
    boolean isNilNome();
    
    /**
     * True if has "Nome" element
     */
    boolean isSetNome();
    
    /**
     * Sets the "Nome" element
     */
    void setNome(java.lang.String nome);
    
    /**
     * Sets (as xml) the "Nome" element
     */
    void xsetNome(org.apache.xmlbeans.XmlString nome);
    
    /**
     * Nils the "Nome" element
     */
    void setNilNome();
    
    /**
     * Unsets the "Nome" element
     */
    void unsetNome();
    
    /**
     * Gets the "Numero" element
     */
    java.lang.String getNumero();
    
    /**
     * Gets (as xml) the "Numero" element
     */
    org.apache.xmlbeans.XmlString xgetNumero();
    
    /**
     * Tests for nil "Numero" element
     */
    boolean isNilNumero();
    
    /**
     * True if has "Numero" element
     */
    boolean isSetNumero();
    
    /**
     * Sets the "Numero" element
     */
    void setNumero(java.lang.String numero);
    
    /**
     * Sets (as xml) the "Numero" element
     */
    void xsetNumero(org.apache.xmlbeans.XmlString numero);
    
    /**
     * Nils the "Numero" element
     */
    void setNilNumero();
    
    /**
     * Unsets the "Numero" element
     */
    void unsetNumero();
    
    /**
     * Gets the "PN" element
     */
    java.lang.String getPN();
    
    /**
     * Gets (as xml) the "PN" element
     */
    org.apache.xmlbeans.XmlString xgetPN();
    
    /**
     * Tests for nil "PN" element
     */
    boolean isNilPN();
    
    /**
     * True if has "PN" element
     */
    boolean isSetPN();
    
    /**
     * Sets the "PN" element
     */
    void setPN(java.lang.String pn);
    
    /**
     * Sets (as xml) the "PN" element
     */
    void xsetPN(org.apache.xmlbeans.XmlString pn);
    
    /**
     * Nils the "PN" element
     */
    void setNilPN();
    
    /**
     * Unsets the "PN" element
     */
    void unsetPN();
    
    /**
     * Gets the "Produtos" element
     */
    org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO getProdutos();
    
    /**
     * Tests for nil "Produtos" element
     */
    boolean isNilProdutos();
    
    /**
     * True if has "Produtos" element
     */
    boolean isSetProdutos();
    
    /**
     * Sets the "Produtos" element
     */
    void setProdutos(org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO produtos);
    
    /**
     * Appends and returns a new empty "Produtos" element
     */
    org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO addNewProdutos();
    
    /**
     * Nils the "Produtos" element
     */
    void setNilProdutos();
    
    /**
     * Unsets the "Produtos" element
     */
    void unsetProdutos();
    
    /**
     * Gets the "Uf" element
     */
    java.lang.String getUf();
    
    /**
     * Gets (as xml) the "Uf" element
     */
    org.apache.xmlbeans.XmlString xgetUf();
    
    /**
     * Tests for nil "Uf" element
     */
    boolean isNilUf();
    
    /**
     * True if has "Uf" element
     */
    boolean isSetUf();
    
    /**
     * Sets the "Uf" element
     */
    void setUf(java.lang.String uf);
    
    /**
     * Sets (as xml) the "Uf" element
     */
    void xsetUf(org.apache.xmlbeans.XmlString uf);
    
    /**
     * Nils the "Uf" element
     */
    void setNilUf();
    
    /**
     * Unsets the "Uf" element
     */
    void unsetUf();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO newInstance() {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ClienteDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
