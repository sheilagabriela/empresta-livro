/*
 * An XML document type.
 * Localname: ArrayOfConsultaParceiroDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one ArrayOfConsultaParceiroDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class ArrayOfConsultaParceiroDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public ArrayOfConsultaParceiroDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFCONSULTAPARCEIRODTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ArrayOfConsultaParceiroDTO");
    
    
    /**
     * Gets the "ArrayOfConsultaParceiroDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO getArrayOfConsultaParceiroDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO)get_store().find_element_user(ARRAYOFCONSULTAPARCEIRODTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfConsultaParceiroDTO" element
     */
    public boolean isNilArrayOfConsultaParceiroDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO)get_store().find_element_user(ARRAYOFCONSULTAPARCEIRODTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfConsultaParceiroDTO" element
     */
    public void setArrayOfConsultaParceiroDTO(org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO arrayOfConsultaParceiroDTO)
    {
        generatedSetterHelperImpl(arrayOfConsultaParceiroDTO, ARRAYOFCONSULTAPARCEIRODTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ArrayOfConsultaParceiroDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO addNewArrayOfConsultaParceiroDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO)get_store().add_element_user(ARRAYOFCONSULTAPARCEIRODTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfConsultaParceiroDTO" element
     */
    public void setNilArrayOfConsultaParceiroDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO)get_store().find_element_user(ARRAYOFCONSULTAPARCEIRODTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO)get_store().add_element_user(ARRAYOFCONSULTAPARCEIRODTO$0);
            }
            target.setNil();
        }
    }
}
