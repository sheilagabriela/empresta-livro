/*
 * An XML document type.
 * Localname: ArrayOfProdutoDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one ArrayOfProdutoDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class ArrayOfProdutoDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public ArrayOfProdutoDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFPRODUTODTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ArrayOfProdutoDTO");
    
    
    /**
     * Gets the "ArrayOfProdutoDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO getArrayOfProdutoDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO)get_store().find_element_user(ARRAYOFPRODUTODTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfProdutoDTO" element
     */
    public boolean isNilArrayOfProdutoDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO)get_store().find_element_user(ARRAYOFPRODUTODTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfProdutoDTO" element
     */
    public void setArrayOfProdutoDTO(org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO arrayOfProdutoDTO)
    {
        generatedSetterHelperImpl(arrayOfProdutoDTO, ARRAYOFPRODUTODTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ArrayOfProdutoDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO addNewArrayOfProdutoDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO)get_store().add_element_user(ARRAYOFPRODUTODTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfProdutoDTO" element
     */
    public void setNilArrayOfProdutoDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO)get_store().find_element_user(ARRAYOFPRODUTODTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO)get_store().add_element_user(ARRAYOFPRODUTODTO$0);
            }
            target.setNil();
        }
    }
}
