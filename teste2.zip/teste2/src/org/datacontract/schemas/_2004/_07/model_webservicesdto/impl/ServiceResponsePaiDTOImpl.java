/*
 * XML Type:  ServiceResponsePaiDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ServiceResponsePaiDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ServiceResponsePaiDTOImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTO
{
    private static final long serialVersionUID = 1L;
    
    public ServiceResponsePaiDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RESULTADO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Resultado");
    
    
    /**
     * Gets the "Resultado" element
     */
    public java.lang.String getResultado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RESULTADO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Resultado" element
     */
    public org.apache.xmlbeans.XmlString xgetResultado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RESULTADO$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Resultado" element
     */
    public boolean isNilResultado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RESULTADO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Resultado" element
     */
    public boolean isSetResultado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RESULTADO$0) != 0;
        }
    }
    
    /**
     * Sets the "Resultado" element
     */
    public void setResultado(java.lang.String resultado)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RESULTADO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RESULTADO$0);
            }
            target.setStringValue(resultado);
        }
    }
    
    /**
     * Sets (as xml) the "Resultado" element
     */
    public void xsetResultado(org.apache.xmlbeans.XmlString resultado)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RESULTADO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RESULTADO$0);
            }
            target.set(resultado);
        }
    }
    
    /**
     * Nils the "Resultado" element
     */
    public void setNilResultado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RESULTADO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RESULTADO$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Resultado" element
     */
    public void unsetResultado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RESULTADO$0, 0);
        }
    }
}
