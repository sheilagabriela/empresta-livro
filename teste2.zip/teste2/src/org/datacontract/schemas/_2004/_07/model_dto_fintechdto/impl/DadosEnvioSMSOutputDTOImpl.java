/*
 * XML Type:  DadosEnvioSMSOutputDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * An XML DadosEnvioSMSOutputDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public class DadosEnvioSMSOutputDTOImpl extends org.datacontract.schemas._2004._07.model_dto_fintechdto.impl.FintechBaseDTOImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO
{
    private static final long serialVersionUID = 1L;
    
    public DadosEnvioSMSOutputDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
