/*
 * An XML document type.
 * Localname: ArrayOfExclusaoParcelaDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one ArrayOfExclusaoParcelaDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class ArrayOfExclusaoParcelaDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public ArrayOfExclusaoParcelaDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFEXCLUSAOPARCELADTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ArrayOfExclusaoParcelaDTO");
    
    
    /**
     * Gets the "ArrayOfExclusaoParcelaDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO getArrayOfExclusaoParcelaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO)get_store().find_element_user(ARRAYOFEXCLUSAOPARCELADTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfExclusaoParcelaDTO" element
     */
    public boolean isNilArrayOfExclusaoParcelaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO)get_store().find_element_user(ARRAYOFEXCLUSAOPARCELADTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfExclusaoParcelaDTO" element
     */
    public void setArrayOfExclusaoParcelaDTO(org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO arrayOfExclusaoParcelaDTO)
    {
        generatedSetterHelperImpl(arrayOfExclusaoParcelaDTO, ARRAYOFEXCLUSAOPARCELADTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ArrayOfExclusaoParcelaDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO addNewArrayOfExclusaoParcelaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO)get_store().add_element_user(ARRAYOFEXCLUSAOPARCELADTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfExclusaoParcelaDTO" element
     */
    public void setNilArrayOfExclusaoParcelaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO)get_store().find_element_user(ARRAYOFEXCLUSAOPARCELADTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO)get_store().add_element_user(ARRAYOFEXCLUSAOPARCELADTO$0);
            }
            target.setNil();
        }
    }
}
