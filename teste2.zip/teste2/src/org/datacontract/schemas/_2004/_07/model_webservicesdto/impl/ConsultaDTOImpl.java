/*
 * XML Type:  ConsultaDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ConsultaDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ConsultaDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.ServiceRequestPaiDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO
{
    private static final long serialVersionUID = 1L;
    
    public ConsultaDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CNPJ$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "CNPJ");
    private static final javax.xml.namespace.QName CPF$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "CPF");
    private static final javax.xml.namespace.QName INSTALACAO$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Instalacao");
    private static final javax.xml.namespace.QName PFPJ$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "PF_PJ");
    private static final javax.xml.namespace.QName PN$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "PN");
    
    
    /**
     * Gets the "CNPJ" element
     */
    public java.lang.String getCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CNPJ" element
     */
    public org.apache.xmlbeans.XmlString xgetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNPJ$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CNPJ" element
     */
    public boolean isNilCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNPJ$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CNPJ" element
     */
    public boolean isSetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CNPJ$0) != 0;
        }
    }
    
    /**
     * Sets the "CNPJ" element
     */
    public void setCNPJ(java.lang.String cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CNPJ$0);
            }
            target.setStringValue(cnpj);
        }
    }
    
    /**
     * Sets (as xml) the "CNPJ" element
     */
    public void xsetCNPJ(org.apache.xmlbeans.XmlString cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CNPJ$0);
            }
            target.set(cnpj);
        }
    }
    
    /**
     * Nils the "CNPJ" element
     */
    public void setNilCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CNPJ$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CNPJ" element
     */
    public void unsetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CNPJ$0, 0);
        }
    }
    
    /**
     * Gets the "CPF" element
     */
    public java.lang.String getCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CPF" element
     */
    public org.apache.xmlbeans.XmlString xgetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPF$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CPF" element
     */
    public boolean isNilCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPF$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CPF" element
     */
    public boolean isSetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPF$2) != 0;
        }
    }
    
    /**
     * Sets the "CPF" element
     */
    public void setCPF(java.lang.String cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPF$2);
            }
            target.setStringValue(cpf);
        }
    }
    
    /**
     * Sets (as xml) the "CPF" element
     */
    public void xsetCPF(org.apache.xmlbeans.XmlString cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CPF$2);
            }
            target.set(cpf);
        }
    }
    
    /**
     * Nils the "CPF" element
     */
    public void setNilCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CPF$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CPF" element
     */
    public void unsetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPF$2, 0);
        }
    }
    
    /**
     * Gets the "Instalacao" element
     */
    public java.lang.String getInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALACAO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Instalacao" element
     */
    public org.apache.xmlbeans.XmlString xgetInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Instalacao" element
     */
    public boolean isNilInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "Instalacao" element
     */
    public void setInstalacao(java.lang.String instalacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALACAO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSTALACAO$4);
            }
            target.setStringValue(instalacao);
        }
    }
    
    /**
     * Sets (as xml) the "Instalacao" element
     */
    public void xsetInstalacao(org.apache.xmlbeans.XmlString instalacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INSTALACAO$4);
            }
            target.set(instalacao);
        }
    }
    
    /**
     * Nils the "Instalacao" element
     */
    public void setNilInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INSTALACAO$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Gets the "PF_PJ" element
     */
    public int getPFPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PFPJ$6, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "PF_PJ" element
     */
    public org.apache.xmlbeans.XmlInt xgetPFPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(PFPJ$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "PF_PJ" element
     */
    public void setPFPJ(int pfpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PFPJ$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PFPJ$6);
            }
            target.setIntValue(pfpj);
        }
    }
    
    /**
     * Sets (as xml) the "PF_PJ" element
     */
    public void xsetPFPJ(org.apache.xmlbeans.XmlInt pfpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(PFPJ$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(PFPJ$6);
            }
            target.set(pfpj);
        }
    }
    
    /**
     * Gets the "PN" element
     */
    public java.lang.String getPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PN$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "PN" element
     */
    public org.apache.xmlbeans.XmlString xgetPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "PN" element
     */
    public boolean isNilPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "PN" element
     */
    public void setPN(java.lang.String pn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PN$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PN$8);
            }
            target.setStringValue(pn);
        }
    }
    
    /**
     * Sets (as xml) the "PN" element
     */
    public void xsetPN(org.apache.xmlbeans.XmlString pn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PN$8);
            }
            target.set(pn);
        }
    }
    
    /**
     * Nils the "PN" element
     */
    public void setNilPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PN$8);
            }
            target.setNil();
        }
    }
}
