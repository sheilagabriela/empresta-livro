/*
 * An XML document type.
 * Localname: ParcelaProdutoDetalhesDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one ParcelaProdutoDetalhesDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class ParcelaProdutoDetalhesDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public ParcelaProdutoDetalhesDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PARCELAPRODUTODETALHESDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ParcelaProdutoDetalhesDTO");
    
    
    /**
     * Gets the "ParcelaProdutoDetalhesDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO getParcelaProdutoDetalhesDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO)get_store().find_element_user(PARCELAPRODUTODETALHESDTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ParcelaProdutoDetalhesDTO" element
     */
    public boolean isNilParcelaProdutoDetalhesDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO)get_store().find_element_user(PARCELAPRODUTODETALHESDTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ParcelaProdutoDetalhesDTO" element
     */
    public void setParcelaProdutoDetalhesDTO(org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parcelaProdutoDetalhesDTO)
    {
        generatedSetterHelperImpl(parcelaProdutoDetalhesDTO, PARCELAPRODUTODETALHESDTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ParcelaProdutoDetalhesDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO addNewParcelaProdutoDetalhesDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO)get_store().add_element_user(PARCELAPRODUTODETALHESDTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "ParcelaProdutoDetalhesDTO" element
     */
    public void setNilParcelaProdutoDetalhesDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO)get_store().find_element_user(PARCELAPRODUTODETALHESDTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO)get_store().add_element_user(PARCELAPRODUTODETALHESDTO$0);
            }
            target.setNil();
        }
    }
}
