/*
 * XML Type:  ConsultaParceiroDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto;


/**
 * An XML ConsultaParceiroDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public interface ConsultaParceiroDTO extends org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConsultaParceiroDTO.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3965ADB232D1D9A0AB9A333DE5AD2A31").resolveHandle("consultaparceirodto13betype");
    
    /**
     * Gets the "CNPJ" element
     */
    java.lang.String getCNPJ();
    
    /**
     * Gets (as xml) the "CNPJ" element
     */
    org.apache.xmlbeans.XmlString xgetCNPJ();
    
    /**
     * Tests for nil "CNPJ" element
     */
    boolean isNilCNPJ();
    
    /**
     * True if has "CNPJ" element
     */
    boolean isSetCNPJ();
    
    /**
     * Sets the "CNPJ" element
     */
    void setCNPJ(java.lang.String cnpj);
    
    /**
     * Sets (as xml) the "CNPJ" element
     */
    void xsetCNPJ(org.apache.xmlbeans.XmlString cnpj);
    
    /**
     * Nils the "CNPJ" element
     */
    void setNilCNPJ();
    
    /**
     * Unsets the "CNPJ" element
     */
    void unsetCNPJ();
    
    /**
     * Gets the "Cep" element
     */
    java.lang.String getCep();
    
    /**
     * Gets (as xml) the "Cep" element
     */
    org.apache.xmlbeans.XmlString xgetCep();
    
    /**
     * Tests for nil "Cep" element
     */
    boolean isNilCep();
    
    /**
     * True if has "Cep" element
     */
    boolean isSetCep();
    
    /**
     * Sets the "Cep" element
     */
    void setCep(java.lang.String cep);
    
    /**
     * Sets (as xml) the "Cep" element
     */
    void xsetCep(org.apache.xmlbeans.XmlString cep);
    
    /**
     * Nils the "Cep" element
     */
    void setNilCep();
    
    /**
     * Unsets the "Cep" element
     */
    void unsetCep();
    
    /**
     * Gets the "Cidade" element
     */
    java.lang.String getCidade();
    
    /**
     * Gets (as xml) the "Cidade" element
     */
    org.apache.xmlbeans.XmlString xgetCidade();
    
    /**
     * Tests for nil "Cidade" element
     */
    boolean isNilCidade();
    
    /**
     * True if has "Cidade" element
     */
    boolean isSetCidade();
    
    /**
     * Sets the "Cidade" element
     */
    void setCidade(java.lang.String cidade);
    
    /**
     * Sets (as xml) the "Cidade" element
     */
    void xsetCidade(org.apache.xmlbeans.XmlString cidade);
    
    /**
     * Nils the "Cidade" element
     */
    void setNilCidade();
    
    /**
     * Unsets the "Cidade" element
     */
    void unsetCidade();
    
    /**
     * Gets the "CodigoEmpresa" element
     */
    java.lang.String getCodigoEmpresa();
    
    /**
     * Gets (as xml) the "CodigoEmpresa" element
     */
    org.apache.xmlbeans.XmlString xgetCodigoEmpresa();
    
    /**
     * Tests for nil "CodigoEmpresa" element
     */
    boolean isNilCodigoEmpresa();
    
    /**
     * True if has "CodigoEmpresa" element
     */
    boolean isSetCodigoEmpresa();
    
    /**
     * Sets the "CodigoEmpresa" element
     */
    void setCodigoEmpresa(java.lang.String codigoEmpresa);
    
    /**
     * Sets (as xml) the "CodigoEmpresa" element
     */
    void xsetCodigoEmpresa(org.apache.xmlbeans.XmlString codigoEmpresa);
    
    /**
     * Nils the "CodigoEmpresa" element
     */
    void setNilCodigoEmpresa();
    
    /**
     * Unsets the "CodigoEmpresa" element
     */
    void unsetCodigoEmpresa();
    
    /**
     * Gets the "Disponivel_Agencia" element
     */
    java.lang.String getDisponivelAgencia();
    
    /**
     * Gets (as xml) the "Disponivel_Agencia" element
     */
    org.apache.xmlbeans.XmlString xgetDisponivelAgencia();
    
    /**
     * Tests for nil "Disponivel_Agencia" element
     */
    boolean isNilDisponivelAgencia();
    
    /**
     * True if has "Disponivel_Agencia" element
     */
    boolean isSetDisponivelAgencia();
    
    /**
     * Sets the "Disponivel_Agencia" element
     */
    void setDisponivelAgencia(java.lang.String disponivelAgencia);
    
    /**
     * Sets (as xml) the "Disponivel_Agencia" element
     */
    void xsetDisponivelAgencia(org.apache.xmlbeans.XmlString disponivelAgencia);
    
    /**
     * Nils the "Disponivel_Agencia" element
     */
    void setNilDisponivelAgencia();
    
    /**
     * Unsets the "Disponivel_Agencia" element
     */
    void unsetDisponivelAgencia();
    
    /**
     * Gets the "Id_Produto" element
     */
    java.lang.String getIdProduto();
    
    /**
     * Gets (as xml) the "Id_Produto" element
     */
    org.apache.xmlbeans.XmlString xgetIdProduto();
    
    /**
     * Tests for nil "Id_Produto" element
     */
    boolean isNilIdProduto();
    
    /**
     * True if has "Id_Produto" element
     */
    boolean isSetIdProduto();
    
    /**
     * Sets the "Id_Produto" element
     */
    void setIdProduto(java.lang.String idProduto);
    
    /**
     * Sets (as xml) the "Id_Produto" element
     */
    void xsetIdProduto(org.apache.xmlbeans.XmlString idProduto);
    
    /**
     * Nils the "Id_Produto" element
     */
    void setNilIdProduto();
    
    /**
     * Unsets the "Id_Produto" element
     */
    void unsetIdProduto();
    
    /**
     * Gets the "Logradouro" element
     */
    java.lang.String getLogradouro();
    
    /**
     * Gets (as xml) the "Logradouro" element
     */
    org.apache.xmlbeans.XmlString xgetLogradouro();
    
    /**
     * Tests for nil "Logradouro" element
     */
    boolean isNilLogradouro();
    
    /**
     * True if has "Logradouro" element
     */
    boolean isSetLogradouro();
    
    /**
     * Sets the "Logradouro" element
     */
    void setLogradouro(java.lang.String logradouro);
    
    /**
     * Sets (as xml) the "Logradouro" element
     */
    void xsetLogradouro(org.apache.xmlbeans.XmlString logradouro);
    
    /**
     * Nils the "Logradouro" element
     */
    void setNilLogradouro();
    
    /**
     * Unsets the "Logradouro" element
     */
    void unsetLogradouro();
    
    /**
     * Gets the "Nome" element
     */
    java.lang.String getNome();
    
    /**
     * Gets (as xml) the "Nome" element
     */
    org.apache.xmlbeans.XmlString xgetNome();
    
    /**
     * Tests for nil "Nome" element
     */
    boolean isNilNome();
    
    /**
     * True if has "Nome" element
     */
    boolean isSetNome();
    
    /**
     * Sets the "Nome" element
     */
    void setNome(java.lang.String nome);
    
    /**
     * Sets (as xml) the "Nome" element
     */
    void xsetNome(org.apache.xmlbeans.XmlString nome);
    
    /**
     * Nils the "Nome" element
     */
    void setNilNome();
    
    /**
     * Unsets the "Nome" element
     */
    void unsetNome();
    
    /**
     * Gets the "NomeAgenciaVirtual" element
     */
    java.lang.String getNomeAgenciaVirtual();
    
    /**
     * Gets (as xml) the "NomeAgenciaVirtual" element
     */
    org.apache.xmlbeans.XmlString xgetNomeAgenciaVirtual();
    
    /**
     * Tests for nil "NomeAgenciaVirtual" element
     */
    boolean isNilNomeAgenciaVirtual();
    
    /**
     * True if has "NomeAgenciaVirtual" element
     */
    boolean isSetNomeAgenciaVirtual();
    
    /**
     * Sets the "NomeAgenciaVirtual" element
     */
    void setNomeAgenciaVirtual(java.lang.String nomeAgenciaVirtual);
    
    /**
     * Sets (as xml) the "NomeAgenciaVirtual" element
     */
    void xsetNomeAgenciaVirtual(org.apache.xmlbeans.XmlString nomeAgenciaVirtual);
    
    /**
     * Nils the "NomeAgenciaVirtual" element
     */
    void setNilNomeAgenciaVirtual();
    
    /**
     * Unsets the "NomeAgenciaVirtual" element
     */
    void unsetNomeAgenciaVirtual();
    
    /**
     * Gets the "Nome_Produto" element
     */
    java.lang.String getNomeProduto();
    
    /**
     * Gets (as xml) the "Nome_Produto" element
     */
    org.apache.xmlbeans.XmlString xgetNomeProduto();
    
    /**
     * Tests for nil "Nome_Produto" element
     */
    boolean isNilNomeProduto();
    
    /**
     * True if has "Nome_Produto" element
     */
    boolean isSetNomeProduto();
    
    /**
     * Sets the "Nome_Produto" element
     */
    void setNomeProduto(java.lang.String nomeProduto);
    
    /**
     * Sets (as xml) the "Nome_Produto" element
     */
    void xsetNomeProduto(org.apache.xmlbeans.XmlString nomeProduto);
    
    /**
     * Nils the "Nome_Produto" element
     */
    void setNilNomeProduto();
    
    /**
     * Unsets the "Nome_Produto" element
     */
    void unsetNomeProduto();
    
    /**
     * Gets the "Numero" element
     */
    java.lang.String getNumero();
    
    /**
     * Gets (as xml) the "Numero" element
     */
    org.apache.xmlbeans.XmlString xgetNumero();
    
    /**
     * Tests for nil "Numero" element
     */
    boolean isNilNumero();
    
    /**
     * True if has "Numero" element
     */
    boolean isSetNumero();
    
    /**
     * Sets the "Numero" element
     */
    void setNumero(java.lang.String numero);
    
    /**
     * Sets (as xml) the "Numero" element
     */
    void xsetNumero(org.apache.xmlbeans.XmlString numero);
    
    /**
     * Nils the "Numero" element
     */
    void setNilNumero();
    
    /**
     * Unsets the "Numero" element
     */
    void unsetNumero();
    
    /**
     * Gets the "PN" element
     */
    java.lang.String getPN();
    
    /**
     * Gets (as xml) the "PN" element
     */
    org.apache.xmlbeans.XmlString xgetPN();
    
    /**
     * Tests for nil "PN" element
     */
    boolean isNilPN();
    
    /**
     * True if has "PN" element
     */
    boolean isSetPN();
    
    /**
     * Sets the "PN" element
     */
    void setPN(java.lang.String pn);
    
    /**
     * Sets (as xml) the "PN" element
     */
    void xsetPN(org.apache.xmlbeans.XmlString pn);
    
    /**
     * Nils the "PN" element
     */
    void setNilPN();
    
    /**
     * Unsets the "PN" element
     */
    void unsetPN();
    
    /**
     * Gets the "RamoAtividade" element
     */
    java.lang.String getRamoAtividade();
    
    /**
     * Gets (as xml) the "RamoAtividade" element
     */
    org.apache.xmlbeans.XmlString xgetRamoAtividade();
    
    /**
     * Tests for nil "RamoAtividade" element
     */
    boolean isNilRamoAtividade();
    
    /**
     * True if has "RamoAtividade" element
     */
    boolean isSetRamoAtividade();
    
    /**
     * Sets the "RamoAtividade" element
     */
    void setRamoAtividade(java.lang.String ramoAtividade);
    
    /**
     * Sets (as xml) the "RamoAtividade" element
     */
    void xsetRamoAtividade(org.apache.xmlbeans.XmlString ramoAtividade);
    
    /**
     * Nils the "RamoAtividade" element
     */
    void setNilRamoAtividade();
    
    /**
     * Unsets the "RamoAtividade" element
     */
    void unsetRamoAtividade();
    
    /**
     * Gets the "Uf" element
     */
    java.lang.String getUf();
    
    /**
     * Gets (as xml) the "Uf" element
     */
    org.apache.xmlbeans.XmlString xgetUf();
    
    /**
     * Tests for nil "Uf" element
     */
    boolean isNilUf();
    
    /**
     * True if has "Uf" element
     */
    boolean isSetUf();
    
    /**
     * Sets the "Uf" element
     */
    void setUf(java.lang.String uf);
    
    /**
     * Sets (as xml) the "Uf" element
     */
    void xsetUf(org.apache.xmlbeans.XmlString uf);
    
    /**
     * Nils the "Uf" element
     */
    void setNilUf();
    
    /**
     * Unsets the "Uf" element
     */
    void unsetUf();
    
    /**
     * Gets the "Visivel_Agencia" element
     */
    java.lang.String getVisivelAgencia();
    
    /**
     * Gets (as xml) the "Visivel_Agencia" element
     */
    org.apache.xmlbeans.XmlString xgetVisivelAgencia();
    
    /**
     * Tests for nil "Visivel_Agencia" element
     */
    boolean isNilVisivelAgencia();
    
    /**
     * True if has "Visivel_Agencia" element
     */
    boolean isSetVisivelAgencia();
    
    /**
     * Sets the "Visivel_Agencia" element
     */
    void setVisivelAgencia(java.lang.String visivelAgencia);
    
    /**
     * Sets (as xml) the "Visivel_Agencia" element
     */
    void xsetVisivelAgencia(org.apache.xmlbeans.XmlString visivelAgencia);
    
    /**
     * Nils the "Visivel_Agencia" element
     */
    void setNilVisivelAgencia();
    
    /**
     * Unsets the "Visivel_Agencia" element
     */
    void unsetVisivelAgencia();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO newInstance() {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
