/*
 * XML Type:  ParcelaProdutoDetalhesDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto;


/**
 * An XML ParcelaProdutoDetalhesDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public interface ParcelaProdutoDetalhesDTO extends org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ParcelaProdutoDetalhesDTO.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3965ADB232D1D9A0AB9A333DE5AD2A31").resolveHandle("parcelaprodutodetalhesdto5f7ftype");
    
    /**
     * Gets the "CanceladoPor" element
     */
    java.lang.String getCanceladoPor();
    
    /**
     * Gets (as xml) the "CanceladoPor" element
     */
    org.apache.xmlbeans.XmlString xgetCanceladoPor();
    
    /**
     * Tests for nil "CanceladoPor" element
     */
    boolean isNilCanceladoPor();
    
    /**
     * True if has "CanceladoPor" element
     */
    boolean isSetCanceladoPor();
    
    /**
     * Sets the "CanceladoPor" element
     */
    void setCanceladoPor(java.lang.String canceladoPor);
    
    /**
     * Sets (as xml) the "CanceladoPor" element
     */
    void xsetCanceladoPor(org.apache.xmlbeans.XmlString canceladoPor);
    
    /**
     * Nils the "CanceladoPor" element
     */
    void setNilCanceladoPor();
    
    /**
     * Unsets the "CanceladoPor" element
     */
    void unsetCanceladoPor();
    
    /**
     * Gets the "DataCancelamentoCobranca" element
     */
    java.lang.String getDataCancelamentoCobranca();
    
    /**
     * Gets (as xml) the "DataCancelamentoCobranca" element
     */
    org.apache.xmlbeans.XmlString xgetDataCancelamentoCobranca();
    
    /**
     * Tests for nil "DataCancelamentoCobranca" element
     */
    boolean isNilDataCancelamentoCobranca();
    
    /**
     * True if has "DataCancelamentoCobranca" element
     */
    boolean isSetDataCancelamentoCobranca();
    
    /**
     * Sets the "DataCancelamentoCobranca" element
     */
    void setDataCancelamentoCobranca(java.lang.String dataCancelamentoCobranca);
    
    /**
     * Sets (as xml) the "DataCancelamentoCobranca" element
     */
    void xsetDataCancelamentoCobranca(org.apache.xmlbeans.XmlString dataCancelamentoCobranca);
    
    /**
     * Nils the "DataCancelamentoCobranca" element
     */
    void setNilDataCancelamentoCobranca();
    
    /**
     * Unsets the "DataCancelamentoCobranca" element
     */
    void unsetDataCancelamentoCobranca();
    
    /**
     * Gets the "DataVencimento" element
     */
    java.lang.String getDataVencimento();
    
    /**
     * Gets (as xml) the "DataVencimento" element
     */
    org.apache.xmlbeans.XmlString xgetDataVencimento();
    
    /**
     * Tests for nil "DataVencimento" element
     */
    boolean isNilDataVencimento();
    
    /**
     * True if has "DataVencimento" element
     */
    boolean isSetDataVencimento();
    
    /**
     * Sets the "DataVencimento" element
     */
    void setDataVencimento(java.lang.String dataVencimento);
    
    /**
     * Sets (as xml) the "DataVencimento" element
     */
    void xsetDataVencimento(org.apache.xmlbeans.XmlString dataVencimento);
    
    /**
     * Nils the "DataVencimento" element
     */
    void setNilDataVencimento();
    
    /**
     * Unsets the "DataVencimento" element
     */
    void unsetDataVencimento();
    
    /**
     * Gets the "DescMotCancelamento" element
     */
    java.lang.String getDescMotCancelamento();
    
    /**
     * Gets (as xml) the "DescMotCancelamento" element
     */
    org.apache.xmlbeans.XmlString xgetDescMotCancelamento();
    
    /**
     * Tests for nil "DescMotCancelamento" element
     */
    boolean isNilDescMotCancelamento();
    
    /**
     * True if has "DescMotCancelamento" element
     */
    boolean isSetDescMotCancelamento();
    
    /**
     * Sets the "DescMotCancelamento" element
     */
    void setDescMotCancelamento(java.lang.String descMotCancelamento);
    
    /**
     * Sets (as xml) the "DescMotCancelamento" element
     */
    void xsetDescMotCancelamento(org.apache.xmlbeans.XmlString descMotCancelamento);
    
    /**
     * Nils the "DescMotCancelamento" element
     */
    void setNilDescMotCancelamento();
    
    /**
     * Unsets the "DescMotCancelamento" element
     */
    void unsetDescMotCancelamento();
    
    /**
     * Gets the "MesReferencia" element
     */
    java.lang.String getMesReferencia();
    
    /**
     * Gets (as xml) the "MesReferencia" element
     */
    org.apache.xmlbeans.XmlString xgetMesReferencia();
    
    /**
     * Tests for nil "MesReferencia" element
     */
    boolean isNilMesReferencia();
    
    /**
     * True if has "MesReferencia" element
     */
    boolean isSetMesReferencia();
    
    /**
     * Sets the "MesReferencia" element
     */
    void setMesReferencia(java.lang.String mesReferencia);
    
    /**
     * Sets (as xml) the "MesReferencia" element
     */
    void xsetMesReferencia(org.apache.xmlbeans.XmlString mesReferencia);
    
    /**
     * Nils the "MesReferencia" element
     */
    void setNilMesReferencia();
    
    /**
     * Unsets the "MesReferencia" element
     */
    void unsetMesReferencia();
    
    /**
     * Gets the "NumeroParcela" element
     */
    int getNumeroParcela();
    
    /**
     * Gets (as xml) the "NumeroParcela" element
     */
    org.apache.xmlbeans.XmlInt xgetNumeroParcela();
    
    /**
     * True if has "NumeroParcela" element
     */
    boolean isSetNumeroParcela();
    
    /**
     * Sets the "NumeroParcela" element
     */
    void setNumeroParcela(int numeroParcela);
    
    /**
     * Sets (as xml) the "NumeroParcela" element
     */
    void xsetNumeroParcela(org.apache.xmlbeans.XmlInt numeroParcela);
    
    /**
     * Unsets the "NumeroParcela" element
     */
    void unsetNumeroParcela();
    
    /**
     * Gets the "Status" element
     */
    java.lang.String getStatus();
    
    /**
     * Gets (as xml) the "Status" element
     */
    org.apache.xmlbeans.XmlString xgetStatus();
    
    /**
     * Tests for nil "Status" element
     */
    boolean isNilStatus();
    
    /**
     * True if has "Status" element
     */
    boolean isSetStatus();
    
    /**
     * Sets the "Status" element
     */
    void setStatus(java.lang.String status);
    
    /**
     * Sets (as xml) the "Status" element
     */
    void xsetStatus(org.apache.xmlbeans.XmlString status);
    
    /**
     * Nils the "Status" element
     */
    void setNilStatus();
    
    /**
     * Unsets the "Status" element
     */
    void unsetStatus();
    
    /**
     * Gets the "Valor" element
     */
    java.math.BigDecimal getValor();
    
    /**
     * Gets (as xml) the "Valor" element
     */
    org.apache.xmlbeans.XmlDecimal xgetValor();
    
    /**
     * True if has "Valor" element
     */
    boolean isSetValor();
    
    /**
     * Sets the "Valor" element
     */
    void setValor(java.math.BigDecimal valor);
    
    /**
     * Sets (as xml) the "Valor" element
     */
    void xsetValor(org.apache.xmlbeans.XmlDecimal valor);
    
    /**
     * Unsets the "Valor" element
     */
    void unsetValor();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO newInstance() {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
