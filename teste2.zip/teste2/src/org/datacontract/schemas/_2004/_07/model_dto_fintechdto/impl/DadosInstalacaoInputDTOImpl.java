/*
 * XML Type:  DadosInstalacaoInputDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * An XML DadosInstalacaoInputDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public class DadosInstalacaoInputDTOImpl extends org.datacontract.schemas._2004._07.model_dto_fintechdto.impl.FintechBaseInputDTOImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO
{
    private static final long serialVersionUID = 1L;
    
    public DadosInstalacaoInputDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NUMEROINSTALACAO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "NumeroInstalacao");
    
    
    /**
     * Gets the "NumeroInstalacao" element
     */
    public java.lang.String getNumeroInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROINSTALACAO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NumeroInstalacao" element
     */
    public org.apache.xmlbeans.XmlString xgetNumeroInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMEROINSTALACAO$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "NumeroInstalacao" element
     */
    public boolean isNilNumeroInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMEROINSTALACAO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NumeroInstalacao" element
     */
    public boolean isSetNumeroInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMEROINSTALACAO$0) != 0;
        }
    }
    
    /**
     * Sets the "NumeroInstalacao" element
     */
    public void setNumeroInstalacao(java.lang.String numeroInstalacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROINSTALACAO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMEROINSTALACAO$0);
            }
            target.setStringValue(numeroInstalacao);
        }
    }
    
    /**
     * Sets (as xml) the "NumeroInstalacao" element
     */
    public void xsetNumeroInstalacao(org.apache.xmlbeans.XmlString numeroInstalacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMEROINSTALACAO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMEROINSTALACAO$0);
            }
            target.set(numeroInstalacao);
        }
    }
    
    /**
     * Nils the "NumeroInstalacao" element
     */
    public void setNilNumeroInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMEROINSTALACAO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMEROINSTALACAO$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NumeroInstalacao" element
     */
    public void unsetNumeroInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMEROINSTALACAO$0, 0);
        }
    }
}
