/*
 * An XML document type.
 * Localname: DadosEnderecoContrato
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContratoDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * A document containing one DadosEnderecoContrato(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO) element.
 *
 * This is a complex type.
 */
public class DadosEnderecoContratoDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContratoDocument
{
    private static final long serialVersionUID = 1L;
    
    public DadosEnderecoContratoDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DADOSENDERECOCONTRATO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DadosEnderecoContrato");
    
    
    /**
     * Gets the "DadosEnderecoContrato" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato getDadosEnderecoContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato)get_store().find_element_user(DADOSENDERECOCONTRATO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "DadosEnderecoContrato" element
     */
    public boolean isNilDadosEnderecoContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato)get_store().find_element_user(DADOSENDERECOCONTRATO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "DadosEnderecoContrato" element
     */
    public void setDadosEnderecoContrato(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato dadosEnderecoContrato)
    {
        generatedSetterHelperImpl(dadosEnderecoContrato, DADOSENDERECOCONTRATO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "DadosEnderecoContrato" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato addNewDadosEnderecoContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato)get_store().add_element_user(DADOSENDERECOCONTRATO$0);
            return target;
        }
    }
    
    /**
     * Nils the "DadosEnderecoContrato" element
     */
    public void setNilDadosEnderecoContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato)get_store().find_element_user(DADOSENDERECOCONTRATO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato)get_store().add_element_user(DADOSENDERECOCONTRATO$0);
            }
            target.setNil();
        }
    }
}
