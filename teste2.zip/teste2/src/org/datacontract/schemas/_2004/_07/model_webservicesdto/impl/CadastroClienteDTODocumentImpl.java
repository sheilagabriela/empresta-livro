/*
 * An XML document type.
 * Localname: CadastroClienteDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one CadastroClienteDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class CadastroClienteDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public CadastroClienteDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CADASTROCLIENTEDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "CadastroClienteDTO");
    
    
    /**
     * Gets the "CadastroClienteDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO getCadastroClienteDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO)get_store().find_element_user(CADASTROCLIENTEDTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "CadastroClienteDTO" element
     */
    public boolean isNilCadastroClienteDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO)get_store().find_element_user(CADASTROCLIENTEDTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "CadastroClienteDTO" element
     */
    public void setCadastroClienteDTO(org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO cadastroClienteDTO)
    {
        generatedSetterHelperImpl(cadastroClienteDTO, CADASTROCLIENTEDTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CadastroClienteDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO addNewCadastroClienteDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO)get_store().add_element_user(CADASTROCLIENTEDTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "CadastroClienteDTO" element
     */
    public void setNilCadastroClienteDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO)get_store().find_element_user(CADASTROCLIENTEDTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO)get_store().add_element_user(CADASTROCLIENTEDTO$0);
            }
            target.setNil();
        }
    }
}
