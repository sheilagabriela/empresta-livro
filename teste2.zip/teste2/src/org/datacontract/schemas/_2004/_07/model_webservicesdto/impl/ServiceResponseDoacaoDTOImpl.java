/*
 * XML Type:  ServiceResponseDoacaoDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ServiceResponseDoacaoDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ServiceResponseDoacaoDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.ServiceResponsePaiDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDoacaoDTO
{
    private static final long serialVersionUID = 1L;
    
    public ServiceResponseDoacaoDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PROTOCOLO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Protocolo");
    
    
    /**
     * Gets the "Protocolo" element
     */
    public java.lang.String getProtocolo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTOCOLO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Protocolo" element
     */
    public org.apache.xmlbeans.XmlString xgetProtocolo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROTOCOLO$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Protocolo" element
     */
    public boolean isNilProtocolo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROTOCOLO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Protocolo" element
     */
    public boolean isSetProtocolo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTOCOLO$0) != 0;
        }
    }
    
    /**
     * Sets the "Protocolo" element
     */
    public void setProtocolo(java.lang.String protocolo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTOCOLO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROTOCOLO$0);
            }
            target.setStringValue(protocolo);
        }
    }
    
    /**
     * Sets (as xml) the "Protocolo" element
     */
    public void xsetProtocolo(org.apache.xmlbeans.XmlString protocolo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROTOCOLO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PROTOCOLO$0);
            }
            target.set(protocolo);
        }
    }
    
    /**
     * Nils the "Protocolo" element
     */
    public void setNilProtocolo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROTOCOLO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PROTOCOLO$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Protocolo" element
     */
    public void unsetProtocolo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTOCOLO$0, 0);
        }
    }
}
