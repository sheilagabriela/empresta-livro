/*
 * XML Type:  DadosEnvioSMSInputDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSInputDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * An XML DadosEnvioSMSInputDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public class DadosEnvioSMSInputDTOImpl extends org.datacontract.schemas._2004._07.model_dto_fintechdto.impl.FintechBaseInputDTOImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSInputDTO
{
    private static final long serialVersionUID = 1L;
    
    public DadosEnvioSMSInputDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CELULAR$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Celular");
    private static final javax.xml.namespace.QName MENSAGEM$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Mensagem");
    
    
    /**
     * Gets the "Celular" element
     */
    public java.lang.String getCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CELULAR$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Celular" element
     */
    public org.apache.xmlbeans.XmlString xgetCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CELULAR$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Celular" element
     */
    public boolean isNilCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CELULAR$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Celular" element
     */
    public boolean isSetCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CELULAR$0) != 0;
        }
    }
    
    /**
     * Sets the "Celular" element
     */
    public void setCelular(java.lang.String celular)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CELULAR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CELULAR$0);
            }
            target.setStringValue(celular);
        }
    }
    
    /**
     * Sets (as xml) the "Celular" element
     */
    public void xsetCelular(org.apache.xmlbeans.XmlString celular)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CELULAR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CELULAR$0);
            }
            target.set(celular);
        }
    }
    
    /**
     * Nils the "Celular" element
     */
    public void setNilCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CELULAR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CELULAR$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Celular" element
     */
    public void unsetCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CELULAR$0, 0);
        }
    }
    
    /**
     * Gets the "Mensagem" element
     */
    public java.lang.String getMensagem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MENSAGEM$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Mensagem" element
     */
    public org.apache.xmlbeans.XmlString xgetMensagem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MENSAGEM$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Mensagem" element
     */
    public boolean isNilMensagem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MENSAGEM$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Mensagem" element
     */
    public boolean isSetMensagem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MENSAGEM$2) != 0;
        }
    }
    
    /**
     * Sets the "Mensagem" element
     */
    public void setMensagem(java.lang.String mensagem)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MENSAGEM$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MENSAGEM$2);
            }
            target.setStringValue(mensagem);
        }
    }
    
    /**
     * Sets (as xml) the "Mensagem" element
     */
    public void xsetMensagem(org.apache.xmlbeans.XmlString mensagem)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MENSAGEM$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MENSAGEM$2);
            }
            target.set(mensagem);
        }
    }
    
    /**
     * Nils the "Mensagem" element
     */
    public void setNilMensagem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MENSAGEM$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MENSAGEM$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Mensagem" element
     */
    public void unsetMensagem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MENSAGEM$2, 0);
        }
    }
}
