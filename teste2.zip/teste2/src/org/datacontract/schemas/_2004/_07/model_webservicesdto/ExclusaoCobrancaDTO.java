/*
 * XML Type:  ExclusaoCobrancaDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto;


/**
 * An XML ExclusaoCobrancaDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public interface ExclusaoCobrancaDTO extends org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTO
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ExclusaoCobrancaDTO.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3965ADB232D1D9A0AB9A333DE5AD2A31").resolveHandle("exclusaocobrancadto18b5type");
    
    /**
     * Gets the "ListaParcelasExcluir" element
     */
    org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO getListaParcelasExcluir();
    
    /**
     * Tests for nil "ListaParcelasExcluir" element
     */
    boolean isNilListaParcelasExcluir();
    
    /**
     * True if has "ListaParcelasExcluir" element
     */
    boolean isSetListaParcelasExcluir();
    
    /**
     * Sets the "ListaParcelasExcluir" element
     */
    void setListaParcelasExcluir(org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO listaParcelasExcluir);
    
    /**
     * Appends and returns a new empty "ListaParcelasExcluir" element
     */
    org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO addNewListaParcelasExcluir();
    
    /**
     * Nils the "ListaParcelasExcluir" element
     */
    void setNilListaParcelasExcluir();
    
    /**
     * Unsets the "ListaParcelasExcluir" element
     */
    void unsetListaParcelasExcluir();
    
    /**
     * Gets the "MotivoCancelamento" element
     */
    java.lang.String getMotivoCancelamento();
    
    /**
     * Gets (as xml) the "MotivoCancelamento" element
     */
    org.apache.xmlbeans.XmlString xgetMotivoCancelamento();
    
    /**
     * Tests for nil "MotivoCancelamento" element
     */
    boolean isNilMotivoCancelamento();
    
    /**
     * True if has "MotivoCancelamento" element
     */
    boolean isSetMotivoCancelamento();
    
    /**
     * Sets the "MotivoCancelamento" element
     */
    void setMotivoCancelamento(java.lang.String motivoCancelamento);
    
    /**
     * Sets (as xml) the "MotivoCancelamento" element
     */
    void xsetMotivoCancelamento(org.apache.xmlbeans.XmlString motivoCancelamento);
    
    /**
     * Nils the "MotivoCancelamento" element
     */
    void setNilMotivoCancelamento();
    
    /**
     * Unsets the "MotivoCancelamento" element
     */
    void unsetMotivoCancelamento();
    
    /**
     * Gets the "OrigemCancelamento" element
     */
    java.lang.String getOrigemCancelamento();
    
    /**
     * Gets (as xml) the "OrigemCancelamento" element
     */
    org.apache.xmlbeans.XmlString xgetOrigemCancelamento();
    
    /**
     * Tests for nil "OrigemCancelamento" element
     */
    boolean isNilOrigemCancelamento();
    
    /**
     * True if has "OrigemCancelamento" element
     */
    boolean isSetOrigemCancelamento();
    
    /**
     * Sets the "OrigemCancelamento" element
     */
    void setOrigemCancelamento(java.lang.String origemCancelamento);
    
    /**
     * Sets (as xml) the "OrigemCancelamento" element
     */
    void xsetOrigemCancelamento(org.apache.xmlbeans.XmlString origemCancelamento);
    
    /**
     * Nils the "OrigemCancelamento" element
     */
    void setNilOrigemCancelamento();
    
    /**
     * Unsets the "OrigemCancelamento" element
     */
    void unsetOrigemCancelamento();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO newInstance() {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
