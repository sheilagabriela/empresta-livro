/*
 * An XML document type.
 * Localname: ServiceResponseDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one ServiceResponseDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class ServiceResponseDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public ServiceResponseDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICERESPONSEDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ServiceResponseDTO");
    
    
    /**
     * Gets the "ServiceResponseDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO getServiceResponseDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(SERVICERESPONSEDTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ServiceResponseDTO" element
     */
    public boolean isNilServiceResponseDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(SERVICERESPONSEDTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ServiceResponseDTO" element
     */
    public void setServiceResponseDTO(org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO serviceResponseDTO)
    {
        generatedSetterHelperImpl(serviceResponseDTO, SERVICERESPONSEDTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ServiceResponseDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO addNewServiceResponseDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().add_element_user(SERVICERESPONSEDTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "ServiceResponseDTO" element
     */
    public void setNilServiceResponseDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().find_element_user(SERVICERESPONSEDTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponseDTO)get_store().add_element_user(SERVICERESPONSEDTO$0);
            }
            target.setNil();
        }
    }
}
