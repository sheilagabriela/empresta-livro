/*
 * XML Type:  DadosFatura
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto;


/**
 * An XML DadosFatura(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public interface DadosFatura extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(DadosFatura.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3965ADB232D1D9A0AB9A333DE5AD2A31").resolveHandle("dadosfaturaf8aftype");
    
    /**
     * Gets the "Boleto" element
     */
    java.lang.String getBoleto();
    
    /**
     * Gets (as xml) the "Boleto" element
     */
    org.apache.xmlbeans.XmlString xgetBoleto();
    
    /**
     * Tests for nil "Boleto" element
     */
    boolean isNilBoleto();
    
    /**
     * True if has "Boleto" element
     */
    boolean isSetBoleto();
    
    /**
     * Sets the "Boleto" element
     */
    void setBoleto(java.lang.String boleto);
    
    /**
     * Sets (as xml) the "Boleto" element
     */
    void xsetBoleto(org.apache.xmlbeans.XmlString boleto);
    
    /**
     * Nils the "Boleto" element
     */
    void setNilBoleto();
    
    /**
     * Unsets the "Boleto" element
     */
    void unsetBoleto();
    
    /**
     * Gets the "CodigoBarras" element
     */
    java.lang.String getCodigoBarras();
    
    /**
     * Gets (as xml) the "CodigoBarras" element
     */
    org.apache.xmlbeans.XmlString xgetCodigoBarras();
    
    /**
     * Tests for nil "CodigoBarras" element
     */
    boolean isNilCodigoBarras();
    
    /**
     * True if has "CodigoBarras" element
     */
    boolean isSetCodigoBarras();
    
    /**
     * Sets the "CodigoBarras" element
     */
    void setCodigoBarras(java.lang.String codigoBarras);
    
    /**
     * Sets (as xml) the "CodigoBarras" element
     */
    void xsetCodigoBarras(org.apache.xmlbeans.XmlString codigoBarras);
    
    /**
     * Nils the "CodigoBarras" element
     */
    void setNilCodigoBarras();
    
    /**
     * Unsets the "CodigoBarras" element
     */
    void unsetCodigoBarras();
    
    /**
     * Gets the "ContaContrato" element
     */
    java.lang.String getContaContrato();
    
    /**
     * Gets (as xml) the "ContaContrato" element
     */
    org.apache.xmlbeans.XmlString xgetContaContrato();
    
    /**
     * Tests for nil "ContaContrato" element
     */
    boolean isNilContaContrato();
    
    /**
     * True if has "ContaContrato" element
     */
    boolean isSetContaContrato();
    
    /**
     * Sets the "ContaContrato" element
     */
    void setContaContrato(java.lang.String contaContrato);
    
    /**
     * Sets (as xml) the "ContaContrato" element
     */
    void xsetContaContrato(org.apache.xmlbeans.XmlString contaContrato);
    
    /**
     * Nils the "ContaContrato" element
     */
    void setNilContaContrato();
    
    /**
     * Unsets the "ContaContrato" element
     */
    void unsetContaContrato();
    
    /**
     * Gets the "ContaEnviadaCobradora" element
     */
    java.lang.String getContaEnviadaCobradora();
    
    /**
     * Gets (as xml) the "ContaEnviadaCobradora" element
     */
    org.apache.xmlbeans.XmlString xgetContaEnviadaCobradora();
    
    /**
     * Tests for nil "ContaEnviadaCobradora" element
     */
    boolean isNilContaEnviadaCobradora();
    
    /**
     * True if has "ContaEnviadaCobradora" element
     */
    boolean isSetContaEnviadaCobradora();
    
    /**
     * Sets the "ContaEnviadaCobradora" element
     */
    void setContaEnviadaCobradora(java.lang.String contaEnviadaCobradora);
    
    /**
     * Sets (as xml) the "ContaEnviadaCobradora" element
     */
    void xsetContaEnviadaCobradora(org.apache.xmlbeans.XmlString contaEnviadaCobradora);
    
    /**
     * Nils the "ContaEnviadaCobradora" element
     */
    void setNilContaEnviadaCobradora();
    
    /**
     * Unsets the "ContaEnviadaCobradora" element
     */
    void unsetContaEnviadaCobradora();
    
    /**
     * Gets the "Contrato" element
     */
    java.lang.String getContrato();
    
    /**
     * Gets (as xml) the "Contrato" element
     */
    org.apache.xmlbeans.XmlString xgetContrato();
    
    /**
     * Tests for nil "Contrato" element
     */
    boolean isNilContrato();
    
    /**
     * True if has "Contrato" element
     */
    boolean isSetContrato();
    
    /**
     * Sets the "Contrato" element
     */
    void setContrato(java.lang.String contrato);
    
    /**
     * Sets (as xml) the "Contrato" element
     */
    void xsetContrato(org.apache.xmlbeans.XmlString contrato);
    
    /**
     * Nils the "Contrato" element
     */
    void setNilContrato();
    
    /**
     * Unsets the "Contrato" element
     */
    void unsetContrato();
    
    /**
     * Gets the "DataCompensacao" element
     */
    java.util.Calendar getDataCompensacao();
    
    /**
     * Gets (as xml) the "DataCompensacao" element
     */
    org.apache.xmlbeans.XmlDateTime xgetDataCompensacao();
    
    /**
     * Tests for nil "DataCompensacao" element
     */
    boolean isNilDataCompensacao();
    
    /**
     * True if has "DataCompensacao" element
     */
    boolean isSetDataCompensacao();
    
    /**
     * Sets the "DataCompensacao" element
     */
    void setDataCompensacao(java.util.Calendar dataCompensacao);
    
    /**
     * Sets (as xml) the "DataCompensacao" element
     */
    void xsetDataCompensacao(org.apache.xmlbeans.XmlDateTime dataCompensacao);
    
    /**
     * Nils the "DataCompensacao" element
     */
    void setNilDataCompensacao();
    
    /**
     * Unsets the "DataCompensacao" element
     */
    void unsetDataCompensacao();
    
    /**
     * Gets the "DataFatura" element
     */
    java.util.Calendar getDataFatura();
    
    /**
     * Gets (as xml) the "DataFatura" element
     */
    org.apache.xmlbeans.XmlDateTime xgetDataFatura();
    
    /**
     * Tests for nil "DataFatura" element
     */
    boolean isNilDataFatura();
    
    /**
     * True if has "DataFatura" element
     */
    boolean isSetDataFatura();
    
    /**
     * Sets the "DataFatura" element
     */
    void setDataFatura(java.util.Calendar dataFatura);
    
    /**
     * Sets (as xml) the "DataFatura" element
     */
    void xsetDataFatura(org.apache.xmlbeans.XmlDateTime dataFatura);
    
    /**
     * Nils the "DataFatura" element
     */
    void setNilDataFatura();
    
    /**
     * Unsets the "DataFatura" element
     */
    void unsetDataFatura();
    
    /**
     * Gets the "DataFimFornecimento" element
     */
    java.util.Calendar getDataFimFornecimento();
    
    /**
     * Gets (as xml) the "DataFimFornecimento" element
     */
    org.apache.xmlbeans.XmlDateTime xgetDataFimFornecimento();
    
    /**
     * Tests for nil "DataFimFornecimento" element
     */
    boolean isNilDataFimFornecimento();
    
    /**
     * True if has "DataFimFornecimento" element
     */
    boolean isSetDataFimFornecimento();
    
    /**
     * Sets the "DataFimFornecimento" element
     */
    void setDataFimFornecimento(java.util.Calendar dataFimFornecimento);
    
    /**
     * Sets (as xml) the "DataFimFornecimento" element
     */
    void xsetDataFimFornecimento(org.apache.xmlbeans.XmlDateTime dataFimFornecimento);
    
    /**
     * Nils the "DataFimFornecimento" element
     */
    void setNilDataFimFornecimento();
    
    /**
     * Unsets the "DataFimFornecimento" element
     */
    void unsetDataFimFornecimento();
    
    /**
     * Gets the "DataInicioFornecimento" element
     */
    java.util.Calendar getDataInicioFornecimento();
    
    /**
     * Gets (as xml) the "DataInicioFornecimento" element
     */
    org.apache.xmlbeans.XmlDateTime xgetDataInicioFornecimento();
    
    /**
     * Tests for nil "DataInicioFornecimento" element
     */
    boolean isNilDataInicioFornecimento();
    
    /**
     * True if has "DataInicioFornecimento" element
     */
    boolean isSetDataInicioFornecimento();
    
    /**
     * Sets the "DataInicioFornecimento" element
     */
    void setDataInicioFornecimento(java.util.Calendar dataInicioFornecimento);
    
    /**
     * Sets (as xml) the "DataInicioFornecimento" element
     */
    void xsetDataInicioFornecimento(org.apache.xmlbeans.XmlDateTime dataInicioFornecimento);
    
    /**
     * Nils the "DataInicioFornecimento" element
     */
    void setNilDataInicioFornecimento();
    
    /**
     * Unsets the "DataInicioFornecimento" element
     */
    void unsetDataInicioFornecimento();
    
    /**
     * Gets the "DataLimite" element
     */
    java.util.Calendar getDataLimite();
    
    /**
     * Gets (as xml) the "DataLimite" element
     */
    org.apache.xmlbeans.XmlDateTime xgetDataLimite();
    
    /**
     * Tests for nil "DataLimite" element
     */
    boolean isNilDataLimite();
    
    /**
     * True if has "DataLimite" element
     */
    boolean isSetDataLimite();
    
    /**
     * Sets the "DataLimite" element
     */
    void setDataLimite(java.util.Calendar dataLimite);
    
    /**
     * Sets (as xml) the "DataLimite" element
     */
    void xsetDataLimite(org.apache.xmlbeans.XmlDateTime dataLimite);
    
    /**
     * Nils the "DataLimite" element
     */
    void setNilDataLimite();
    
    /**
     * Unsets the "DataLimite" element
     */
    void unsetDataLimite();
    
    /**
     * Gets the "DataPagamento" element
     */
    java.util.Calendar getDataPagamento();
    
    /**
     * Gets (as xml) the "DataPagamento" element
     */
    org.apache.xmlbeans.XmlDateTime xgetDataPagamento();
    
    /**
     * Tests for nil "DataPagamento" element
     */
    boolean isNilDataPagamento();
    
    /**
     * True if has "DataPagamento" element
     */
    boolean isSetDataPagamento();
    
    /**
     * Sets the "DataPagamento" element
     */
    void setDataPagamento(java.util.Calendar dataPagamento);
    
    /**
     * Sets (as xml) the "DataPagamento" element
     */
    void xsetDataPagamento(org.apache.xmlbeans.XmlDateTime dataPagamento);
    
    /**
     * Nils the "DataPagamento" element
     */
    void setNilDataPagamento();
    
    /**
     * Unsets the "DataPagamento" element
     */
    void unsetDataPagamento();
    
    /**
     * Gets the "DataVencimento" element
     */
    java.util.Calendar getDataVencimento();
    
    /**
     * Gets (as xml) the "DataVencimento" element
     */
    org.apache.xmlbeans.XmlDateTime xgetDataVencimento();
    
    /**
     * Tests for nil "DataVencimento" element
     */
    boolean isNilDataVencimento();
    
    /**
     * True if has "DataVencimento" element
     */
    boolean isSetDataVencimento();
    
    /**
     * Sets the "DataVencimento" element
     */
    void setDataVencimento(java.util.Calendar dataVencimento);
    
    /**
     * Sets (as xml) the "DataVencimento" element
     */
    void xsetDataVencimento(org.apache.xmlbeans.XmlDateTime dataVencimento);
    
    /**
     * Nils the "DataVencimento" element
     */
    void setNilDataVencimento();
    
    /**
     * Unsets the "DataVencimento" element
     */
    void unsetDataVencimento();
    
    /**
     * Gets the "DocCCContratual" element
     */
    java.lang.String getDocCCContratual();
    
    /**
     * Gets (as xml) the "DocCCContratual" element
     */
    org.apache.xmlbeans.XmlString xgetDocCCContratual();
    
    /**
     * Tests for nil "DocCCContratual" element
     */
    boolean isNilDocCCContratual();
    
    /**
     * True if has "DocCCContratual" element
     */
    boolean isSetDocCCContratual();
    
    /**
     * Sets the "DocCCContratual" element
     */
    void setDocCCContratual(java.lang.String docCCContratual);
    
    /**
     * Sets (as xml) the "DocCCContratual" element
     */
    void xsetDocCCContratual(org.apache.xmlbeans.XmlString docCCContratual);
    
    /**
     * Nils the "DocCCContratual" element
     */
    void setNilDocCCContratual();
    
    /**
     * Unsets the "DocCCContratual" element
     */
    void unsetDocCCContratual();
    
    /**
     * Gets the "DocReferencia" element
     */
    java.lang.String getDocReferencia();
    
    /**
     * Gets (as xml) the "DocReferencia" element
     */
    org.apache.xmlbeans.XmlString xgetDocReferencia();
    
    /**
     * Tests for nil "DocReferencia" element
     */
    boolean isNilDocReferencia();
    
    /**
     * True if has "DocReferencia" element
     */
    boolean isSetDocReferencia();
    
    /**
     * Sets the "DocReferencia" element
     */
    void setDocReferencia(java.lang.String docReferencia);
    
    /**
     * Sets (as xml) the "DocReferencia" element
     */
    void xsetDocReferencia(org.apache.xmlbeans.XmlString docReferencia);
    
    /**
     * Nils the "DocReferencia" element
     */
    void setNilDocReferencia();
    
    /**
     * Unsets the "DocReferencia" element
     */
    void unsetDocReferencia();
    
    /**
     * Gets the "DtSolicit2aVia" element
     */
    java.lang.String getDtSolicit2AVia();
    
    /**
     * Gets (as xml) the "DtSolicit2aVia" element
     */
    org.apache.xmlbeans.XmlString xgetDtSolicit2AVia();
    
    /**
     * Tests for nil "DtSolicit2aVia" element
     */
    boolean isNilDtSolicit2AVia();
    
    /**
     * True if has "DtSolicit2aVia" element
     */
    boolean isSetDtSolicit2AVia();
    
    /**
     * Sets the "DtSolicit2aVia" element
     */
    void setDtSolicit2AVia(java.lang.String dtSolicit2AVia);
    
    /**
     * Sets (as xml) the "DtSolicit2aVia" element
     */
    void xsetDtSolicit2AVia(org.apache.xmlbeans.XmlString dtSolicit2AVia);
    
    /**
     * Nils the "DtSolicit2aVia" element
     */
    void setNilDtSolicit2AVia();
    
    /**
     * Unsets the "DtSolicit2aVia" element
     */
    void unsetDtSolicit2AVia();
    
    /**
     * Gets the "ExisteParcelamento" element
     */
    java.lang.String getExisteParcelamento();
    
    /**
     * Gets (as xml) the "ExisteParcelamento" element
     */
    org.apache.xmlbeans.XmlString xgetExisteParcelamento();
    
    /**
     * Tests for nil "ExisteParcelamento" element
     */
    boolean isNilExisteParcelamento();
    
    /**
     * True if has "ExisteParcelamento" element
     */
    boolean isSetExisteParcelamento();
    
    /**
     * Sets the "ExisteParcelamento" element
     */
    void setExisteParcelamento(java.lang.String existeParcelamento);
    
    /**
     * Sets (as xml) the "ExisteParcelamento" element
     */
    void xsetExisteParcelamento(org.apache.xmlbeans.XmlString existeParcelamento);
    
    /**
     * Nils the "ExisteParcelamento" element
     */
    void setNilExisteParcelamento();
    
    /**
     * Unsets the "ExisteParcelamento" element
     */
    void unsetExisteParcelamento();
    
    /**
     * Gets the "ExisteReaviso" element
     */
    java.lang.String getExisteReaviso();
    
    /**
     * Gets (as xml) the "ExisteReaviso" element
     */
    org.apache.xmlbeans.XmlString xgetExisteReaviso();
    
    /**
     * Tests for nil "ExisteReaviso" element
     */
    boolean isNilExisteReaviso();
    
    /**
     * True if has "ExisteReaviso" element
     */
    boolean isSetExisteReaviso();
    
    /**
     * Sets the "ExisteReaviso" element
     */
    void setExisteReaviso(java.lang.String existeReaviso);
    
    /**
     * Sets (as xml) the "ExisteReaviso" element
     */
    void xsetExisteReaviso(org.apache.xmlbeans.XmlString existeReaviso);
    
    /**
     * Nils the "ExisteReaviso" element
     */
    void setNilExisteReaviso();
    
    /**
     * Unsets the "ExisteReaviso" element
     */
    void unsetExisteReaviso();
    
    /**
     * Gets the "FormaPagamento" element
     */
    java.lang.String getFormaPagamento();
    
    /**
     * Gets (as xml) the "FormaPagamento" element
     */
    org.apache.xmlbeans.XmlString xgetFormaPagamento();
    
    /**
     * Tests for nil "FormaPagamento" element
     */
    boolean isNilFormaPagamento();
    
    /**
     * True if has "FormaPagamento" element
     */
    boolean isSetFormaPagamento();
    
    /**
     * Sets the "FormaPagamento" element
     */
    void setFormaPagamento(java.lang.String formaPagamento);
    
    /**
     * Sets (as xml) the "FormaPagamento" element
     */
    void xsetFormaPagamento(org.apache.xmlbeans.XmlString formaPagamento);
    
    /**
     * Nils the "FormaPagamento" element
     */
    void setNilFormaPagamento();
    
    /**
     * Unsets the "FormaPagamento" element
     */
    void unsetFormaPagamento();
    
    /**
     * Gets the "MesReferencia" element
     */
    java.lang.String getMesReferencia();
    
    /**
     * Gets (as xml) the "MesReferencia" element
     */
    org.apache.xmlbeans.XmlString xgetMesReferencia();
    
    /**
     * Tests for nil "MesReferencia" element
     */
    boolean isNilMesReferencia();
    
    /**
     * True if has "MesReferencia" element
     */
    boolean isSetMesReferencia();
    
    /**
     * Sets the "MesReferencia" element
     */
    void setMesReferencia(java.lang.String mesReferencia);
    
    /**
     * Sets (as xml) the "MesReferencia" element
     */
    void xsetMesReferencia(org.apache.xmlbeans.XmlString mesReferencia);
    
    /**
     * Nils the "MesReferencia" element
     */
    void setNilMesReferencia();
    
    /**
     * Unsets the "MesReferencia" element
     */
    void unsetMesReferencia();
    
    /**
     * Gets the "NumeroConta" element
     */
    java.lang.String getNumeroConta();
    
    /**
     * Gets (as xml) the "NumeroConta" element
     */
    org.apache.xmlbeans.XmlString xgetNumeroConta();
    
    /**
     * Tests for nil "NumeroConta" element
     */
    boolean isNilNumeroConta();
    
    /**
     * True if has "NumeroConta" element
     */
    boolean isSetNumeroConta();
    
    /**
     * Sets the "NumeroConta" element
     */
    void setNumeroConta(java.lang.String numeroConta);
    
    /**
     * Sets (as xml) the "NumeroConta" element
     */
    void xsetNumeroConta(org.apache.xmlbeans.XmlString numeroConta);
    
    /**
     * Nils the "NumeroConta" element
     */
    void setNilNumeroConta();
    
    /**
     * Unsets the "NumeroConta" element
     */
    void unsetNumeroConta();
    
    /**
     * Gets the "OperacaoPartida" element
     */
    java.lang.String getOperacaoPartida();
    
    /**
     * Gets (as xml) the "OperacaoPartida" element
     */
    org.apache.xmlbeans.XmlString xgetOperacaoPartida();
    
    /**
     * Tests for nil "OperacaoPartida" element
     */
    boolean isNilOperacaoPartida();
    
    /**
     * True if has "OperacaoPartida" element
     */
    boolean isSetOperacaoPartida();
    
    /**
     * Sets the "OperacaoPartida" element
     */
    void setOperacaoPartida(java.lang.String operacaoPartida);
    
    /**
     * Sets (as xml) the "OperacaoPartida" element
     */
    void xsetOperacaoPartida(org.apache.xmlbeans.XmlString operacaoPartida);
    
    /**
     * Nils the "OperacaoPartida" element
     */
    void setNilOperacaoPartida();
    
    /**
     * Unsets the "OperacaoPartida" element
     */
    void unsetOperacaoPartida();
    
    /**
     * Gets the "Parcela" element
     */
    java.lang.String getParcela();
    
    /**
     * Gets (as xml) the "Parcela" element
     */
    org.apache.xmlbeans.XmlString xgetParcela();
    
    /**
     * Tests for nil "Parcela" element
     */
    boolean isNilParcela();
    
    /**
     * True if has "Parcela" element
     */
    boolean isSetParcela();
    
    /**
     * Sets the "Parcela" element
     */
    void setParcela(java.lang.String parcela);
    
    /**
     * Sets (as xml) the "Parcela" element
     */
    void xsetParcela(org.apache.xmlbeans.XmlString parcela);
    
    /**
     * Nils the "Parcela" element
     */
    void setNilParcela();
    
    /**
     * Unsets the "Parcela" element
     */
    void unsetParcela();
    
    /**
     * Gets the "Status" element
     */
    java.lang.String getStatus();
    
    /**
     * Gets (as xml) the "Status" element
     */
    org.apache.xmlbeans.XmlString xgetStatus();
    
    /**
     * Tests for nil "Status" element
     */
    boolean isNilStatus();
    
    /**
     * True if has "Status" element
     */
    boolean isSetStatus();
    
    /**
     * Sets the "Status" element
     */
    void setStatus(java.lang.String status);
    
    /**
     * Sets (as xml) the "Status" element
     */
    void xsetStatus(org.apache.xmlbeans.XmlString status);
    
    /**
     * Nils the "Status" element
     */
    void setNilStatus();
    
    /**
     * Unsets the "Status" element
     */
    void unsetStatus();
    
    /**
     * Gets the "SubOperacaoPartida" element
     */
    java.lang.String getSubOperacaoPartida();
    
    /**
     * Gets (as xml) the "SubOperacaoPartida" element
     */
    org.apache.xmlbeans.XmlString xgetSubOperacaoPartida();
    
    /**
     * Tests for nil "SubOperacaoPartida" element
     */
    boolean isNilSubOperacaoPartida();
    
    /**
     * True if has "SubOperacaoPartida" element
     */
    boolean isSetSubOperacaoPartida();
    
    /**
     * Sets the "SubOperacaoPartida" element
     */
    void setSubOperacaoPartida(java.lang.String subOperacaoPartida);
    
    /**
     * Sets (as xml) the "SubOperacaoPartida" element
     */
    void xsetSubOperacaoPartida(org.apache.xmlbeans.XmlString subOperacaoPartida);
    
    /**
     * Nils the "SubOperacaoPartida" element
     */
    void setNilSubOperacaoPartida();
    
    /**
     * Unsets the "SubOperacaoPartida" element
     */
    void unsetSubOperacaoPartida();
    
    /**
     * Gets the "TipoFatura" element
     */
    java.lang.String getTipoFatura();
    
    /**
     * Gets (as xml) the "TipoFatura" element
     */
    org.apache.xmlbeans.XmlString xgetTipoFatura();
    
    /**
     * Tests for nil "TipoFatura" element
     */
    boolean isNilTipoFatura();
    
    /**
     * True if has "TipoFatura" element
     */
    boolean isSetTipoFatura();
    
    /**
     * Sets the "TipoFatura" element
     */
    void setTipoFatura(java.lang.String tipoFatura);
    
    /**
     * Sets (as xml) the "TipoFatura" element
     */
    void xsetTipoFatura(org.apache.xmlbeans.XmlString tipoFatura);
    
    /**
     * Nils the "TipoFatura" element
     */
    void setNilTipoFatura();
    
    /**
     * Unsets the "TipoFatura" element
     */
    void unsetTipoFatura();
    
    /**
     * Gets the "TipoPartida" element
     */
    java.lang.String getTipoPartida();
    
    /**
     * Gets (as xml) the "TipoPartida" element
     */
    org.apache.xmlbeans.XmlString xgetTipoPartida();
    
    /**
     * Tests for nil "TipoPartida" element
     */
    boolean isNilTipoPartida();
    
    /**
     * True if has "TipoPartida" element
     */
    boolean isSetTipoPartida();
    
    /**
     * Sets the "TipoPartida" element
     */
    void setTipoPartida(java.lang.String tipoPartida);
    
    /**
     * Sets (as xml) the "TipoPartida" element
     */
    void xsetTipoPartida(org.apache.xmlbeans.XmlString tipoPartida);
    
    /**
     * Nils the "TipoPartida" element
     */
    void setNilTipoPartida();
    
    /**
     * Unsets the "TipoPartida" element
     */
    void unsetTipoPartida();
    
    /**
     * Gets the "Valor" element
     */
    java.lang.String getValor();
    
    /**
     * Gets (as xml) the "Valor" element
     */
    org.apache.xmlbeans.XmlString xgetValor();
    
    /**
     * Tests for nil "Valor" element
     */
    boolean isNilValor();
    
    /**
     * True if has "Valor" element
     */
    boolean isSetValor();
    
    /**
     * Sets the "Valor" element
     */
    void setValor(java.lang.String valor);
    
    /**
     * Sets (as xml) the "Valor" element
     */
    void xsetValor(org.apache.xmlbeans.XmlString valor);
    
    /**
     * Nils the "Valor" element
     */
    void setNilValor();
    
    /**
     * Unsets the "Valor" element
     */
    void unsetValor();
    
    /**
     * Gets the "ValorFatura" element
     */
    java.lang.String getValorFatura();
    
    /**
     * Gets (as xml) the "ValorFatura" element
     */
    org.apache.xmlbeans.XmlString xgetValorFatura();
    
    /**
     * Tests for nil "ValorFatura" element
     */
    boolean isNilValorFatura();
    
    /**
     * True if has "ValorFatura" element
     */
    boolean isSetValorFatura();
    
    /**
     * Sets the "ValorFatura" element
     */
    void setValorFatura(java.lang.String valorFatura);
    
    /**
     * Sets (as xml) the "ValorFatura" element
     */
    void xsetValorFatura(org.apache.xmlbeans.XmlString valorFatura);
    
    /**
     * Nils the "ValorFatura" element
     */
    void setNilValorFatura();
    
    /**
     * Unsets the "ValorFatura" element
     */
    void unsetValorFatura();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura newInstance() {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
