/*
 * An XML document type.
 * Localname: InclusaoCobrancaDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one InclusaoCobrancaDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class InclusaoCobrancaDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public InclusaoCobrancaDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INCLUSAOCOBRANCADTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "InclusaoCobrancaDTO");
    
    
    /**
     * Gets the "InclusaoCobrancaDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO getInclusaoCobrancaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO)get_store().find_element_user(INCLUSAOCOBRANCADTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "InclusaoCobrancaDTO" element
     */
    public boolean isNilInclusaoCobrancaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO)get_store().find_element_user(INCLUSAOCOBRANCADTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "InclusaoCobrancaDTO" element
     */
    public void setInclusaoCobrancaDTO(org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO inclusaoCobrancaDTO)
    {
        generatedSetterHelperImpl(inclusaoCobrancaDTO, INCLUSAOCOBRANCADTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "InclusaoCobrancaDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO addNewInclusaoCobrancaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO)get_store().add_element_user(INCLUSAOCOBRANCADTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "InclusaoCobrancaDTO" element
     */
    public void setNilInclusaoCobrancaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO)get_store().find_element_user(INCLUSAOCOBRANCADTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO)get_store().add_element_user(INCLUSAOCOBRANCADTO$0);
            }
            target.setNil();
        }
    }
}
