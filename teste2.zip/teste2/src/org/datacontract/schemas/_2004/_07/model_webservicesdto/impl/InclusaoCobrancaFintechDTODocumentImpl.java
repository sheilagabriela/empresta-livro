/*
 * An XML document type.
 * Localname: InclusaoCobrancaFintechDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one InclusaoCobrancaFintechDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class InclusaoCobrancaFintechDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public InclusaoCobrancaFintechDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INCLUSAOCOBRANCAFINTECHDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "InclusaoCobrancaFintechDTO");
    
    
    /**
     * Gets the "InclusaoCobrancaFintechDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO getInclusaoCobrancaFintechDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO)get_store().find_element_user(INCLUSAOCOBRANCAFINTECHDTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "InclusaoCobrancaFintechDTO" element
     */
    public boolean isNilInclusaoCobrancaFintechDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO)get_store().find_element_user(INCLUSAOCOBRANCAFINTECHDTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "InclusaoCobrancaFintechDTO" element
     */
    public void setInclusaoCobrancaFintechDTO(org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO inclusaoCobrancaFintechDTO)
    {
        generatedSetterHelperImpl(inclusaoCobrancaFintechDTO, INCLUSAOCOBRANCAFINTECHDTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "InclusaoCobrancaFintechDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO addNewInclusaoCobrancaFintechDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO)get_store().add_element_user(INCLUSAOCOBRANCAFINTECHDTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "InclusaoCobrancaFintechDTO" element
     */
    public void setNilInclusaoCobrancaFintechDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO)get_store().find_element_user(INCLUSAOCOBRANCAFINTECHDTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO)get_store().add_element_user(INCLUSAOCOBRANCAFINTECHDTO$0);
            }
            target.setNil();
        }
    }
}
