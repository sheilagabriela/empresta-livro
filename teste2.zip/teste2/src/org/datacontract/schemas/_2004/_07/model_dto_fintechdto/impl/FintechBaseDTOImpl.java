/*
 * XML Type:  FintechBaseDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * An XML FintechBaseDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public class FintechBaseDTOImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseDTO
{
    private static final long serialVersionUID = 1L;
    
    public FintechBaseDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CODIGORETORNO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "CodigoRetorno");
    private static final javax.xml.namespace.QName MENSAGEMRETORNO$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "MensagemRetorno");
    
    
    /**
     * Gets the "CodigoRetorno" element
     */
    public java.lang.String getCodigoRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGORETORNO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoRetorno" element
     */
    public org.apache.xmlbeans.XmlString xgetCodigoRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGORETORNO$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodigoRetorno" element
     */
    public boolean isNilCodigoRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGORETORNO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodigoRetorno" element
     */
    public boolean isSetCodigoRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGORETORNO$0) != 0;
        }
    }
    
    /**
     * Sets the "CodigoRetorno" element
     */
    public void setCodigoRetorno(java.lang.String codigoRetorno)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGORETORNO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGORETORNO$0);
            }
            target.setStringValue(codigoRetorno);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoRetorno" element
     */
    public void xsetCodigoRetorno(org.apache.xmlbeans.XmlString codigoRetorno)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGORETORNO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODIGORETORNO$0);
            }
            target.set(codigoRetorno);
        }
    }
    
    /**
     * Nils the "CodigoRetorno" element
     */
    public void setNilCodigoRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGORETORNO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODIGORETORNO$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodigoRetorno" element
     */
    public void unsetCodigoRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGORETORNO$0, 0);
        }
    }
    
    /**
     * Gets the "MensagemRetorno" element
     */
    public java.lang.String getMensagemRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MENSAGEMRETORNO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "MensagemRetorno" element
     */
    public org.apache.xmlbeans.XmlString xgetMensagemRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MENSAGEMRETORNO$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "MensagemRetorno" element
     */
    public boolean isNilMensagemRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MENSAGEMRETORNO$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "MensagemRetorno" element
     */
    public boolean isSetMensagemRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MENSAGEMRETORNO$2) != 0;
        }
    }
    
    /**
     * Sets the "MensagemRetorno" element
     */
    public void setMensagemRetorno(java.lang.String mensagemRetorno)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MENSAGEMRETORNO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MENSAGEMRETORNO$2);
            }
            target.setStringValue(mensagemRetorno);
        }
    }
    
    /**
     * Sets (as xml) the "MensagemRetorno" element
     */
    public void xsetMensagemRetorno(org.apache.xmlbeans.XmlString mensagemRetorno)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MENSAGEMRETORNO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MENSAGEMRETORNO$2);
            }
            target.set(mensagemRetorno);
        }
    }
    
    /**
     * Nils the "MensagemRetorno" element
     */
    public void setNilMensagemRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MENSAGEMRETORNO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MENSAGEMRETORNO$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "MensagemRetorno" element
     */
    public void unsetMensagemRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MENSAGEMRETORNO$2, 0);
        }
    }
}
