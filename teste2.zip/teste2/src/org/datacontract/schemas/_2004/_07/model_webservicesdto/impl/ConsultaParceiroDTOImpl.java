/*
 * XML Type:  ConsultaParceiroDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ConsultaParceiroDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ConsultaParceiroDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.ServiceRequestPaiDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO
{
    private static final long serialVersionUID = 1L;
    
    public ConsultaParceiroDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CNPJ$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "CNPJ");
    private static final javax.xml.namespace.QName CEP$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Cep");
    private static final javax.xml.namespace.QName CIDADE$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Cidade");
    private static final javax.xml.namespace.QName CODIGOEMPRESA$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "CodigoEmpresa");
    private static final javax.xml.namespace.QName DISPONIVELAGENCIA$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Disponivel_Agencia");
    private static final javax.xml.namespace.QName IDPRODUTO$10 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Id_Produto");
    private static final javax.xml.namespace.QName LOGRADOURO$12 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Logradouro");
    private static final javax.xml.namespace.QName NOME$14 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Nome");
    private static final javax.xml.namespace.QName NOMEAGENCIAVIRTUAL$16 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "NomeAgenciaVirtual");
    private static final javax.xml.namespace.QName NOMEPRODUTO$18 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Nome_Produto");
    private static final javax.xml.namespace.QName NUMERO$20 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Numero");
    private static final javax.xml.namespace.QName PN$22 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "PN");
    private static final javax.xml.namespace.QName RAMOATIVIDADE$24 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "RamoAtividade");
    private static final javax.xml.namespace.QName UF$26 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Uf");
    private static final javax.xml.namespace.QName VISIVELAGENCIA$28 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Visivel_Agencia");
    
    
    /**
     * Gets the "CNPJ" element
     */
    public java.lang.String getCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CNPJ" element
     */
    public org.apache.xmlbeans.XmlString xgetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNPJ$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CNPJ" element
     */
    public boolean isNilCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNPJ$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CNPJ" element
     */
    public boolean isSetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CNPJ$0) != 0;
        }
    }
    
    /**
     * Sets the "CNPJ" element
     */
    public void setCNPJ(java.lang.String cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CNPJ$0);
            }
            target.setStringValue(cnpj);
        }
    }
    
    /**
     * Sets (as xml) the "CNPJ" element
     */
    public void xsetCNPJ(org.apache.xmlbeans.XmlString cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CNPJ$0);
            }
            target.set(cnpj);
        }
    }
    
    /**
     * Nils the "CNPJ" element
     */
    public void setNilCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CNPJ$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CNPJ" element
     */
    public void unsetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CNPJ$0, 0);
        }
    }
    
    /**
     * Gets the "Cep" element
     */
    public java.lang.String getCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Cep" element
     */
    public org.apache.xmlbeans.XmlString xgetCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CEP$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Cep" element
     */
    public boolean isNilCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CEP$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Cep" element
     */
    public boolean isSetCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CEP$2) != 0;
        }
    }
    
    /**
     * Sets the "Cep" element
     */
    public void setCep(java.lang.String cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CEP$2);
            }
            target.setStringValue(cep);
        }
    }
    
    /**
     * Sets (as xml) the "Cep" element
     */
    public void xsetCep(org.apache.xmlbeans.XmlString cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CEP$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CEP$2);
            }
            target.set(cep);
        }
    }
    
    /**
     * Nils the "Cep" element
     */
    public void setNilCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CEP$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CEP$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Cep" element
     */
    public void unsetCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CEP$2, 0);
        }
    }
    
    /**
     * Gets the "Cidade" element
     */
    public java.lang.String getCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CIDADE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Cidade" element
     */
    public org.apache.xmlbeans.XmlString xgetCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CIDADE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Cidade" element
     */
    public boolean isNilCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CIDADE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Cidade" element
     */
    public boolean isSetCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CIDADE$4) != 0;
        }
    }
    
    /**
     * Sets the "Cidade" element
     */
    public void setCidade(java.lang.String cidade)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CIDADE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CIDADE$4);
            }
            target.setStringValue(cidade);
        }
    }
    
    /**
     * Sets (as xml) the "Cidade" element
     */
    public void xsetCidade(org.apache.xmlbeans.XmlString cidade)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CIDADE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CIDADE$4);
            }
            target.set(cidade);
        }
    }
    
    /**
     * Nils the "Cidade" element
     */
    public void setNilCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CIDADE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CIDADE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Cidade" element
     */
    public void unsetCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CIDADE$4, 0);
        }
    }
    
    /**
     * Gets the "CodigoEmpresa" element
     */
    public java.lang.String getCodigoEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOEMPRESA$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoEmpresa" element
     */
    public org.apache.xmlbeans.XmlString xgetCodigoEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOEMPRESA$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodigoEmpresa" element
     */
    public boolean isNilCodigoEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOEMPRESA$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodigoEmpresa" element
     */
    public boolean isSetCodigoEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGOEMPRESA$6) != 0;
        }
    }
    
    /**
     * Sets the "CodigoEmpresa" element
     */
    public void setCodigoEmpresa(java.lang.String codigoEmpresa)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOEMPRESA$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOEMPRESA$6);
            }
            target.setStringValue(codigoEmpresa);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoEmpresa" element
     */
    public void xsetCodigoEmpresa(org.apache.xmlbeans.XmlString codigoEmpresa)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOEMPRESA$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODIGOEMPRESA$6);
            }
            target.set(codigoEmpresa);
        }
    }
    
    /**
     * Nils the "CodigoEmpresa" element
     */
    public void setNilCodigoEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOEMPRESA$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODIGOEMPRESA$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodigoEmpresa" element
     */
    public void unsetCodigoEmpresa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGOEMPRESA$6, 0);
        }
    }
    
    /**
     * Gets the "Disponivel_Agencia" element
     */
    public java.lang.String getDisponivelAgencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DISPONIVELAGENCIA$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Disponivel_Agencia" element
     */
    public org.apache.xmlbeans.XmlString xgetDisponivelAgencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DISPONIVELAGENCIA$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Disponivel_Agencia" element
     */
    public boolean isNilDisponivelAgencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DISPONIVELAGENCIA$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Disponivel_Agencia" element
     */
    public boolean isSetDisponivelAgencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DISPONIVELAGENCIA$8) != 0;
        }
    }
    
    /**
     * Sets the "Disponivel_Agencia" element
     */
    public void setDisponivelAgencia(java.lang.String disponivelAgencia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DISPONIVELAGENCIA$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DISPONIVELAGENCIA$8);
            }
            target.setStringValue(disponivelAgencia);
        }
    }
    
    /**
     * Sets (as xml) the "Disponivel_Agencia" element
     */
    public void xsetDisponivelAgencia(org.apache.xmlbeans.XmlString disponivelAgencia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DISPONIVELAGENCIA$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DISPONIVELAGENCIA$8);
            }
            target.set(disponivelAgencia);
        }
    }
    
    /**
     * Nils the "Disponivel_Agencia" element
     */
    public void setNilDisponivelAgencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DISPONIVELAGENCIA$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DISPONIVELAGENCIA$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Disponivel_Agencia" element
     */
    public void unsetDisponivelAgencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DISPONIVELAGENCIA$8, 0);
        }
    }
    
    /**
     * Gets the "Id_Produto" element
     */
    public java.lang.String getIdProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDPRODUTO$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Id_Produto" element
     */
    public org.apache.xmlbeans.XmlString xgetIdProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPRODUTO$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Id_Produto" element
     */
    public boolean isNilIdProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPRODUTO$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Id_Produto" element
     */
    public boolean isSetIdProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IDPRODUTO$10) != 0;
        }
    }
    
    /**
     * Sets the "Id_Produto" element
     */
    public void setIdProduto(java.lang.String idProduto)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDPRODUTO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IDPRODUTO$10);
            }
            target.setStringValue(idProduto);
        }
    }
    
    /**
     * Sets (as xml) the "Id_Produto" element
     */
    public void xsetIdProduto(org.apache.xmlbeans.XmlString idProduto)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPRODUTO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDPRODUTO$10);
            }
            target.set(idProduto);
        }
    }
    
    /**
     * Nils the "Id_Produto" element
     */
    public void setNilIdProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPRODUTO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDPRODUTO$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Id_Produto" element
     */
    public void unsetIdProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IDPRODUTO$10, 0);
        }
    }
    
    /**
     * Gets the "Logradouro" element
     */
    public java.lang.String getLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LOGRADOURO$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Logradouro" element
     */
    public org.apache.xmlbeans.XmlString xgetLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(LOGRADOURO$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Logradouro" element
     */
    public boolean isNilLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(LOGRADOURO$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Logradouro" element
     */
    public boolean isSetLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LOGRADOURO$12) != 0;
        }
    }
    
    /**
     * Sets the "Logradouro" element
     */
    public void setLogradouro(java.lang.String logradouro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LOGRADOURO$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(LOGRADOURO$12);
            }
            target.setStringValue(logradouro);
        }
    }
    
    /**
     * Sets (as xml) the "Logradouro" element
     */
    public void xsetLogradouro(org.apache.xmlbeans.XmlString logradouro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(LOGRADOURO$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(LOGRADOURO$12);
            }
            target.set(logradouro);
        }
    }
    
    /**
     * Nils the "Logradouro" element
     */
    public void setNilLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(LOGRADOURO$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(LOGRADOURO$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Logradouro" element
     */
    public void unsetLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LOGRADOURO$12, 0);
        }
    }
    
    /**
     * Gets the "Nome" element
     */
    public java.lang.String getNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOME$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Nome" element
     */
    public org.apache.xmlbeans.XmlString xgetNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOME$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Nome" element
     */
    public boolean isNilNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOME$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Nome" element
     */
    public boolean isSetNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOME$14) != 0;
        }
    }
    
    /**
     * Sets the "Nome" element
     */
    public void setNome(java.lang.String nome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOME$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOME$14);
            }
            target.setStringValue(nome);
        }
    }
    
    /**
     * Sets (as xml) the "Nome" element
     */
    public void xsetNome(org.apache.xmlbeans.XmlString nome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOME$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOME$14);
            }
            target.set(nome);
        }
    }
    
    /**
     * Nils the "Nome" element
     */
    public void setNilNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOME$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOME$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Nome" element
     */
    public void unsetNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOME$14, 0);
        }
    }
    
    /**
     * Gets the "NomeAgenciaVirtual" element
     */
    public java.lang.String getNomeAgenciaVirtual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMEAGENCIAVIRTUAL$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NomeAgenciaVirtual" element
     */
    public org.apache.xmlbeans.XmlString xgetNomeAgenciaVirtual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEAGENCIAVIRTUAL$16, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "NomeAgenciaVirtual" element
     */
    public boolean isNilNomeAgenciaVirtual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEAGENCIAVIRTUAL$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NomeAgenciaVirtual" element
     */
    public boolean isSetNomeAgenciaVirtual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOMEAGENCIAVIRTUAL$16) != 0;
        }
    }
    
    /**
     * Sets the "NomeAgenciaVirtual" element
     */
    public void setNomeAgenciaVirtual(java.lang.String nomeAgenciaVirtual)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMEAGENCIAVIRTUAL$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOMEAGENCIAVIRTUAL$16);
            }
            target.setStringValue(nomeAgenciaVirtual);
        }
    }
    
    /**
     * Sets (as xml) the "NomeAgenciaVirtual" element
     */
    public void xsetNomeAgenciaVirtual(org.apache.xmlbeans.XmlString nomeAgenciaVirtual)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEAGENCIAVIRTUAL$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMEAGENCIAVIRTUAL$16);
            }
            target.set(nomeAgenciaVirtual);
        }
    }
    
    /**
     * Nils the "NomeAgenciaVirtual" element
     */
    public void setNilNomeAgenciaVirtual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEAGENCIAVIRTUAL$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMEAGENCIAVIRTUAL$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NomeAgenciaVirtual" element
     */
    public void unsetNomeAgenciaVirtual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOMEAGENCIAVIRTUAL$16, 0);
        }
    }
    
    /**
     * Gets the "Nome_Produto" element
     */
    public java.lang.String getNomeProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMEPRODUTO$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Nome_Produto" element
     */
    public org.apache.xmlbeans.XmlString xgetNomeProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEPRODUTO$18, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Nome_Produto" element
     */
    public boolean isNilNomeProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEPRODUTO$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Nome_Produto" element
     */
    public boolean isSetNomeProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOMEPRODUTO$18) != 0;
        }
    }
    
    /**
     * Sets the "Nome_Produto" element
     */
    public void setNomeProduto(java.lang.String nomeProduto)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMEPRODUTO$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOMEPRODUTO$18);
            }
            target.setStringValue(nomeProduto);
        }
    }
    
    /**
     * Sets (as xml) the "Nome_Produto" element
     */
    public void xsetNomeProduto(org.apache.xmlbeans.XmlString nomeProduto)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEPRODUTO$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMEPRODUTO$18);
            }
            target.set(nomeProduto);
        }
    }
    
    /**
     * Nils the "Nome_Produto" element
     */
    public void setNilNomeProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEPRODUTO$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMEPRODUTO$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Nome_Produto" element
     */
    public void unsetNomeProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOMEPRODUTO$18, 0);
        }
    }
    
    /**
     * Gets the "Numero" element
     */
    public java.lang.String getNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERO$20, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Numero" element
     */
    public org.apache.xmlbeans.XmlString xgetNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMERO$20, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Numero" element
     */
    public boolean isNilNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMERO$20, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Numero" element
     */
    public boolean isSetNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMERO$20) != 0;
        }
    }
    
    /**
     * Sets the "Numero" element
     */
    public void setNumero(java.lang.String numero)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERO$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMERO$20);
            }
            target.setStringValue(numero);
        }
    }
    
    /**
     * Sets (as xml) the "Numero" element
     */
    public void xsetNumero(org.apache.xmlbeans.XmlString numero)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMERO$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMERO$20);
            }
            target.set(numero);
        }
    }
    
    /**
     * Nils the "Numero" element
     */
    public void setNilNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMERO$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMERO$20);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Numero" element
     */
    public void unsetNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMERO$20, 0);
        }
    }
    
    /**
     * Gets the "PN" element
     */
    public java.lang.String getPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PN$22, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "PN" element
     */
    public org.apache.xmlbeans.XmlString xgetPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$22, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "PN" element
     */
    public boolean isNilPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$22, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "PN" element
     */
    public boolean isSetPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PN$22) != 0;
        }
    }
    
    /**
     * Sets the "PN" element
     */
    public void setPN(java.lang.String pn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PN$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PN$22);
            }
            target.setStringValue(pn);
        }
    }
    
    /**
     * Sets (as xml) the "PN" element
     */
    public void xsetPN(org.apache.xmlbeans.XmlString pn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PN$22);
            }
            target.set(pn);
        }
    }
    
    /**
     * Nils the "PN" element
     */
    public void setNilPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PN$22);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "PN" element
     */
    public void unsetPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PN$22, 0);
        }
    }
    
    /**
     * Gets the "RamoAtividade" element
     */
    public java.lang.String getRamoAtividade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RAMOATIVIDADE$24, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "RamoAtividade" element
     */
    public org.apache.xmlbeans.XmlString xgetRamoAtividade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RAMOATIVIDADE$24, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "RamoAtividade" element
     */
    public boolean isNilRamoAtividade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RAMOATIVIDADE$24, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "RamoAtividade" element
     */
    public boolean isSetRamoAtividade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RAMOATIVIDADE$24) != 0;
        }
    }
    
    /**
     * Sets the "RamoAtividade" element
     */
    public void setRamoAtividade(java.lang.String ramoAtividade)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RAMOATIVIDADE$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RAMOATIVIDADE$24);
            }
            target.setStringValue(ramoAtividade);
        }
    }
    
    /**
     * Sets (as xml) the "RamoAtividade" element
     */
    public void xsetRamoAtividade(org.apache.xmlbeans.XmlString ramoAtividade)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RAMOATIVIDADE$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RAMOATIVIDADE$24);
            }
            target.set(ramoAtividade);
        }
    }
    
    /**
     * Nils the "RamoAtividade" element
     */
    public void setNilRamoAtividade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RAMOATIVIDADE$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RAMOATIVIDADE$24);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "RamoAtividade" element
     */
    public void unsetRamoAtividade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RAMOATIVIDADE$24, 0);
        }
    }
    
    /**
     * Gets the "Uf" element
     */
    public java.lang.String getUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UF$26, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Uf" element
     */
    public org.apache.xmlbeans.XmlString xgetUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(UF$26, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Uf" element
     */
    public boolean isNilUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(UF$26, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Uf" element
     */
    public boolean isSetUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(UF$26) != 0;
        }
    }
    
    /**
     * Sets the "Uf" element
     */
    public void setUf(java.lang.String uf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UF$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(UF$26);
            }
            target.setStringValue(uf);
        }
    }
    
    /**
     * Sets (as xml) the "Uf" element
     */
    public void xsetUf(org.apache.xmlbeans.XmlString uf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(UF$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(UF$26);
            }
            target.set(uf);
        }
    }
    
    /**
     * Nils the "Uf" element
     */
    public void setNilUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(UF$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(UF$26);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Uf" element
     */
    public void unsetUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(UF$26, 0);
        }
    }
    
    /**
     * Gets the "Visivel_Agencia" element
     */
    public java.lang.String getVisivelAgencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VISIVELAGENCIA$28, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Visivel_Agencia" element
     */
    public org.apache.xmlbeans.XmlString xgetVisivelAgencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VISIVELAGENCIA$28, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Visivel_Agencia" element
     */
    public boolean isNilVisivelAgencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VISIVELAGENCIA$28, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Visivel_Agencia" element
     */
    public boolean isSetVisivelAgencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VISIVELAGENCIA$28) != 0;
        }
    }
    
    /**
     * Sets the "Visivel_Agencia" element
     */
    public void setVisivelAgencia(java.lang.String visivelAgencia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VISIVELAGENCIA$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VISIVELAGENCIA$28);
            }
            target.setStringValue(visivelAgencia);
        }
    }
    
    /**
     * Sets (as xml) the "Visivel_Agencia" element
     */
    public void xsetVisivelAgencia(org.apache.xmlbeans.XmlString visivelAgencia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VISIVELAGENCIA$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VISIVELAGENCIA$28);
            }
            target.set(visivelAgencia);
        }
    }
    
    /**
     * Nils the "Visivel_Agencia" element
     */
    public void setNilVisivelAgencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VISIVELAGENCIA$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VISIVELAGENCIA$28);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Visivel_Agencia" element
     */
    public void unsetVisivelAgencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VISIVELAGENCIA$28, 0);
        }
    }
}
