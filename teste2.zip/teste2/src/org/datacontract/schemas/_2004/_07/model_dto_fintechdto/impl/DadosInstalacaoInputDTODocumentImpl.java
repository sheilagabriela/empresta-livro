/*
 * An XML document type.
 * Localname: DadosInstalacaoInputDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * A document containing one DadosInstalacaoInputDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO) element.
 *
 * This is a complex type.
 */
public class DadosInstalacaoInputDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public DadosInstalacaoInputDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DADOSINSTALACAOINPUTDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DadosInstalacaoInputDTO");
    
    
    /**
     * Gets the "DadosInstalacaoInputDTO" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO getDadosInstalacaoInputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO)get_store().find_element_user(DADOSINSTALACAOINPUTDTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "DadosInstalacaoInputDTO" element
     */
    public boolean isNilDadosInstalacaoInputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO)get_store().find_element_user(DADOSINSTALACAOINPUTDTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "DadosInstalacaoInputDTO" element
     */
    public void setDadosInstalacaoInputDTO(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO dadosInstalacaoInputDTO)
    {
        generatedSetterHelperImpl(dadosInstalacaoInputDTO, DADOSINSTALACAOINPUTDTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "DadosInstalacaoInputDTO" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO addNewDadosInstalacaoInputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO)get_store().add_element_user(DADOSINSTALACAOINPUTDTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "DadosInstalacaoInputDTO" element
     */
    public void setNilDadosInstalacaoInputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO)get_store().find_element_user(DADOSINSTALACAOINPUTDTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoInputDTO)get_store().add_element_user(DADOSINSTALACAOINPUTDTO$0);
            }
            target.setNil();
        }
    }
}
