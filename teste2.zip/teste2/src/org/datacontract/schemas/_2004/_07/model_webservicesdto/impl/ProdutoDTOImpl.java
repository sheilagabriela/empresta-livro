/*
 * XML Type:  ProdutoDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ProdutoDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ProdutoDTOImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO
{
    private static final long serialVersionUID = 1L;
    
    public ProdutoDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CODIGOPRODUTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "CodigoProduto");
    private static final javax.xml.namespace.QName DESCRICAOPRODUTO$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "DescricaoProduto");
    
    
    /**
     * Gets the "CodigoProduto" element
     */
    public java.lang.String getCodigoProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOPRODUTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoProduto" element
     */
    public org.apache.xmlbeans.XmlString xgetCodigoProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOPRODUTO$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodigoProduto" element
     */
    public boolean isNilCodigoProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOPRODUTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodigoProduto" element
     */
    public boolean isSetCodigoProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGOPRODUTO$0) != 0;
        }
    }
    
    /**
     * Sets the "CodigoProduto" element
     */
    public void setCodigoProduto(java.lang.String codigoProduto)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOPRODUTO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOPRODUTO$0);
            }
            target.setStringValue(codigoProduto);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoProduto" element
     */
    public void xsetCodigoProduto(org.apache.xmlbeans.XmlString codigoProduto)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOPRODUTO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODIGOPRODUTO$0);
            }
            target.set(codigoProduto);
        }
    }
    
    /**
     * Nils the "CodigoProduto" element
     */
    public void setNilCodigoProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOPRODUTO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODIGOPRODUTO$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodigoProduto" element
     */
    public void unsetCodigoProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGOPRODUTO$0, 0);
        }
    }
    
    /**
     * Gets the "DescricaoProduto" element
     */
    public java.lang.String getDescricaoProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRICAOPRODUTO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DescricaoProduto" element
     */
    public org.apache.xmlbeans.XmlString xgetDescricaoProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRICAOPRODUTO$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DescricaoProduto" element
     */
    public boolean isNilDescricaoProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRICAOPRODUTO$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DescricaoProduto" element
     */
    public boolean isSetDescricaoProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DESCRICAOPRODUTO$2) != 0;
        }
    }
    
    /**
     * Sets the "DescricaoProduto" element
     */
    public void setDescricaoProduto(java.lang.String descricaoProduto)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRICAOPRODUTO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DESCRICAOPRODUTO$2);
            }
            target.setStringValue(descricaoProduto);
        }
    }
    
    /**
     * Sets (as xml) the "DescricaoProduto" element
     */
    public void xsetDescricaoProduto(org.apache.xmlbeans.XmlString descricaoProduto)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRICAOPRODUTO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESCRICAOPRODUTO$2);
            }
            target.set(descricaoProduto);
        }
    }
    
    /**
     * Nils the "DescricaoProduto" element
     */
    public void setNilDescricaoProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRICAOPRODUTO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESCRICAOPRODUTO$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DescricaoProduto" element
     */
    public void unsetDescricaoProduto()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DESCRICAOPRODUTO$2, 0);
        }
    }
}
