/*
 * XML Type:  ProdutosDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ProdutosDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ProdutosDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ProdutosDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.ServiceResponsePaiDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ProdutosDTO
{
    private static final long serialVersionUID = 1L;
    
    public ProdutosDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYPRODUTOS$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ArrayProdutos");
    
    
    /**
     * Gets the "ArrayProdutos" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO getArrayProdutos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO)get_store().find_element_user(ARRAYPRODUTOS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayProdutos" element
     */
    public boolean isNilArrayProdutos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO)get_store().find_element_user(ARRAYPRODUTOS$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ArrayProdutos" element
     */
    public boolean isSetArrayProdutos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ARRAYPRODUTOS$0) != 0;
        }
    }
    
    /**
     * Sets the "ArrayProdutos" element
     */
    public void setArrayProdutos(org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO arrayProdutos)
    {
        generatedSetterHelperImpl(arrayProdutos, ARRAYPRODUTOS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ArrayProdutos" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO addNewArrayProdutos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO)get_store().add_element_user(ARRAYPRODUTOS$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayProdutos" element
     */
    public void setNilArrayProdutos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO)get_store().find_element_user(ARRAYPRODUTOS$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO)get_store().add_element_user(ARRAYPRODUTOS$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ArrayProdutos" element
     */
    public void unsetArrayProdutos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ARRAYPRODUTOS$0, 0);
        }
    }
}
