/*
 * XML Type:  ProdutoDetalhesDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto;


/**
 * An XML ProdutoDetalhesDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public interface ProdutoDetalhesDTO extends org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ProdutoDetalhesDTO.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3965ADB232D1D9A0AB9A333DE5AD2A31").resolveHandle("produtodetalhesdtof4a5type");
    
    /**
     * Gets the "CanceladoPor" element
     */
    java.lang.String getCanceladoPor();
    
    /**
     * Gets (as xml) the "CanceladoPor" element
     */
    org.apache.xmlbeans.XmlString xgetCanceladoPor();
    
    /**
     * Tests for nil "CanceladoPor" element
     */
    boolean isNilCanceladoPor();
    
    /**
     * True if has "CanceladoPor" element
     */
    boolean isSetCanceladoPor();
    
    /**
     * Sets the "CanceladoPor" element
     */
    void setCanceladoPor(java.lang.String canceladoPor);
    
    /**
     * Sets (as xml) the "CanceladoPor" element
     */
    void xsetCanceladoPor(org.apache.xmlbeans.XmlString canceladoPor);
    
    /**
     * Nils the "CanceladoPor" element
     */
    void setNilCanceladoPor();
    
    /**
     * Unsets the "CanceladoPor" element
     */
    void unsetCanceladoPor();
    
    /**
     * Gets the "DataCancelamentoCobranca" element
     */
    java.lang.String getDataCancelamentoCobranca();
    
    /**
     * Gets (as xml) the "DataCancelamentoCobranca" element
     */
    org.apache.xmlbeans.XmlString xgetDataCancelamentoCobranca();
    
    /**
     * Tests for nil "DataCancelamentoCobranca" element
     */
    boolean isNilDataCancelamentoCobranca();
    
    /**
     * True if has "DataCancelamentoCobranca" element
     */
    boolean isSetDataCancelamentoCobranca();
    
    /**
     * Sets the "DataCancelamentoCobranca" element
     */
    void setDataCancelamentoCobranca(java.lang.String dataCancelamentoCobranca);
    
    /**
     * Sets (as xml) the "DataCancelamentoCobranca" element
     */
    void xsetDataCancelamentoCobranca(org.apache.xmlbeans.XmlString dataCancelamentoCobranca);
    
    /**
     * Nils the "DataCancelamentoCobranca" element
     */
    void setNilDataCancelamentoCobranca();
    
    /**
     * Unsets the "DataCancelamentoCobranca" element
     */
    void unsetDataCancelamentoCobranca();
    
    /**
     * Gets the "DataCobranca" element
     */
    java.lang.String getDataCobranca();
    
    /**
     * Gets (as xml) the "DataCobranca" element
     */
    org.apache.xmlbeans.XmlString xgetDataCobranca();
    
    /**
     * Tests for nil "DataCobranca" element
     */
    boolean isNilDataCobranca();
    
    /**
     * True if has "DataCobranca" element
     */
    boolean isSetDataCobranca();
    
    /**
     * Sets the "DataCobranca" element
     */
    void setDataCobranca(java.lang.String dataCobranca);
    
    /**
     * Sets (as xml) the "DataCobranca" element
     */
    void xsetDataCobranca(org.apache.xmlbeans.XmlString dataCobranca);
    
    /**
     * Nils the "DataCobranca" element
     */
    void setNilDataCobranca();
    
    /**
     * Unsets the "DataCobranca" element
     */
    void unsetDataCobranca();
    
    /**
     * Gets the "DescMotCancelamento" element
     */
    java.lang.String getDescMotCancelamento();
    
    /**
     * Gets (as xml) the "DescMotCancelamento" element
     */
    org.apache.xmlbeans.XmlString xgetDescMotCancelamento();
    
    /**
     * Tests for nil "DescMotCancelamento" element
     */
    boolean isNilDescMotCancelamento();
    
    /**
     * True if has "DescMotCancelamento" element
     */
    boolean isSetDescMotCancelamento();
    
    /**
     * Sets the "DescMotCancelamento" element
     */
    void setDescMotCancelamento(java.lang.String descMotCancelamento);
    
    /**
     * Sets (as xml) the "DescMotCancelamento" element
     */
    void xsetDescMotCancelamento(org.apache.xmlbeans.XmlString descMotCancelamento);
    
    /**
     * Nils the "DescMotCancelamento" element
     */
    void setNilDescMotCancelamento();
    
    /**
     * Unsets the "DescMotCancelamento" element
     */
    void unsetDescMotCancelamento();
    
    /**
     * Gets the "DescricaoStatus" element
     */
    java.lang.String getDescricaoStatus();
    
    /**
     * Gets (as xml) the "DescricaoStatus" element
     */
    org.apache.xmlbeans.XmlString xgetDescricaoStatus();
    
    /**
     * Tests for nil "DescricaoStatus" element
     */
    boolean isNilDescricaoStatus();
    
    /**
     * True if has "DescricaoStatus" element
     */
    boolean isSetDescricaoStatus();
    
    /**
     * Sets the "DescricaoStatus" element
     */
    void setDescricaoStatus(java.lang.String descricaoStatus);
    
    /**
     * Sets (as xml) the "DescricaoStatus" element
     */
    void xsetDescricaoStatus(org.apache.xmlbeans.XmlString descricaoStatus);
    
    /**
     * Nils the "DescricaoStatus" element
     */
    void setNilDescricaoStatus();
    
    /**
     * Unsets the "DescricaoStatus" element
     */
    void unsetDescricaoStatus();
    
    /**
     * Gets the "DetalheParcelas" element
     */
    org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO getDetalheParcelas();
    
    /**
     * Tests for nil "DetalheParcelas" element
     */
    boolean isNilDetalheParcelas();
    
    /**
     * True if has "DetalheParcelas" element
     */
    boolean isSetDetalheParcelas();
    
    /**
     * Sets the "DetalheParcelas" element
     */
    void setDetalheParcelas(org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO detalheParcelas);
    
    /**
     * Appends and returns a new empty "DetalheParcelas" element
     */
    org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO addNewDetalheParcelas();
    
    /**
     * Nils the "DetalheParcelas" element
     */
    void setNilDetalheParcelas();
    
    /**
     * Unsets the "DetalheParcelas" element
     */
    void unsetDetalheParcelas();
    
    /**
     * Gets the "Identificacao" element
     */
    java.lang.String getIdentificacao();
    
    /**
     * Gets (as xml) the "Identificacao" element
     */
    org.apache.xmlbeans.XmlString xgetIdentificacao();
    
    /**
     * Tests for nil "Identificacao" element
     */
    boolean isNilIdentificacao();
    
    /**
     * True if has "Identificacao" element
     */
    boolean isSetIdentificacao();
    
    /**
     * Sets the "Identificacao" element
     */
    void setIdentificacao(java.lang.String identificacao);
    
    /**
     * Sets (as xml) the "Identificacao" element
     */
    void xsetIdentificacao(org.apache.xmlbeans.XmlString identificacao);
    
    /**
     * Nils the "Identificacao" element
     */
    void setNilIdentificacao();
    
    /**
     * Unsets the "Identificacao" element
     */
    void unsetIdentificacao();
    
    /**
     * Gets the "NomeAnexos" element
     */
    com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring getNomeAnexos();
    
    /**
     * Tests for nil "NomeAnexos" element
     */
    boolean isNilNomeAnexos();
    
    /**
     * True if has "NomeAnexos" element
     */
    boolean isSetNomeAnexos();
    
    /**
     * Sets the "NomeAnexos" element
     */
    void setNomeAnexos(com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring nomeAnexos);
    
    /**
     * Appends and returns a new empty "NomeAnexos" element
     */
    com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring addNewNomeAnexos();
    
    /**
     * Nils the "NomeAnexos" element
     */
    void setNilNomeAnexos();
    
    /**
     * Unsets the "NomeAnexos" element
     */
    void unsetNomeAnexos();
    
    /**
     * Gets the "QtdParcelas" element
     */
    int getQtdParcelas();
    
    /**
     * Gets (as xml) the "QtdParcelas" element
     */
    org.apache.xmlbeans.XmlInt xgetQtdParcelas();
    
    /**
     * True if has "QtdParcelas" element
     */
    boolean isSetQtdParcelas();
    
    /**
     * Sets the "QtdParcelas" element
     */
    void setQtdParcelas(int qtdParcelas);
    
    /**
     * Sets (as xml) the "QtdParcelas" element
     */
    void xsetQtdParcelas(org.apache.xmlbeans.XmlInt qtdParcelas);
    
    /**
     * Unsets the "QtdParcelas" element
     */
    void unsetQtdParcelas();
    
    /**
     * Gets the "Status" element
     */
    int getStatus();
    
    /**
     * Gets (as xml) the "Status" element
     */
    org.apache.xmlbeans.XmlInt xgetStatus();
    
    /**
     * True if has "Status" element
     */
    boolean isSetStatus();
    
    /**
     * Sets the "Status" element
     */
    void setStatus(int status);
    
    /**
     * Sets (as xml) the "Status" element
     */
    void xsetStatus(org.apache.xmlbeans.XmlInt status);
    
    /**
     * Unsets the "Status" element
     */
    void unsetStatus();
    
    /**
     * Gets the "Valor" element
     */
    java.math.BigDecimal getValor();
    
    /**
     * Gets (as xml) the "Valor" element
     */
    org.apache.xmlbeans.XmlDecimal xgetValor();
    
    /**
     * True if has "Valor" element
     */
    boolean isSetValor();
    
    /**
     * Sets the "Valor" element
     */
    void setValor(java.math.BigDecimal valor);
    
    /**
     * Sets (as xml) the "Valor" element
     */
    void xsetValor(org.apache.xmlbeans.XmlDecimal valor);
    
    /**
     * Unsets the "Valor" element
     */
    void unsetValor();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO newInstance() {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
