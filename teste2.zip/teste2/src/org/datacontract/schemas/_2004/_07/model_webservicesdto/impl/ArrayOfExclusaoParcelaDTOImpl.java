/*
 * XML Type:  ArrayOfExclusaoParcelaDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ArrayOfExclusaoParcelaDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ArrayOfExclusaoParcelaDTOImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO
{
    private static final long serialVersionUID = 1L;
    
    public ArrayOfExclusaoParcelaDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EXCLUSAOPARCELADTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ExclusaoParcelaDTO");
    
    
    /**
     * Gets array of all "ExclusaoParcelaDTO" elements
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO[] getExclusaoParcelaDTOArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(EXCLUSAOPARCELADTO$0, targetList);
            org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO[] result = new org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "ExclusaoParcelaDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO getExclusaoParcelaDTOArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO)get_store().find_element_user(EXCLUSAOPARCELADTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "ExclusaoParcelaDTO" element
     */
    public boolean isNilExclusaoParcelaDTOArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO)get_store().find_element_user(EXCLUSAOPARCELADTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "ExclusaoParcelaDTO" element
     */
    public int sizeOfExclusaoParcelaDTOArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXCLUSAOPARCELADTO$0);
        }
    }
    
    /**
     * Sets array of all "ExclusaoParcelaDTO" element  WARNING: This method is not atomicaly synchronized.
     */
    public void setExclusaoParcelaDTOArray(org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO[] exclusaoParcelaDTOArray)
    {
        check_orphaned();
        arraySetterHelper(exclusaoParcelaDTOArray, EXCLUSAOPARCELADTO$0);
    }
    
    /**
     * Sets ith "ExclusaoParcelaDTO" element
     */
    public void setExclusaoParcelaDTOArray(int i, org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO exclusaoParcelaDTO)
    {
        generatedSetterHelperImpl(exclusaoParcelaDTO, EXCLUSAOPARCELADTO$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
    }
    
    /**
     * Nils the ith "ExclusaoParcelaDTO" element
     */
    public void setNilExclusaoParcelaDTOArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO)get_store().find_element_user(EXCLUSAOPARCELADTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "ExclusaoParcelaDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO insertNewExclusaoParcelaDTO(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO)get_store().insert_element_user(EXCLUSAOPARCELADTO$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "ExclusaoParcelaDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO addNewExclusaoParcelaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO)get_store().add_element_user(EXCLUSAOPARCELADTO$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "ExclusaoParcelaDTO" element
     */
    public void removeExclusaoParcelaDTO(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXCLUSAOPARCELADTO$0, i);
        }
    }
}
