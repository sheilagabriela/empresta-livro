/*
 * XML Type:  ExclusaoCobrancaDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ExclusaoCobrancaDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ExclusaoCobrancaDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.CobrancaDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoCobrancaDTO
{
    private static final long serialVersionUID = 1L;
    
    public ExclusaoCobrancaDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName LISTAPARCELASEXCLUIR$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ListaParcelasExcluir");
    private static final javax.xml.namespace.QName MOTIVOCANCELAMENTO$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "MotivoCancelamento");
    private static final javax.xml.namespace.QName ORIGEMCANCELAMENTO$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "OrigemCancelamento");
    
    
    /**
     * Gets the "ListaParcelasExcluir" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO getListaParcelasExcluir()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO)get_store().find_element_user(LISTAPARCELASEXCLUIR$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ListaParcelasExcluir" element
     */
    public boolean isNilListaParcelasExcluir()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO)get_store().find_element_user(LISTAPARCELASEXCLUIR$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ListaParcelasExcluir" element
     */
    public boolean isSetListaParcelasExcluir()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LISTAPARCELASEXCLUIR$0) != 0;
        }
    }
    
    /**
     * Sets the "ListaParcelasExcluir" element
     */
    public void setListaParcelasExcluir(org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO listaParcelasExcluir)
    {
        generatedSetterHelperImpl(listaParcelasExcluir, LISTAPARCELASEXCLUIR$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ListaParcelasExcluir" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO addNewListaParcelasExcluir()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO)get_store().add_element_user(LISTAPARCELASEXCLUIR$0);
            return target;
        }
    }
    
    /**
     * Nils the "ListaParcelasExcluir" element
     */
    public void setNilListaParcelasExcluir()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO)get_store().find_element_user(LISTAPARCELASEXCLUIR$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfExclusaoParcelaDTO)get_store().add_element_user(LISTAPARCELASEXCLUIR$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ListaParcelasExcluir" element
     */
    public void unsetListaParcelasExcluir()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LISTAPARCELASEXCLUIR$0, 0);
        }
    }
    
    /**
     * Gets the "MotivoCancelamento" element
     */
    public java.lang.String getMotivoCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MOTIVOCANCELAMENTO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "MotivoCancelamento" element
     */
    public org.apache.xmlbeans.XmlString xgetMotivoCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MOTIVOCANCELAMENTO$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "MotivoCancelamento" element
     */
    public boolean isNilMotivoCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MOTIVOCANCELAMENTO$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "MotivoCancelamento" element
     */
    public boolean isSetMotivoCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MOTIVOCANCELAMENTO$2) != 0;
        }
    }
    
    /**
     * Sets the "MotivoCancelamento" element
     */
    public void setMotivoCancelamento(java.lang.String motivoCancelamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MOTIVOCANCELAMENTO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MOTIVOCANCELAMENTO$2);
            }
            target.setStringValue(motivoCancelamento);
        }
    }
    
    /**
     * Sets (as xml) the "MotivoCancelamento" element
     */
    public void xsetMotivoCancelamento(org.apache.xmlbeans.XmlString motivoCancelamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MOTIVOCANCELAMENTO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MOTIVOCANCELAMENTO$2);
            }
            target.set(motivoCancelamento);
        }
    }
    
    /**
     * Nils the "MotivoCancelamento" element
     */
    public void setNilMotivoCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MOTIVOCANCELAMENTO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MOTIVOCANCELAMENTO$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "MotivoCancelamento" element
     */
    public void unsetMotivoCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MOTIVOCANCELAMENTO$2, 0);
        }
    }
    
    /**
     * Gets the "OrigemCancelamento" element
     */
    public java.lang.String getOrigemCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ORIGEMCANCELAMENTO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "OrigemCancelamento" element
     */
    public org.apache.xmlbeans.XmlString xgetOrigemCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ORIGEMCANCELAMENTO$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "OrigemCancelamento" element
     */
    public boolean isNilOrigemCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ORIGEMCANCELAMENTO$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "OrigemCancelamento" element
     */
    public boolean isSetOrigemCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ORIGEMCANCELAMENTO$4) != 0;
        }
    }
    
    /**
     * Sets the "OrigemCancelamento" element
     */
    public void setOrigemCancelamento(java.lang.String origemCancelamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ORIGEMCANCELAMENTO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ORIGEMCANCELAMENTO$4);
            }
            target.setStringValue(origemCancelamento);
        }
    }
    
    /**
     * Sets (as xml) the "OrigemCancelamento" element
     */
    public void xsetOrigemCancelamento(org.apache.xmlbeans.XmlString origemCancelamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ORIGEMCANCELAMENTO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ORIGEMCANCELAMENTO$4);
            }
            target.set(origemCancelamento);
        }
    }
    
    /**
     * Nils the "OrigemCancelamento" element
     */
    public void setNilOrigemCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ORIGEMCANCELAMENTO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ORIGEMCANCELAMENTO$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "OrigemCancelamento" element
     */
    public void unsetOrigemCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ORIGEMCANCELAMENTO$4, 0);
        }
    }
}
