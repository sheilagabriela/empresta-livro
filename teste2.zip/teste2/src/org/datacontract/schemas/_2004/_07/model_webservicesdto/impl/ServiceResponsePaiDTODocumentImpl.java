/*
 * An XML document type.
 * Localname: ServiceResponsePaiDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one ServiceResponsePaiDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class ServiceResponsePaiDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public ServiceResponsePaiDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICERESPONSEPAIDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ServiceResponsePaiDTO");
    
    
    /**
     * Gets the "ServiceResponsePaiDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTO getServiceResponsePaiDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTO)get_store().find_element_user(SERVICERESPONSEPAIDTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ServiceResponsePaiDTO" element
     */
    public boolean isNilServiceResponsePaiDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTO)get_store().find_element_user(SERVICERESPONSEPAIDTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ServiceResponsePaiDTO" element
     */
    public void setServiceResponsePaiDTO(org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTO serviceResponsePaiDTO)
    {
        generatedSetterHelperImpl(serviceResponsePaiDTO, SERVICERESPONSEPAIDTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ServiceResponsePaiDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTO addNewServiceResponsePaiDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTO)get_store().add_element_user(SERVICERESPONSEPAIDTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "ServiceResponsePaiDTO" element
     */
    public void setNilServiceResponsePaiDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTO)get_store().find_element_user(SERVICERESPONSEPAIDTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceResponsePaiDTO)get_store().add_element_user(SERVICERESPONSEPAIDTO$0);
            }
            target.setNil();
        }
    }
}
