/*
 * An XML document type.
 * Localname: DadosInstalacaoOutputDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * A document containing one DadosInstalacaoOutputDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO) element.
 *
 * This is a complex type.
 */
public class DadosInstalacaoOutputDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public DadosInstalacaoOutputDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DADOSINSTALACAOOUTPUTDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DadosInstalacaoOutputDTO");
    
    
    /**
     * Gets the "DadosInstalacaoOutputDTO" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO getDadosInstalacaoOutputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO)get_store().find_element_user(DADOSINSTALACAOOUTPUTDTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "DadosInstalacaoOutputDTO" element
     */
    public boolean isNilDadosInstalacaoOutputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO)get_store().find_element_user(DADOSINSTALACAOOUTPUTDTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "DadosInstalacaoOutputDTO" element
     */
    public void setDadosInstalacaoOutputDTO(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO dadosInstalacaoOutputDTO)
    {
        generatedSetterHelperImpl(dadosInstalacaoOutputDTO, DADOSINSTALACAOOUTPUTDTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "DadosInstalacaoOutputDTO" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO addNewDadosInstalacaoOutputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO)get_store().add_element_user(DADOSINSTALACAOOUTPUTDTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "DadosInstalacaoOutputDTO" element
     */
    public void setNilDadosInstalacaoOutputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO)get_store().find_element_user(DADOSINSTALACAOOUTPUTDTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO)get_store().add_element_user(DADOSINSTALACAOOUTPUTDTO$0);
            }
            target.setNil();
        }
    }
}
