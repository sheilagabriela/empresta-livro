/*
 * XML Type:  ParcelaProdutoDetalhesDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ParcelaProdutoDetalhesDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ParcelaProdutoDetalhesDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.ProdutoDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO
{
    private static final long serialVersionUID = 1L;
    
    public ParcelaProdutoDetalhesDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CANCELADOPOR$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "CanceladoPor");
    private static final javax.xml.namespace.QName DATACANCELAMENTOCOBRANCA$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "DataCancelamentoCobranca");
    private static final javax.xml.namespace.QName DATAVENCIMENTO$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "DataVencimento");
    private static final javax.xml.namespace.QName DESCMOTCANCELAMENTO$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "DescMotCancelamento");
    private static final javax.xml.namespace.QName MESREFERENCIA$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "MesReferencia");
    private static final javax.xml.namespace.QName NUMEROPARCELA$10 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "NumeroParcela");
    private static final javax.xml.namespace.QName STATUS$12 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Status");
    private static final javax.xml.namespace.QName VALOR$14 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Valor");
    
    
    /**
     * Gets the "CanceladoPor" element
     */
    public java.lang.String getCanceladoPor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CANCELADOPOR$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CanceladoPor" element
     */
    public org.apache.xmlbeans.XmlString xgetCanceladoPor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CANCELADOPOR$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CanceladoPor" element
     */
    public boolean isNilCanceladoPor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CANCELADOPOR$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CanceladoPor" element
     */
    public boolean isSetCanceladoPor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CANCELADOPOR$0) != 0;
        }
    }
    
    /**
     * Sets the "CanceladoPor" element
     */
    public void setCanceladoPor(java.lang.String canceladoPor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CANCELADOPOR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CANCELADOPOR$0);
            }
            target.setStringValue(canceladoPor);
        }
    }
    
    /**
     * Sets (as xml) the "CanceladoPor" element
     */
    public void xsetCanceladoPor(org.apache.xmlbeans.XmlString canceladoPor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CANCELADOPOR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CANCELADOPOR$0);
            }
            target.set(canceladoPor);
        }
    }
    
    /**
     * Nils the "CanceladoPor" element
     */
    public void setNilCanceladoPor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CANCELADOPOR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CANCELADOPOR$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CanceladoPor" element
     */
    public void unsetCanceladoPor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CANCELADOPOR$0, 0);
        }
    }
    
    /**
     * Gets the "DataCancelamentoCobranca" element
     */
    public java.lang.String getDataCancelamentoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATACANCELAMENTOCOBRANCA$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataCancelamentoCobranca" element
     */
    public org.apache.xmlbeans.XmlString xgetDataCancelamentoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATACANCELAMENTOCOBRANCA$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataCancelamentoCobranca" element
     */
    public boolean isNilDataCancelamentoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATACANCELAMENTOCOBRANCA$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataCancelamentoCobranca" element
     */
    public boolean isSetDataCancelamentoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATACANCELAMENTOCOBRANCA$2) != 0;
        }
    }
    
    /**
     * Sets the "DataCancelamentoCobranca" element
     */
    public void setDataCancelamentoCobranca(java.lang.String dataCancelamentoCobranca)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATACANCELAMENTOCOBRANCA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATACANCELAMENTOCOBRANCA$2);
            }
            target.setStringValue(dataCancelamentoCobranca);
        }
    }
    
    /**
     * Sets (as xml) the "DataCancelamentoCobranca" element
     */
    public void xsetDataCancelamentoCobranca(org.apache.xmlbeans.XmlString dataCancelamentoCobranca)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATACANCELAMENTOCOBRANCA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATACANCELAMENTOCOBRANCA$2);
            }
            target.set(dataCancelamentoCobranca);
        }
    }
    
    /**
     * Nils the "DataCancelamentoCobranca" element
     */
    public void setNilDataCancelamentoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATACANCELAMENTOCOBRANCA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATACANCELAMENTOCOBRANCA$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataCancelamentoCobranca" element
     */
    public void unsetDataCancelamentoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATACANCELAMENTOCOBRANCA$2, 0);
        }
    }
    
    /**
     * Gets the "DataVencimento" element
     */
    public java.lang.String getDataVencimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAVENCIMENTO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataVencimento" element
     */
    public org.apache.xmlbeans.XmlString xgetDataVencimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAVENCIMENTO$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataVencimento" element
     */
    public boolean isNilDataVencimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAVENCIMENTO$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataVencimento" element
     */
    public boolean isSetDataVencimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATAVENCIMENTO$4) != 0;
        }
    }
    
    /**
     * Sets the "DataVencimento" element
     */
    public void setDataVencimento(java.lang.String dataVencimento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAVENCIMENTO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAVENCIMENTO$4);
            }
            target.setStringValue(dataVencimento);
        }
    }
    
    /**
     * Sets (as xml) the "DataVencimento" element
     */
    public void xsetDataVencimento(org.apache.xmlbeans.XmlString dataVencimento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAVENCIMENTO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATAVENCIMENTO$4);
            }
            target.set(dataVencimento);
        }
    }
    
    /**
     * Nils the "DataVencimento" element
     */
    public void setNilDataVencimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAVENCIMENTO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATAVENCIMENTO$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataVencimento" element
     */
    public void unsetDataVencimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATAVENCIMENTO$4, 0);
        }
    }
    
    /**
     * Gets the "DescMotCancelamento" element
     */
    public java.lang.String getDescMotCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCMOTCANCELAMENTO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DescMotCancelamento" element
     */
    public org.apache.xmlbeans.XmlString xgetDescMotCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCMOTCANCELAMENTO$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DescMotCancelamento" element
     */
    public boolean isNilDescMotCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCMOTCANCELAMENTO$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DescMotCancelamento" element
     */
    public boolean isSetDescMotCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DESCMOTCANCELAMENTO$6) != 0;
        }
    }
    
    /**
     * Sets the "DescMotCancelamento" element
     */
    public void setDescMotCancelamento(java.lang.String descMotCancelamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCMOTCANCELAMENTO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DESCMOTCANCELAMENTO$6);
            }
            target.setStringValue(descMotCancelamento);
        }
    }
    
    /**
     * Sets (as xml) the "DescMotCancelamento" element
     */
    public void xsetDescMotCancelamento(org.apache.xmlbeans.XmlString descMotCancelamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCMOTCANCELAMENTO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESCMOTCANCELAMENTO$6);
            }
            target.set(descMotCancelamento);
        }
    }
    
    /**
     * Nils the "DescMotCancelamento" element
     */
    public void setNilDescMotCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCMOTCANCELAMENTO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESCMOTCANCELAMENTO$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DescMotCancelamento" element
     */
    public void unsetDescMotCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DESCMOTCANCELAMENTO$6, 0);
        }
    }
    
    /**
     * Gets the "MesReferencia" element
     */
    public java.lang.String getMesReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MESREFERENCIA$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "MesReferencia" element
     */
    public org.apache.xmlbeans.XmlString xgetMesReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MESREFERENCIA$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "MesReferencia" element
     */
    public boolean isNilMesReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MESREFERENCIA$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "MesReferencia" element
     */
    public boolean isSetMesReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MESREFERENCIA$8) != 0;
        }
    }
    
    /**
     * Sets the "MesReferencia" element
     */
    public void setMesReferencia(java.lang.String mesReferencia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MESREFERENCIA$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MESREFERENCIA$8);
            }
            target.setStringValue(mesReferencia);
        }
    }
    
    /**
     * Sets (as xml) the "MesReferencia" element
     */
    public void xsetMesReferencia(org.apache.xmlbeans.XmlString mesReferencia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MESREFERENCIA$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MESREFERENCIA$8);
            }
            target.set(mesReferencia);
        }
    }
    
    /**
     * Nils the "MesReferencia" element
     */
    public void setNilMesReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MESREFERENCIA$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MESREFERENCIA$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "MesReferencia" element
     */
    public void unsetMesReferencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MESREFERENCIA$8, 0);
        }
    }
    
    /**
     * Gets the "NumeroParcela" element
     */
    public int getNumeroParcela()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROPARCELA$10, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "NumeroParcela" element
     */
    public org.apache.xmlbeans.XmlInt xgetNumeroParcela()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(NUMEROPARCELA$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "NumeroParcela" element
     */
    public boolean isSetNumeroParcela()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMEROPARCELA$10) != 0;
        }
    }
    
    /**
     * Sets the "NumeroParcela" element
     */
    public void setNumeroParcela(int numeroParcela)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROPARCELA$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMEROPARCELA$10);
            }
            target.setIntValue(numeroParcela);
        }
    }
    
    /**
     * Sets (as xml) the "NumeroParcela" element
     */
    public void xsetNumeroParcela(org.apache.xmlbeans.XmlInt numeroParcela)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(NUMEROPARCELA$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(NUMEROPARCELA$10);
            }
            target.set(numeroParcela);
        }
    }
    
    /**
     * Unsets the "NumeroParcela" element
     */
    public void unsetNumeroParcela()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMEROPARCELA$10, 0);
        }
    }
    
    /**
     * Gets the "Status" element
     */
    public java.lang.String getStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STATUS$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Status" element
     */
    public org.apache.xmlbeans.XmlString xgetStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(STATUS$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Status" element
     */
    public boolean isNilStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(STATUS$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Status" element
     */
    public boolean isSetStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(STATUS$12) != 0;
        }
    }
    
    /**
     * Sets the "Status" element
     */
    public void setStatus(java.lang.String status)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STATUS$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(STATUS$12);
            }
            target.setStringValue(status);
        }
    }
    
    /**
     * Sets (as xml) the "Status" element
     */
    public void xsetStatus(org.apache.xmlbeans.XmlString status)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(STATUS$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(STATUS$12);
            }
            target.set(status);
        }
    }
    
    /**
     * Nils the "Status" element
     */
    public void setNilStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(STATUS$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(STATUS$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Status" element
     */
    public void unsetStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(STATUS$12, 0);
        }
    }
    
    /**
     * Gets the "Valor" element
     */
    public java.math.BigDecimal getValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALOR$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "Valor" element
     */
    public org.apache.xmlbeans.XmlDecimal xgetValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDecimal target = null;
            target = (org.apache.xmlbeans.XmlDecimal)get_store().find_element_user(VALOR$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "Valor" element
     */
    public boolean isSetValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALOR$14) != 0;
        }
    }
    
    /**
     * Sets the "Valor" element
     */
    public void setValor(java.math.BigDecimal valor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALOR$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALOR$14);
            }
            target.setBigDecimalValue(valor);
        }
    }
    
    /**
     * Sets (as xml) the "Valor" element
     */
    public void xsetValor(org.apache.xmlbeans.XmlDecimal valor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDecimal target = null;
            target = (org.apache.xmlbeans.XmlDecimal)get_store().find_element_user(VALOR$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDecimal)get_store().add_element_user(VALOR$14);
            }
            target.set(valor);
        }
    }
    
    /**
     * Unsets the "Valor" element
     */
    public void unsetValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALOR$14, 0);
        }
    }
}
