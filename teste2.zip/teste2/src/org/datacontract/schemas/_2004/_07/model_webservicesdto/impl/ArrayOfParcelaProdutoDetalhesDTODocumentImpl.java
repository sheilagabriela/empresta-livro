/*
 * An XML document type.
 * Localname: ArrayOfParcelaProdutoDetalhesDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one ArrayOfParcelaProdutoDetalhesDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class ArrayOfParcelaProdutoDetalhesDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public ArrayOfParcelaProdutoDetalhesDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFPARCELAPRODUTODETALHESDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ArrayOfParcelaProdutoDetalhesDTO");
    
    
    /**
     * Gets the "ArrayOfParcelaProdutoDetalhesDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO getArrayOfParcelaProdutoDetalhesDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO)get_store().find_element_user(ARRAYOFPARCELAPRODUTODETALHESDTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfParcelaProdutoDetalhesDTO" element
     */
    public boolean isNilArrayOfParcelaProdutoDetalhesDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO)get_store().find_element_user(ARRAYOFPARCELAPRODUTODETALHESDTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfParcelaProdutoDetalhesDTO" element
     */
    public void setArrayOfParcelaProdutoDetalhesDTO(org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO arrayOfParcelaProdutoDetalhesDTO)
    {
        generatedSetterHelperImpl(arrayOfParcelaProdutoDetalhesDTO, ARRAYOFPARCELAPRODUTODETALHESDTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ArrayOfParcelaProdutoDetalhesDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO addNewArrayOfParcelaProdutoDetalhesDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO)get_store().add_element_user(ARRAYOFPARCELAPRODUTODETALHESDTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfParcelaProdutoDetalhesDTO" element
     */
    public void setNilArrayOfParcelaProdutoDetalhesDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO)get_store().find_element_user(ARRAYOFPARCELAPRODUTODETALHESDTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO)get_store().add_element_user(ARRAYOFPARCELAPRODUTODETALHESDTO$0);
            }
            target.setNil();
        }
    }
}
