/*
 * XML Type:  ArrayOfDadosContrato
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosContrato
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * An XML ArrayOfDadosContrato(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public class ArrayOfDadosContratoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosContrato
{
    private static final long serialVersionUID = 1L;
    
    public ArrayOfDadosContratoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DADOSCONTRATO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DadosContrato");
    
    
    /**
     * Gets array of all "DadosContrato" elements
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato[] getDadosContratoArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(DADOSCONTRATO$0, targetList);
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato[] result = new org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "DadosContrato" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato getDadosContratoArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato)get_store().find_element_user(DADOSCONTRATO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "DadosContrato" element
     */
    public boolean isNilDadosContratoArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato)get_store().find_element_user(DADOSCONTRATO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "DadosContrato" element
     */
    public int sizeOfDadosContratoArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DADOSCONTRATO$0);
        }
    }
    
    /**
     * Sets array of all "DadosContrato" element  WARNING: This method is not atomicaly synchronized.
     */
    public void setDadosContratoArray(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato[] dadosContratoArray)
    {
        check_orphaned();
        arraySetterHelper(dadosContratoArray, DADOSCONTRATO$0);
    }
    
    /**
     * Sets ith "DadosContrato" element
     */
    public void setDadosContratoArray(int i, org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato dadosContrato)
    {
        generatedSetterHelperImpl(dadosContrato, DADOSCONTRATO$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
    }
    
    /**
     * Nils the ith "DadosContrato" element
     */
    public void setNilDadosContratoArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato)get_store().find_element_user(DADOSCONTRATO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "DadosContrato" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato insertNewDadosContrato(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato)get_store().insert_element_user(DADOSCONTRATO$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "DadosContrato" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato addNewDadosContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato)get_store().add_element_user(DADOSCONTRATO$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "DadosContrato" element
     */
    public void removeDadosContrato(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DADOSCONTRATO$0, i);
        }
    }
}
