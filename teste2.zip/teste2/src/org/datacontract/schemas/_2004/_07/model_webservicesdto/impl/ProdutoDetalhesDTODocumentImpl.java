/*
 * An XML document type.
 * Localname: ProdutoDetalhesDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one ProdutoDetalhesDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class ProdutoDetalhesDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public ProdutoDetalhesDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PRODUTODETALHESDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ProdutoDetalhesDTO");
    
    
    /**
     * Gets the "ProdutoDetalhesDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO getProdutoDetalhesDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO)get_store().find_element_user(PRODUTODETALHESDTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ProdutoDetalhesDTO" element
     */
    public boolean isNilProdutoDetalhesDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO)get_store().find_element_user(PRODUTODETALHESDTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ProdutoDetalhesDTO" element
     */
    public void setProdutoDetalhesDTO(org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO produtoDetalhesDTO)
    {
        generatedSetterHelperImpl(produtoDetalhesDTO, PRODUTODETALHESDTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ProdutoDetalhesDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO addNewProdutoDetalhesDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO)get_store().add_element_user(PRODUTODETALHESDTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "ProdutoDetalhesDTO" element
     */
    public void setNilProdutoDetalhesDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO)get_store().find_element_user(PRODUTODETALHESDTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO)get_store().add_element_user(PRODUTODETALHESDTO$0);
            }
            target.setNil();
        }
    }
}
