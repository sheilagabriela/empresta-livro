/*
 * XML Type:  ArrayOfParcelaProdutoDetalhesDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ArrayOfParcelaProdutoDetalhesDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ArrayOfParcelaProdutoDetalhesDTOImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO
{
    private static final long serialVersionUID = 1L;
    
    public ArrayOfParcelaProdutoDetalhesDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PARCELAPRODUTODETALHESDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ParcelaProdutoDetalhesDTO");
    
    
    /**
     * Gets array of all "ParcelaProdutoDetalhesDTO" elements
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO[] getParcelaProdutoDetalhesDTOArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PARCELAPRODUTODETALHESDTO$0, targetList);
            org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO[] result = new org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "ParcelaProdutoDetalhesDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO getParcelaProdutoDetalhesDTOArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO)get_store().find_element_user(PARCELAPRODUTODETALHESDTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "ParcelaProdutoDetalhesDTO" element
     */
    public boolean isNilParcelaProdutoDetalhesDTOArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO)get_store().find_element_user(PARCELAPRODUTODETALHESDTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "ParcelaProdutoDetalhesDTO" element
     */
    public int sizeOfParcelaProdutoDetalhesDTOArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PARCELAPRODUTODETALHESDTO$0);
        }
    }
    
    /**
     * Sets array of all "ParcelaProdutoDetalhesDTO" element  WARNING: This method is not atomicaly synchronized.
     */
    public void setParcelaProdutoDetalhesDTOArray(org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO[] parcelaProdutoDetalhesDTOArray)
    {
        check_orphaned();
        arraySetterHelper(parcelaProdutoDetalhesDTOArray, PARCELAPRODUTODETALHESDTO$0);
    }
    
    /**
     * Sets ith "ParcelaProdutoDetalhesDTO" element
     */
    public void setParcelaProdutoDetalhesDTOArray(int i, org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO parcelaProdutoDetalhesDTO)
    {
        generatedSetterHelperImpl(parcelaProdutoDetalhesDTO, PARCELAPRODUTODETALHESDTO$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
    }
    
    /**
     * Nils the ith "ParcelaProdutoDetalhesDTO" element
     */
    public void setNilParcelaProdutoDetalhesDTOArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO)get_store().find_element_user(PARCELAPRODUTODETALHESDTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "ParcelaProdutoDetalhesDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO insertNewParcelaProdutoDetalhesDTO(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO)get_store().insert_element_user(PARCELAPRODUTODETALHESDTO$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "ParcelaProdutoDetalhesDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO addNewParcelaProdutoDetalhesDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ParcelaProdutoDetalhesDTO)get_store().add_element_user(PARCELAPRODUTODETALHESDTO$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "ParcelaProdutoDetalhesDTO" element
     */
    public void removeParcelaProdutoDetalhesDTO(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PARCELAPRODUTODETALHESDTO$0, i);
        }
    }
}
