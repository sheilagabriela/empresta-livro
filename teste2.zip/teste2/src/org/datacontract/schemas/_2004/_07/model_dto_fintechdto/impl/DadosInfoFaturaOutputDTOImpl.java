/*
 * XML Type:  DadosInfoFaturaOutputDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaOutputDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * An XML DadosInfoFaturaOutputDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public class DadosInfoFaturaOutputDTOImpl extends org.datacontract.schemas._2004._07.model_dto_fintechdto.impl.FintechBaseDTOImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaOutputDTO
{
    private static final long serialVersionUID = 1L;
    
    public DadosInfoFaturaOutputDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName LISTAFATURAS$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "ListaFaturas");
    
    
    /**
     * Gets the "ListaFaturas" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura getListaFaturas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura)get_store().find_element_user(LISTAFATURAS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ListaFaturas" element
     */
    public boolean isNilListaFaturas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura)get_store().find_element_user(LISTAFATURAS$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ListaFaturas" element
     */
    public boolean isSetListaFaturas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LISTAFATURAS$0) != 0;
        }
    }
    
    /**
     * Sets the "ListaFaturas" element
     */
    public void setListaFaturas(org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura listaFaturas)
    {
        generatedSetterHelperImpl(listaFaturas, LISTAFATURAS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ListaFaturas" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura addNewListaFaturas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura)get_store().add_element_user(LISTAFATURAS$0);
            return target;
        }
    }
    
    /**
     * Nils the "ListaFaturas" element
     */
    public void setNilListaFaturas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura)get_store().find_element_user(LISTAFATURAS$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura)get_store().add_element_user(LISTAFATURAS$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ListaFaturas" element
     */
    public void unsetListaFaturas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LISTAFATURAS$0, 0);
        }
    }
}
