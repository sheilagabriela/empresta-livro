/*
 * XML Type:  InclusaoCobrancaDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML InclusaoCobrancaDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class InclusaoCobrancaDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.CobrancaDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO
{
    private static final long serialVersionUID = 1L;
    
    public InclusaoCobrancaDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName APROVADOCONJUGE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "AprovadoConjuge");
    private static final javax.xml.namespace.QName NOMEANEXO$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "NomeAnexo");
    private static final javax.xml.namespace.QName PARCELAINDETERMINADA$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ParcelaIndeterminada");
    private static final javax.xml.namespace.QName QTDPARCELAS$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "QtdParcelas");
    private static final javax.xml.namespace.QName VALOR$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Valor");
    
    
    /**
     * Gets the "AprovadoConjuge" element
     */
    public java.lang.String getAprovadoConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(APROVADOCONJUGE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "AprovadoConjuge" element
     */
    public org.apache.xmlbeans.XmlString xgetAprovadoConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APROVADOCONJUGE$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "AprovadoConjuge" element
     */
    public boolean isNilAprovadoConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APROVADOCONJUGE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "AprovadoConjuge" element
     */
    public boolean isSetAprovadoConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(APROVADOCONJUGE$0) != 0;
        }
    }
    
    /**
     * Sets the "AprovadoConjuge" element
     */
    public void setAprovadoConjuge(java.lang.String aprovadoConjuge)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(APROVADOCONJUGE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(APROVADOCONJUGE$0);
            }
            target.setStringValue(aprovadoConjuge);
        }
    }
    
    /**
     * Sets (as xml) the "AprovadoConjuge" element
     */
    public void xsetAprovadoConjuge(org.apache.xmlbeans.XmlString aprovadoConjuge)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APROVADOCONJUGE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(APROVADOCONJUGE$0);
            }
            target.set(aprovadoConjuge);
        }
    }
    
    /**
     * Nils the "AprovadoConjuge" element
     */
    public void setNilAprovadoConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APROVADOCONJUGE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(APROVADOCONJUGE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "AprovadoConjuge" element
     */
    public void unsetAprovadoConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(APROVADOCONJUGE$0, 0);
        }
    }
    
    /**
     * Gets the "NomeAnexo" element
     */
    public java.lang.String getNomeAnexo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMEANEXO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NomeAnexo" element
     */
    public org.apache.xmlbeans.XmlString xgetNomeAnexo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEANEXO$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "NomeAnexo" element
     */
    public boolean isNilNomeAnexo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEANEXO$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NomeAnexo" element
     */
    public boolean isSetNomeAnexo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOMEANEXO$2) != 0;
        }
    }
    
    /**
     * Sets the "NomeAnexo" element
     */
    public void setNomeAnexo(java.lang.String nomeAnexo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMEANEXO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOMEANEXO$2);
            }
            target.setStringValue(nomeAnexo);
        }
    }
    
    /**
     * Sets (as xml) the "NomeAnexo" element
     */
    public void xsetNomeAnexo(org.apache.xmlbeans.XmlString nomeAnexo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEANEXO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMEANEXO$2);
            }
            target.set(nomeAnexo);
        }
    }
    
    /**
     * Nils the "NomeAnexo" element
     */
    public void setNilNomeAnexo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMEANEXO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMEANEXO$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NomeAnexo" element
     */
    public void unsetNomeAnexo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOMEANEXO$2, 0);
        }
    }
    
    /**
     * Gets the "ParcelaIndeterminada" element
     */
    public int getParcelaIndeterminada()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PARCELAINDETERMINADA$4, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "ParcelaIndeterminada" element
     */
    public org.apache.xmlbeans.XmlInt xgetParcelaIndeterminada()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(PARCELAINDETERMINADA$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "ParcelaIndeterminada" element
     */
    public boolean isSetParcelaIndeterminada()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PARCELAINDETERMINADA$4) != 0;
        }
    }
    
    /**
     * Sets the "ParcelaIndeterminada" element
     */
    public void setParcelaIndeterminada(int parcelaIndeterminada)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PARCELAINDETERMINADA$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PARCELAINDETERMINADA$4);
            }
            target.setIntValue(parcelaIndeterminada);
        }
    }
    
    /**
     * Sets (as xml) the "ParcelaIndeterminada" element
     */
    public void xsetParcelaIndeterminada(org.apache.xmlbeans.XmlInt parcelaIndeterminada)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(PARCELAINDETERMINADA$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(PARCELAINDETERMINADA$4);
            }
            target.set(parcelaIndeterminada);
        }
    }
    
    /**
     * Unsets the "ParcelaIndeterminada" element
     */
    public void unsetParcelaIndeterminada()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PARCELAINDETERMINADA$4, 0);
        }
    }
    
    /**
     * Gets the "QtdParcelas" element
     */
    public int getQtdParcelas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(QTDPARCELAS$6, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "QtdParcelas" element
     */
    public org.apache.xmlbeans.XmlInt xgetQtdParcelas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(QTDPARCELAS$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "QtdParcelas" element
     */
    public boolean isSetQtdParcelas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QTDPARCELAS$6) != 0;
        }
    }
    
    /**
     * Sets the "QtdParcelas" element
     */
    public void setQtdParcelas(int qtdParcelas)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(QTDPARCELAS$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(QTDPARCELAS$6);
            }
            target.setIntValue(qtdParcelas);
        }
    }
    
    /**
     * Sets (as xml) the "QtdParcelas" element
     */
    public void xsetQtdParcelas(org.apache.xmlbeans.XmlInt qtdParcelas)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(QTDPARCELAS$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(QTDPARCELAS$6);
            }
            target.set(qtdParcelas);
        }
    }
    
    /**
     * Unsets the "QtdParcelas" element
     */
    public void unsetQtdParcelas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QTDPARCELAS$6, 0);
        }
    }
    
    /**
     * Gets the "Valor" element
     */
    public java.math.BigDecimal getValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALOR$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "Valor" element
     */
    public org.apache.xmlbeans.XmlDecimal xgetValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDecimal target = null;
            target = (org.apache.xmlbeans.XmlDecimal)get_store().find_element_user(VALOR$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "Valor" element
     */
    public boolean isSetValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALOR$8) != 0;
        }
    }
    
    /**
     * Sets the "Valor" element
     */
    public void setValor(java.math.BigDecimal valor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALOR$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALOR$8);
            }
            target.setBigDecimalValue(valor);
        }
    }
    
    /**
     * Sets (as xml) the "Valor" element
     */
    public void xsetValor(org.apache.xmlbeans.XmlDecimal valor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDecimal target = null;
            target = (org.apache.xmlbeans.XmlDecimal)get_store().find_element_user(VALOR$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDecimal)get_store().add_element_user(VALOR$8);
            }
            target.set(valor);
        }
    }
    
    /**
     * Unsets the "Valor" element
     */
    public void unsetValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALOR$8, 0);
        }
    }
}
