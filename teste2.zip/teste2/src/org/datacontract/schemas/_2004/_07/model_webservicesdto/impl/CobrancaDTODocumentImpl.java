/*
 * An XML document type.
 * Localname: CobrancaDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one CobrancaDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class CobrancaDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public CobrancaDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName COBRANCADTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "CobrancaDTO");
    
    
    /**
     * Gets the "CobrancaDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTO getCobrancaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTO)get_store().find_element_user(COBRANCADTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "CobrancaDTO" element
     */
    public boolean isNilCobrancaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTO)get_store().find_element_user(COBRANCADTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "CobrancaDTO" element
     */
    public void setCobrancaDTO(org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTO cobrancaDTO)
    {
        generatedSetterHelperImpl(cobrancaDTO, COBRANCADTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CobrancaDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTO addNewCobrancaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTO)get_store().add_element_user(COBRANCADTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "CobrancaDTO" element
     */
    public void setNilCobrancaDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTO)get_store().find_element_user(COBRANCADTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTO)get_store().add_element_user(COBRANCADTO$0);
            }
            target.setNil();
        }
    }
}
