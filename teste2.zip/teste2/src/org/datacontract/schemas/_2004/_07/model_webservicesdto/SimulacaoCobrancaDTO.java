/*
 * XML Type:  SimulacaoCobrancaDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto;


/**
 * An XML SimulacaoCobrancaDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public interface SimulacaoCobrancaDTO extends org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(SimulacaoCobrancaDTO.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3965ADB232D1D9A0AB9A333DE5AD2A31").resolveHandle("simulacaocobrancadto8799type");
    
    /**
     * Gets the "InfoSimulacao" element
     */
    java.lang.String getInfoSimulacao();
    
    /**
     * Gets (as xml) the "InfoSimulacao" element
     */
    org.apache.xmlbeans.XmlString xgetInfoSimulacao();
    
    /**
     * Tests for nil "InfoSimulacao" element
     */
    boolean isNilInfoSimulacao();
    
    /**
     * True if has "InfoSimulacao" element
     */
    boolean isSetInfoSimulacao();
    
    /**
     * Sets the "InfoSimulacao" element
     */
    void setInfoSimulacao(java.lang.String infoSimulacao);
    
    /**
     * Sets (as xml) the "InfoSimulacao" element
     */
    void xsetInfoSimulacao(org.apache.xmlbeans.XmlString infoSimulacao);
    
    /**
     * Nils the "InfoSimulacao" element
     */
    void setNilInfoSimulacao();
    
    /**
     * Unsets the "InfoSimulacao" element
     */
    void unsetInfoSimulacao();
    
    /**
     * Gets the "Instalacao" element
     */
    java.lang.String getInstalacao();
    
    /**
     * Gets (as xml) the "Instalacao" element
     */
    org.apache.xmlbeans.XmlString xgetInstalacao();
    
    /**
     * Tests for nil "Instalacao" element
     */
    boolean isNilInstalacao();
    
    /**
     * True if has "Instalacao" element
     */
    boolean isSetInstalacao();
    
    /**
     * Sets the "Instalacao" element
     */
    void setInstalacao(java.lang.String instalacao);
    
    /**
     * Sets (as xml) the "Instalacao" element
     */
    void xsetInstalacao(org.apache.xmlbeans.XmlString instalacao);
    
    /**
     * Nils the "Instalacao" element
     */
    void setNilInstalacao();
    
    /**
     * Unsets the "Instalacao" element
     */
    void unsetInstalacao();
    
    /**
     * Gets the "PN" element
     */
    java.lang.String getPN();
    
    /**
     * Gets (as xml) the "PN" element
     */
    org.apache.xmlbeans.XmlString xgetPN();
    
    /**
     * Tests for nil "PN" element
     */
    boolean isNilPN();
    
    /**
     * True if has "PN" element
     */
    boolean isSetPN();
    
    /**
     * Sets the "PN" element
     */
    void setPN(java.lang.String pn);
    
    /**
     * Sets (as xml) the "PN" element
     */
    void xsetPN(org.apache.xmlbeans.XmlString pn);
    
    /**
     * Nils the "PN" element
     */
    void setNilPN();
    
    /**
     * Unsets the "PN" element
     */
    void unsetPN();
    
    /**
     * Gets the "Produto" element
     */
    java.lang.String getProduto();
    
    /**
     * Gets (as xml) the "Produto" element
     */
    org.apache.xmlbeans.XmlString xgetProduto();
    
    /**
     * Tests for nil "Produto" element
     */
    boolean isNilProduto();
    
    /**
     * True if has "Produto" element
     */
    boolean isSetProduto();
    
    /**
     * Sets the "Produto" element
     */
    void setProduto(java.lang.String produto);
    
    /**
     * Sets (as xml) the "Produto" element
     */
    void xsetProduto(org.apache.xmlbeans.XmlString produto);
    
    /**
     * Nils the "Produto" element
     */
    void setNilProduto();
    
    /**
     * Unsets the "Produto" element
     */
    void unsetProduto();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO newInstance() {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.SimulacaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
