/*
 * XML Type:  DadosInfoFaturaInputDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * An XML DadosInfoFaturaInputDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public class DadosInfoFaturaInputDTOImpl extends org.datacontract.schemas._2004._07.model_dto_fintechdto.impl.FintechBaseInputDTOImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO
{
    private static final long serialVersionUID = 1L;
    
    public DadosInfoFaturaInputDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CODIGOPARCEIRO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "CodigoParceiro");
    private static final javax.xml.namespace.QName CONTACONTRATO$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "ContaContrato");
    private static final javax.xml.namespace.QName NUMEROINSTALACAO$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "NumeroInstalacao");
    
    
    /**
     * Gets the "CodigoParceiro" element
     */
    public java.lang.String getCodigoParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOPARCEIRO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoParceiro" element
     */
    public org.apache.xmlbeans.XmlString xgetCodigoParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOPARCEIRO$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodigoParceiro" element
     */
    public boolean isNilCodigoParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOPARCEIRO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodigoParceiro" element
     */
    public boolean isSetCodigoParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGOPARCEIRO$0) != 0;
        }
    }
    
    /**
     * Sets the "CodigoParceiro" element
     */
    public void setCodigoParceiro(java.lang.String codigoParceiro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOPARCEIRO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOPARCEIRO$0);
            }
            target.setStringValue(codigoParceiro);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoParceiro" element
     */
    public void xsetCodigoParceiro(org.apache.xmlbeans.XmlString codigoParceiro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOPARCEIRO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODIGOPARCEIRO$0);
            }
            target.set(codigoParceiro);
        }
    }
    
    /**
     * Nils the "CodigoParceiro" element
     */
    public void setNilCodigoParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOPARCEIRO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODIGOPARCEIRO$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodigoParceiro" element
     */
    public void unsetCodigoParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGOPARCEIRO$0, 0);
        }
    }
    
    /**
     * Gets the "ContaContrato" element
     */
    public java.lang.String getContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTACONTRATO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ContaContrato" element
     */
    public org.apache.xmlbeans.XmlString xgetContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTACONTRATO$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ContaContrato" element
     */
    public boolean isNilContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTACONTRATO$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ContaContrato" element
     */
    public boolean isSetContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONTACONTRATO$2) != 0;
        }
    }
    
    /**
     * Sets the "ContaContrato" element
     */
    public void setContaContrato(java.lang.String contaContrato)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTACONTRATO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONTACONTRATO$2);
            }
            target.setStringValue(contaContrato);
        }
    }
    
    /**
     * Sets (as xml) the "ContaContrato" element
     */
    public void xsetContaContrato(org.apache.xmlbeans.XmlString contaContrato)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTACONTRATO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONTACONTRATO$2);
            }
            target.set(contaContrato);
        }
    }
    
    /**
     * Nils the "ContaContrato" element
     */
    public void setNilContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTACONTRATO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONTACONTRATO$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ContaContrato" element
     */
    public void unsetContaContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONTACONTRATO$2, 0);
        }
    }
    
    /**
     * Gets the "NumeroInstalacao" element
     */
    public java.lang.String getNumeroInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROINSTALACAO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NumeroInstalacao" element
     */
    public org.apache.xmlbeans.XmlString xgetNumeroInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMEROINSTALACAO$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "NumeroInstalacao" element
     */
    public boolean isNilNumeroInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMEROINSTALACAO$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NumeroInstalacao" element
     */
    public boolean isSetNumeroInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMEROINSTALACAO$4) != 0;
        }
    }
    
    /**
     * Sets the "NumeroInstalacao" element
     */
    public void setNumeroInstalacao(java.lang.String numeroInstalacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROINSTALACAO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMEROINSTALACAO$4);
            }
            target.setStringValue(numeroInstalacao);
        }
    }
    
    /**
     * Sets (as xml) the "NumeroInstalacao" element
     */
    public void xsetNumeroInstalacao(org.apache.xmlbeans.XmlString numeroInstalacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMEROINSTALACAO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMEROINSTALACAO$4);
            }
            target.set(numeroInstalacao);
        }
    }
    
    /**
     * Nils the "NumeroInstalacao" element
     */
    public void setNilNumeroInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMEROINSTALACAO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMEROINSTALACAO$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NumeroInstalacao" element
     */
    public void unsetNumeroInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMEROINSTALACAO$4, 0);
        }
    }
}
