/*
 * An XML document type.
 * Localname: ServiceRequestPaiDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one ServiceRequestPaiDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class ServiceRequestPaiDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public ServiceRequestPaiDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICEREQUESTPAIDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ServiceRequestPaiDTO");
    
    
    /**
     * Gets the "ServiceRequestPaiDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO getServiceRequestPaiDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO)get_store().find_element_user(SERVICEREQUESTPAIDTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ServiceRequestPaiDTO" element
     */
    public boolean isNilServiceRequestPaiDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO)get_store().find_element_user(SERVICEREQUESTPAIDTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ServiceRequestPaiDTO" element
     */
    public void setServiceRequestPaiDTO(org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO serviceRequestPaiDTO)
    {
        generatedSetterHelperImpl(serviceRequestPaiDTO, SERVICEREQUESTPAIDTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ServiceRequestPaiDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO addNewServiceRequestPaiDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO)get_store().add_element_user(SERVICEREQUESTPAIDTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "ServiceRequestPaiDTO" element
     */
    public void setNilServiceRequestPaiDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO)get_store().find_element_user(SERVICEREQUESTPAIDTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO)get_store().add_element_user(SERVICEREQUESTPAIDTO$0);
            }
            target.setNil();
        }
    }
}
