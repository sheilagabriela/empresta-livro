/*
 * An XML document type.
 * Localname: ConsultarProdutoDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * A document containing one ConsultarProdutoDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO) element.
 *
 * This is a complex type.
 */
public class ConsultarProdutoDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarProdutoDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTARPRODUTODTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ConsultarProdutoDTO");
    
    
    /**
     * Gets the "ConsultarProdutoDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTO getConsultarProdutoDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTO)get_store().find_element_user(CONSULTARPRODUTODTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ConsultarProdutoDTO" element
     */
    public boolean isNilConsultarProdutoDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTO)get_store().find_element_user(CONSULTARPRODUTODTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ConsultarProdutoDTO" element
     */
    public void setConsultarProdutoDTO(org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTO consultarProdutoDTO)
    {
        generatedSetterHelperImpl(consultarProdutoDTO, CONSULTARPRODUTODTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultarProdutoDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTO addNewConsultarProdutoDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTO)get_store().add_element_user(CONSULTARPRODUTODTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "ConsultarProdutoDTO" element
     */
    public void setNilConsultarProdutoDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTO)get_store().find_element_user(CONSULTARPRODUTODTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTO)get_store().add_element_user(CONSULTARPRODUTODTO$0);
            }
            target.setNil();
        }
    }
}
