/*
 * XML Type:  InclusaoCobrancaFintechDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML InclusaoCobrancaFintechDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class InclusaoCobrancaFintechDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.InclusaoCobrancaDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaFintechDTO
{
    private static final long serialVersionUID = 1L;
    
    public InclusaoCobrancaFintechDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INFOCOBRANCA$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "InfoCobranca");
    
    
    /**
     * Gets the "InfoCobranca" element
     */
    public java.lang.String getInfoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INFOCOBRANCA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "InfoCobranca" element
     */
    public org.apache.xmlbeans.XmlString xgetInfoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INFOCOBRANCA$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "InfoCobranca" element
     */
    public boolean isNilInfoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INFOCOBRANCA$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "InfoCobranca" element
     */
    public boolean isSetInfoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INFOCOBRANCA$0) != 0;
        }
    }
    
    /**
     * Sets the "InfoCobranca" element
     */
    public void setInfoCobranca(java.lang.String infoCobranca)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INFOCOBRANCA$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INFOCOBRANCA$0);
            }
            target.setStringValue(infoCobranca);
        }
    }
    
    /**
     * Sets (as xml) the "InfoCobranca" element
     */
    public void xsetInfoCobranca(org.apache.xmlbeans.XmlString infoCobranca)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INFOCOBRANCA$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INFOCOBRANCA$0);
            }
            target.set(infoCobranca);
        }
    }
    
    /**
     * Nils the "InfoCobranca" element
     */
    public void setNilInfoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INFOCOBRANCA$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INFOCOBRANCA$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "InfoCobranca" element
     */
    public void unsetInfoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INFOCOBRANCA$0, 0);
        }
    }
}
