/*
 * An XML document type.
 * Localname: DadosInfoFaturaInputDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * A document containing one DadosInfoFaturaInputDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO) element.
 *
 * This is a complex type.
 */
public class DadosInfoFaturaInputDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public DadosInfoFaturaInputDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DADOSINFOFATURAINPUTDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DadosInfoFaturaInputDTO");
    
    
    /**
     * Gets the "DadosInfoFaturaInputDTO" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO getDadosInfoFaturaInputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO)get_store().find_element_user(DADOSINFOFATURAINPUTDTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "DadosInfoFaturaInputDTO" element
     */
    public boolean isNilDadosInfoFaturaInputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO)get_store().find_element_user(DADOSINFOFATURAINPUTDTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "DadosInfoFaturaInputDTO" element
     */
    public void setDadosInfoFaturaInputDTO(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO dadosInfoFaturaInputDTO)
    {
        generatedSetterHelperImpl(dadosInfoFaturaInputDTO, DADOSINFOFATURAINPUTDTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "DadosInfoFaturaInputDTO" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO addNewDadosInfoFaturaInputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO)get_store().add_element_user(DADOSINFOFATURAINPUTDTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "DadosInfoFaturaInputDTO" element
     */
    public void setNilDadosInfoFaturaInputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO)get_store().find_element_user(DADOSINFOFATURAINPUTDTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInfoFaturaInputDTO)get_store().add_element_user(DADOSINFOFATURAINPUTDTO$0);
            }
            target.setNil();
        }
    }
}
