/*
 * XML Type:  ConsultaDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto;


/**
 * An XML ConsultaDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public interface ConsultaDTO extends org.datacontract.schemas._2004._07.model_webservicesdto.ServiceRequestPaiDTO
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConsultaDTO.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3965ADB232D1D9A0AB9A333DE5AD2A31").resolveHandle("consultadto80dbtype");
    
    /**
     * Gets the "CNPJ" element
     */
    java.lang.String getCNPJ();
    
    /**
     * Gets (as xml) the "CNPJ" element
     */
    org.apache.xmlbeans.XmlString xgetCNPJ();
    
    /**
     * Tests for nil "CNPJ" element
     */
    boolean isNilCNPJ();
    
    /**
     * True if has "CNPJ" element
     */
    boolean isSetCNPJ();
    
    /**
     * Sets the "CNPJ" element
     */
    void setCNPJ(java.lang.String cnpj);
    
    /**
     * Sets (as xml) the "CNPJ" element
     */
    void xsetCNPJ(org.apache.xmlbeans.XmlString cnpj);
    
    /**
     * Nils the "CNPJ" element
     */
    void setNilCNPJ();
    
    /**
     * Unsets the "CNPJ" element
     */
    void unsetCNPJ();
    
    /**
     * Gets the "CPF" element
     */
    java.lang.String getCPF();
    
    /**
     * Gets (as xml) the "CPF" element
     */
    org.apache.xmlbeans.XmlString xgetCPF();
    
    /**
     * Tests for nil "CPF" element
     */
    boolean isNilCPF();
    
    /**
     * True if has "CPF" element
     */
    boolean isSetCPF();
    
    /**
     * Sets the "CPF" element
     */
    void setCPF(java.lang.String cpf);
    
    /**
     * Sets (as xml) the "CPF" element
     */
    void xsetCPF(org.apache.xmlbeans.XmlString cpf);
    
    /**
     * Nils the "CPF" element
     */
    void setNilCPF();
    
    /**
     * Unsets the "CPF" element
     */
    void unsetCPF();
    
    /**
     * Gets the "Instalacao" element
     */
    java.lang.String getInstalacao();
    
    /**
     * Gets (as xml) the "Instalacao" element
     */
    org.apache.xmlbeans.XmlString xgetInstalacao();
    
    /**
     * Tests for nil "Instalacao" element
     */
    boolean isNilInstalacao();
    
    /**
     * Sets the "Instalacao" element
     */
    void setInstalacao(java.lang.String instalacao);
    
    /**
     * Sets (as xml) the "Instalacao" element
     */
    void xsetInstalacao(org.apache.xmlbeans.XmlString instalacao);
    
    /**
     * Nils the "Instalacao" element
     */
    void setNilInstalacao();
    
    /**
     * Gets the "PF_PJ" element
     */
    int getPFPJ();
    
    /**
     * Gets (as xml) the "PF_PJ" element
     */
    org.apache.xmlbeans.XmlInt xgetPFPJ();
    
    /**
     * Sets the "PF_PJ" element
     */
    void setPFPJ(int pfpj);
    
    /**
     * Sets (as xml) the "PF_PJ" element
     */
    void xsetPFPJ(org.apache.xmlbeans.XmlInt pfpj);
    
    /**
     * Gets the "PN" element
     */
    java.lang.String getPN();
    
    /**
     * Gets (as xml) the "PN" element
     */
    org.apache.xmlbeans.XmlString xgetPN();
    
    /**
     * Tests for nil "PN" element
     */
    boolean isNilPN();
    
    /**
     * Sets the "PN" element
     */
    void setPN(java.lang.String pn);
    
    /**
     * Sets (as xml) the "PN" element
     */
    void xsetPN(org.apache.xmlbeans.XmlString pn);
    
    /**
     * Nils the "PN" element
     */
    void setNilPN();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO newInstance() {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
