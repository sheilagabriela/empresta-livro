/*
 * XML Type:  ExclusaoParcelaDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ExclusaoParcelaDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ExclusaoParcelaDTOImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ExclusaoParcelaDTO
{
    private static final long serialVersionUID = 1L;
    
    public ExclusaoParcelaDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NUMEROPARCELA$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "NumeroParcela");
    
    
    /**
     * Gets the "NumeroParcela" element
     */
    public int getNumeroParcela()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROPARCELA$0, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "NumeroParcela" element
     */
    public org.apache.xmlbeans.XmlInt xgetNumeroParcela()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(NUMEROPARCELA$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "NumeroParcela" element
     */
    public boolean isSetNumeroParcela()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMEROPARCELA$0) != 0;
        }
    }
    
    /**
     * Sets the "NumeroParcela" element
     */
    public void setNumeroParcela(int numeroParcela)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROPARCELA$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMEROPARCELA$0);
            }
            target.setIntValue(numeroParcela);
        }
    }
    
    /**
     * Sets (as xml) the "NumeroParcela" element
     */
    public void xsetNumeroParcela(org.apache.xmlbeans.XmlInt numeroParcela)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(NUMEROPARCELA$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(NUMEROPARCELA$0);
            }
            target.set(numeroParcela);
        }
    }
    
    /**
     * Unsets the "NumeroParcela" element
     */
    public void unsetNumeroParcela()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMEROPARCELA$0, 0);
        }
    }
}
