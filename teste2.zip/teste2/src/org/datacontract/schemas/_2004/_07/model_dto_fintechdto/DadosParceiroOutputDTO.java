/*
 * XML Type:  DadosParceiroOutputDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto;


/**
 * An XML DadosParceiroOutputDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public interface DadosParceiroOutputDTO extends org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseDTO
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(DadosParceiroOutputDTO.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3965ADB232D1D9A0AB9A333DE5AD2A31").resolveHandle("dadosparceirooutputdtod843type");
    
    /**
     * Gets the "CNAE" element
     */
    java.lang.String getCNAE();
    
    /**
     * Gets (as xml) the "CNAE" element
     */
    org.apache.xmlbeans.XmlString xgetCNAE();
    
    /**
     * Tests for nil "CNAE" element
     */
    boolean isNilCNAE();
    
    /**
     * True if has "CNAE" element
     */
    boolean isSetCNAE();
    
    /**
     * Sets the "CNAE" element
     */
    void setCNAE(java.lang.String cnae);
    
    /**
     * Sets (as xml) the "CNAE" element
     */
    void xsetCNAE(org.apache.xmlbeans.XmlString cnae);
    
    /**
     * Nils the "CNAE" element
     */
    void setNilCNAE();
    
    /**
     * Unsets the "CNAE" element
     */
    void unsetCNAE();
    
    /**
     * Gets the "Celular" element
     */
    java.lang.String getCelular();
    
    /**
     * Gets (as xml) the "Celular" element
     */
    org.apache.xmlbeans.XmlString xgetCelular();
    
    /**
     * Tests for nil "Celular" element
     */
    boolean isNilCelular();
    
    /**
     * True if has "Celular" element
     */
    boolean isSetCelular();
    
    /**
     * Sets the "Celular" element
     */
    void setCelular(java.lang.String celular);
    
    /**
     * Sets (as xml) the "Celular" element
     */
    void xsetCelular(org.apache.xmlbeans.XmlString celular);
    
    /**
     * Nils the "Celular" element
     */
    void setNilCelular();
    
    /**
     * Unsets the "Celular" element
     */
    void unsetCelular();
    
    /**
     * Gets the "CodTipoPessoa" element
     */
    java.lang.String getCodTipoPessoa();
    
    /**
     * Gets (as xml) the "CodTipoPessoa" element
     */
    org.apache.xmlbeans.XmlString xgetCodTipoPessoa();
    
    /**
     * Tests for nil "CodTipoPessoa" element
     */
    boolean isNilCodTipoPessoa();
    
    /**
     * True if has "CodTipoPessoa" element
     */
    boolean isSetCodTipoPessoa();
    
    /**
     * Sets the "CodTipoPessoa" element
     */
    void setCodTipoPessoa(java.lang.String codTipoPessoa);
    
    /**
     * Sets (as xml) the "CodTipoPessoa" element
     */
    void xsetCodTipoPessoa(org.apache.xmlbeans.XmlString codTipoPessoa);
    
    /**
     * Nils the "CodTipoPessoa" element
     */
    void setNilCodTipoPessoa();
    
    /**
     * Unsets the "CodTipoPessoa" element
     */
    void unsetCodTipoPessoa();
    
    /**
     * Gets the "DataNascimento" element
     */
    java.util.Calendar getDataNascimento();
    
    /**
     * Gets (as xml) the "DataNascimento" element
     */
    org.apache.xmlbeans.XmlDateTime xgetDataNascimento();
    
    /**
     * Tests for nil "DataNascimento" element
     */
    boolean isNilDataNascimento();
    
    /**
     * True if has "DataNascimento" element
     */
    boolean isSetDataNascimento();
    
    /**
     * Sets the "DataNascimento" element
     */
    void setDataNascimento(java.util.Calendar dataNascimento);
    
    /**
     * Sets (as xml) the "DataNascimento" element
     */
    void xsetDataNascimento(org.apache.xmlbeans.XmlDateTime dataNascimento);
    
    /**
     * Nils the "DataNascimento" element
     */
    void setNilDataNascimento();
    
    /**
     * Unsets the "DataNascimento" element
     */
    void unsetDataNascimento();
    
    /**
     * Gets the "Email" element
     */
    java.lang.String getEmail();
    
    /**
     * Gets (as xml) the "Email" element
     */
    org.apache.xmlbeans.XmlString xgetEmail();
    
    /**
     * Tests for nil "Email" element
     */
    boolean isNilEmail();
    
    /**
     * True if has "Email" element
     */
    boolean isSetEmail();
    
    /**
     * Sets the "Email" element
     */
    void setEmail(java.lang.String email);
    
    /**
     * Sets (as xml) the "Email" element
     */
    void xsetEmail(org.apache.xmlbeans.XmlString email);
    
    /**
     * Nils the "Email" element
     */
    void setNilEmail();
    
    /**
     * Unsets the "Email" element
     */
    void unsetEmail();
    
    /**
     * Gets the "Nome" element
     */
    java.lang.String getNome();
    
    /**
     * Gets (as xml) the "Nome" element
     */
    org.apache.xmlbeans.XmlString xgetNome();
    
    /**
     * Tests for nil "Nome" element
     */
    boolean isNilNome();
    
    /**
     * True if has "Nome" element
     */
    boolean isSetNome();
    
    /**
     * Sets the "Nome" element
     */
    void setNome(java.lang.String nome);
    
    /**
     * Sets (as xml) the "Nome" element
     */
    void xsetNome(org.apache.xmlbeans.XmlString nome);
    
    /**
     * Nils the "Nome" element
     */
    void setNilNome();
    
    /**
     * Unsets the "Nome" element
     */
    void unsetNome();
    
    /**
     * Gets the "NomeFantasia" element
     */
    java.lang.String getNomeFantasia();
    
    /**
     * Gets (as xml) the "NomeFantasia" element
     */
    org.apache.xmlbeans.XmlString xgetNomeFantasia();
    
    /**
     * Tests for nil "NomeFantasia" element
     */
    boolean isNilNomeFantasia();
    
    /**
     * True if has "NomeFantasia" element
     */
    boolean isSetNomeFantasia();
    
    /**
     * Sets the "NomeFantasia" element
     */
    void setNomeFantasia(java.lang.String nomeFantasia);
    
    /**
     * Sets (as xml) the "NomeFantasia" element
     */
    void xsetNomeFantasia(org.apache.xmlbeans.XmlString nomeFantasia);
    
    /**
     * Nils the "NomeFantasia" element
     */
    void setNilNomeFantasia();
    
    /**
     * Unsets the "NomeFantasia" element
     */
    void unsetNomeFantasia();
    
    /**
     * Gets the "NumeroDocumento" element
     */
    java.lang.String getNumeroDocumento();
    
    /**
     * Gets (as xml) the "NumeroDocumento" element
     */
    org.apache.xmlbeans.XmlString xgetNumeroDocumento();
    
    /**
     * Tests for nil "NumeroDocumento" element
     */
    boolean isNilNumeroDocumento();
    
    /**
     * True if has "NumeroDocumento" element
     */
    boolean isSetNumeroDocumento();
    
    /**
     * Sets the "NumeroDocumento" element
     */
    void setNumeroDocumento(java.lang.String numeroDocumento);
    
    /**
     * Sets (as xml) the "NumeroDocumento" element
     */
    void xsetNumeroDocumento(org.apache.xmlbeans.XmlString numeroDocumento);
    
    /**
     * Nils the "NumeroDocumento" element
     */
    void setNilNumeroDocumento();
    
    /**
     * Unsets the "NumeroDocumento" element
     */
    void unsetNumeroDocumento();
    
    /**
     * Gets the "RazaoSocial1" element
     */
    java.lang.String getRazaoSocial1();
    
    /**
     * Gets (as xml) the "RazaoSocial1" element
     */
    org.apache.xmlbeans.XmlString xgetRazaoSocial1();
    
    /**
     * Tests for nil "RazaoSocial1" element
     */
    boolean isNilRazaoSocial1();
    
    /**
     * True if has "RazaoSocial1" element
     */
    boolean isSetRazaoSocial1();
    
    /**
     * Sets the "RazaoSocial1" element
     */
    void setRazaoSocial1(java.lang.String razaoSocial1);
    
    /**
     * Sets (as xml) the "RazaoSocial1" element
     */
    void xsetRazaoSocial1(org.apache.xmlbeans.XmlString razaoSocial1);
    
    /**
     * Nils the "RazaoSocial1" element
     */
    void setNilRazaoSocial1();
    
    /**
     * Unsets the "RazaoSocial1" element
     */
    void unsetRazaoSocial1();
    
    /**
     * Gets the "RazaoSocial2" element
     */
    java.lang.String getRazaoSocial2();
    
    /**
     * Gets (as xml) the "RazaoSocial2" element
     */
    org.apache.xmlbeans.XmlString xgetRazaoSocial2();
    
    /**
     * Tests for nil "RazaoSocial2" element
     */
    boolean isNilRazaoSocial2();
    
    /**
     * True if has "RazaoSocial2" element
     */
    boolean isSetRazaoSocial2();
    
    /**
     * Sets the "RazaoSocial2" element
     */
    void setRazaoSocial2(java.lang.String razaoSocial2);
    
    /**
     * Sets (as xml) the "RazaoSocial2" element
     */
    void xsetRazaoSocial2(org.apache.xmlbeans.XmlString razaoSocial2);
    
    /**
     * Nils the "RazaoSocial2" element
     */
    void setNilRazaoSocial2();
    
    /**
     * Unsets the "RazaoSocial2" element
     */
    void unsetRazaoSocial2();
    
    /**
     * Gets the "Sobrenome" element
     */
    java.lang.String getSobrenome();
    
    /**
     * Gets (as xml) the "Sobrenome" element
     */
    org.apache.xmlbeans.XmlString xgetSobrenome();
    
    /**
     * Tests for nil "Sobrenome" element
     */
    boolean isNilSobrenome();
    
    /**
     * True if has "Sobrenome" element
     */
    boolean isSetSobrenome();
    
    /**
     * Sets the "Sobrenome" element
     */
    void setSobrenome(java.lang.String sobrenome);
    
    /**
     * Sets (as xml) the "Sobrenome" element
     */
    void xsetSobrenome(org.apache.xmlbeans.XmlString sobrenome);
    
    /**
     * Nils the "Sobrenome" element
     */
    void setNilSobrenome();
    
    /**
     * Unsets the "Sobrenome" element
     */
    void unsetSobrenome();
    
    /**
     * Gets the "Telefone" element
     */
    java.lang.String getTelefone();
    
    /**
     * Gets (as xml) the "Telefone" element
     */
    org.apache.xmlbeans.XmlString xgetTelefone();
    
    /**
     * Tests for nil "Telefone" element
     */
    boolean isNilTelefone();
    
    /**
     * True if has "Telefone" element
     */
    boolean isSetTelefone();
    
    /**
     * Sets the "Telefone" element
     */
    void setTelefone(java.lang.String telefone);
    
    /**
     * Sets (as xml) the "Telefone" element
     */
    void xsetTelefone(org.apache.xmlbeans.XmlString telefone);
    
    /**
     * Nils the "Telefone" element
     */
    void setNilTelefone();
    
    /**
     * Unsets the "Telefone" element
     */
    void unsetTelefone();
    
    /**
     * Gets the "TipoDocumento" element
     */
    java.lang.String getTipoDocumento();
    
    /**
     * Gets (as xml) the "TipoDocumento" element
     */
    org.apache.xmlbeans.XmlString xgetTipoDocumento();
    
    /**
     * Tests for nil "TipoDocumento" element
     */
    boolean isNilTipoDocumento();
    
    /**
     * True if has "TipoDocumento" element
     */
    boolean isSetTipoDocumento();
    
    /**
     * Sets the "TipoDocumento" element
     */
    void setTipoDocumento(java.lang.String tipoDocumento);
    
    /**
     * Sets (as xml) the "TipoDocumento" element
     */
    void xsetTipoDocumento(org.apache.xmlbeans.XmlString tipoDocumento);
    
    /**
     * Nils the "TipoDocumento" element
     */
    void setNilTipoDocumento();
    
    /**
     * Unsets the "TipoDocumento" element
     */
    void unsetTipoDocumento();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO newInstance() {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
