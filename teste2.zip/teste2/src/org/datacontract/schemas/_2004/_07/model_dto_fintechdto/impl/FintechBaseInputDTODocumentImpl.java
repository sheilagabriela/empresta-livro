/*
 * An XML document type.
 * Localname: FintechBaseInputDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseInputDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * A document containing one FintechBaseInputDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO) element.
 *
 * This is a complex type.
 */
public class FintechBaseInputDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseInputDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public FintechBaseInputDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FINTECHBASEINPUTDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "FintechBaseInputDTO");
    
    
    /**
     * Gets the "FintechBaseInputDTO" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseInputDTO getFintechBaseInputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseInputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseInputDTO)get_store().find_element_user(FINTECHBASEINPUTDTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "FintechBaseInputDTO" element
     */
    public boolean isNilFintechBaseInputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseInputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseInputDTO)get_store().find_element_user(FINTECHBASEINPUTDTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "FintechBaseInputDTO" element
     */
    public void setFintechBaseInputDTO(org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseInputDTO fintechBaseInputDTO)
    {
        generatedSetterHelperImpl(fintechBaseInputDTO, FINTECHBASEINPUTDTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "FintechBaseInputDTO" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseInputDTO addNewFintechBaseInputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseInputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseInputDTO)get_store().add_element_user(FINTECHBASEINPUTDTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "FintechBaseInputDTO" element
     */
    public void setNilFintechBaseInputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseInputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseInputDTO)get_store().find_element_user(FINTECHBASEINPUTDTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.FintechBaseInputDTO)get_store().add_element_user(FINTECHBASEINPUTDTO$0);
            }
            target.setNil();
        }
    }
}
