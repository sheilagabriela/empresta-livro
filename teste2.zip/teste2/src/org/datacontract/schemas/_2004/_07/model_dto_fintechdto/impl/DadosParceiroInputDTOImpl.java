/*
 * XML Type:  DadosParceiroInputDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroInputDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * An XML DadosParceiroInputDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public class DadosParceiroInputDTOImpl extends org.datacontract.schemas._2004._07.model_dto_fintechdto.impl.FintechBaseInputDTOImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroInputDTO
{
    private static final long serialVersionUID = 1L;
    
    public DadosParceiroInputDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CODIGOPARCEIRO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "CodigoParceiro");
    
    
    /**
     * Gets the "CodigoParceiro" element
     */
    public java.lang.String getCodigoParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOPARCEIRO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoParceiro" element
     */
    public org.apache.xmlbeans.XmlString xgetCodigoParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOPARCEIRO$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodigoParceiro" element
     */
    public boolean isNilCodigoParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOPARCEIRO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodigoParceiro" element
     */
    public boolean isSetCodigoParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGOPARCEIRO$0) != 0;
        }
    }
    
    /**
     * Sets the "CodigoParceiro" element
     */
    public void setCodigoParceiro(java.lang.String codigoParceiro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOPARCEIRO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOPARCEIRO$0);
            }
            target.setStringValue(codigoParceiro);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoParceiro" element
     */
    public void xsetCodigoParceiro(org.apache.xmlbeans.XmlString codigoParceiro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOPARCEIRO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODIGOPARCEIRO$0);
            }
            target.set(codigoParceiro);
        }
    }
    
    /**
     * Nils the "CodigoParceiro" element
     */
    public void setNilCodigoParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODIGOPARCEIRO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODIGOPARCEIRO$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodigoParceiro" element
     */
    public void unsetCodigoParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGOPARCEIRO$0, 0);
        }
    }
}
