/*
 * XML Type:  ArrayOfProdutoDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ArrayOfProdutoDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ArrayOfProdutoDTOImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDTO
{
    private static final long serialVersionUID = 1L;
    
    public ArrayOfProdutoDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PRODUTODTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ProdutoDTO");
    
    
    /**
     * Gets array of all "ProdutoDTO" elements
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO[] getProdutoDTOArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PRODUTODTO$0, targetList);
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO[] result = new org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "ProdutoDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO getProdutoDTOArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO)get_store().find_element_user(PRODUTODTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "ProdutoDTO" element
     */
    public boolean isNilProdutoDTOArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO)get_store().find_element_user(PRODUTODTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "ProdutoDTO" element
     */
    public int sizeOfProdutoDTOArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRODUTODTO$0);
        }
    }
    
    /**
     * Sets array of all "ProdutoDTO" element  WARNING: This method is not atomicaly synchronized.
     */
    public void setProdutoDTOArray(org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO[] produtoDTOArray)
    {
        check_orphaned();
        arraySetterHelper(produtoDTOArray, PRODUTODTO$0);
    }
    
    /**
     * Sets ith "ProdutoDTO" element
     */
    public void setProdutoDTOArray(int i, org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO produtoDTO)
    {
        generatedSetterHelperImpl(produtoDTO, PRODUTODTO$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
    }
    
    /**
     * Nils the ith "ProdutoDTO" element
     */
    public void setNilProdutoDTOArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO)get_store().find_element_user(PRODUTODTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "ProdutoDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO insertNewProdutoDTO(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO)get_store().insert_element_user(PRODUTODTO$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "ProdutoDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO addNewProdutoDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDTO)get_store().add_element_user(PRODUTODTO$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "ProdutoDTO" element
     */
    public void removeProdutoDTO(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRODUTODTO$0, i);
        }
    }
}
