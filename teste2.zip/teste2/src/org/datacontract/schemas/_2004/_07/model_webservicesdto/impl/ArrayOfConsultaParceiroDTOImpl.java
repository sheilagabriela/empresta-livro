/*
 * XML Type:  ArrayOfConsultaParceiroDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ArrayOfConsultaParceiroDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ArrayOfConsultaParceiroDTOImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO
{
    private static final long serialVersionUID = 1L;
    
    public ArrayOfConsultaParceiroDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTAPARCEIRODTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ConsultaParceiroDTO");
    
    
    /**
     * Gets array of all "ConsultaParceiroDTO" elements
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO[] getConsultaParceiroDTOArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(CONSULTAPARCEIRODTO$0, targetList);
            org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO[] result = new org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "ConsultaParceiroDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO getConsultaParceiroDTOArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO)get_store().find_element_user(CONSULTAPARCEIRODTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "ConsultaParceiroDTO" element
     */
    public boolean isNilConsultaParceiroDTOArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO)get_store().find_element_user(CONSULTAPARCEIRODTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "ConsultaParceiroDTO" element
     */
    public int sizeOfConsultaParceiroDTOArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONSULTAPARCEIRODTO$0);
        }
    }
    
    /**
     * Sets array of all "ConsultaParceiroDTO" element  WARNING: This method is not atomicaly synchronized.
     */
    public void setConsultaParceiroDTOArray(org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO[] consultaParceiroDTOArray)
    {
        check_orphaned();
        arraySetterHelper(consultaParceiroDTOArray, CONSULTAPARCEIRODTO$0);
    }
    
    /**
     * Sets ith "ConsultaParceiroDTO" element
     */
    public void setConsultaParceiroDTOArray(int i, org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO consultaParceiroDTO)
    {
        generatedSetterHelperImpl(consultaParceiroDTO, CONSULTAPARCEIRODTO$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
    }
    
    /**
     * Nils the ith "ConsultaParceiroDTO" element
     */
    public void setNilConsultaParceiroDTOArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO)get_store().find_element_user(CONSULTAPARCEIRODTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "ConsultaParceiroDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO insertNewConsultaParceiroDTO(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO)get_store().insert_element_user(CONSULTAPARCEIRODTO$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "ConsultaParceiroDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO addNewConsultaParceiroDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ConsultaParceiroDTO)get_store().add_element_user(CONSULTAPARCEIRODTO$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "ConsultaParceiroDTO" element
     */
    public void removeConsultaParceiroDTO(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONSULTAPARCEIRODTO$0, i);
        }
    }
}
