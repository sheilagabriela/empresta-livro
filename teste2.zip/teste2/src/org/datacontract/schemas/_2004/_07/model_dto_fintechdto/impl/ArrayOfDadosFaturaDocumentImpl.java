/*
 * An XML document type.
 * Localname: ArrayOfDadosFatura
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFaturaDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * A document containing one ArrayOfDadosFatura(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO) element.
 *
 * This is a complex type.
 */
public class ArrayOfDadosFaturaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFaturaDocument
{
    private static final long serialVersionUID = 1L;
    
    public ArrayOfDadosFaturaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFDADOSFATURA$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "ArrayOfDadosFatura");
    
    
    /**
     * Gets the "ArrayOfDadosFatura" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura getArrayOfDadosFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura)get_store().find_element_user(ARRAYOFDADOSFATURA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfDadosFatura" element
     */
    public boolean isNilArrayOfDadosFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura)get_store().find_element_user(ARRAYOFDADOSFATURA$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfDadosFatura" element
     */
    public void setArrayOfDadosFatura(org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura arrayOfDadosFatura)
    {
        generatedSetterHelperImpl(arrayOfDadosFatura, ARRAYOFDADOSFATURA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ArrayOfDadosFatura" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura addNewArrayOfDadosFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura)get_store().add_element_user(ARRAYOFDADOSFATURA$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfDadosFatura" element
     */
    public void setNilArrayOfDadosFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura)get_store().find_element_user(ARRAYOFDADOSFATURA$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura)get_store().add_element_user(ARRAYOFDADOSFATURA$0);
            }
            target.setNil();
        }
    }
}
