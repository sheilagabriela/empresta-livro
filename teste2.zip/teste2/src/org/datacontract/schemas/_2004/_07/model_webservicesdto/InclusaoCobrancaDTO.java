/*
 * XML Type:  InclusaoCobrancaDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto;


/**
 * An XML InclusaoCobrancaDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public interface InclusaoCobrancaDTO extends org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTO
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(InclusaoCobrancaDTO.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3965ADB232D1D9A0AB9A333DE5AD2A31").resolveHandle("inclusaocobrancadtod9a7type");
    
    /**
     * Gets the "AprovadoConjuge" element
     */
    java.lang.String getAprovadoConjuge();
    
    /**
     * Gets (as xml) the "AprovadoConjuge" element
     */
    org.apache.xmlbeans.XmlString xgetAprovadoConjuge();
    
    /**
     * Tests for nil "AprovadoConjuge" element
     */
    boolean isNilAprovadoConjuge();
    
    /**
     * True if has "AprovadoConjuge" element
     */
    boolean isSetAprovadoConjuge();
    
    /**
     * Sets the "AprovadoConjuge" element
     */
    void setAprovadoConjuge(java.lang.String aprovadoConjuge);
    
    /**
     * Sets (as xml) the "AprovadoConjuge" element
     */
    void xsetAprovadoConjuge(org.apache.xmlbeans.XmlString aprovadoConjuge);
    
    /**
     * Nils the "AprovadoConjuge" element
     */
    void setNilAprovadoConjuge();
    
    /**
     * Unsets the "AprovadoConjuge" element
     */
    void unsetAprovadoConjuge();
    
    /**
     * Gets the "NomeAnexo" element
     */
    java.lang.String getNomeAnexo();
    
    /**
     * Gets (as xml) the "NomeAnexo" element
     */
    org.apache.xmlbeans.XmlString xgetNomeAnexo();
    
    /**
     * Tests for nil "NomeAnexo" element
     */
    boolean isNilNomeAnexo();
    
    /**
     * True if has "NomeAnexo" element
     */
    boolean isSetNomeAnexo();
    
    /**
     * Sets the "NomeAnexo" element
     */
    void setNomeAnexo(java.lang.String nomeAnexo);
    
    /**
     * Sets (as xml) the "NomeAnexo" element
     */
    void xsetNomeAnexo(org.apache.xmlbeans.XmlString nomeAnexo);
    
    /**
     * Nils the "NomeAnexo" element
     */
    void setNilNomeAnexo();
    
    /**
     * Unsets the "NomeAnexo" element
     */
    void unsetNomeAnexo();
    
    /**
     * Gets the "ParcelaIndeterminada" element
     */
    int getParcelaIndeterminada();
    
    /**
     * Gets (as xml) the "ParcelaIndeterminada" element
     */
    org.apache.xmlbeans.XmlInt xgetParcelaIndeterminada();
    
    /**
     * True if has "ParcelaIndeterminada" element
     */
    boolean isSetParcelaIndeterminada();
    
    /**
     * Sets the "ParcelaIndeterminada" element
     */
    void setParcelaIndeterminada(int parcelaIndeterminada);
    
    /**
     * Sets (as xml) the "ParcelaIndeterminada" element
     */
    void xsetParcelaIndeterminada(org.apache.xmlbeans.XmlInt parcelaIndeterminada);
    
    /**
     * Unsets the "ParcelaIndeterminada" element
     */
    void unsetParcelaIndeterminada();
    
    /**
     * Gets the "QtdParcelas" element
     */
    int getQtdParcelas();
    
    /**
     * Gets (as xml) the "QtdParcelas" element
     */
    org.apache.xmlbeans.XmlInt xgetQtdParcelas();
    
    /**
     * True if has "QtdParcelas" element
     */
    boolean isSetQtdParcelas();
    
    /**
     * Sets the "QtdParcelas" element
     */
    void setQtdParcelas(int qtdParcelas);
    
    /**
     * Sets (as xml) the "QtdParcelas" element
     */
    void xsetQtdParcelas(org.apache.xmlbeans.XmlInt qtdParcelas);
    
    /**
     * Unsets the "QtdParcelas" element
     */
    void unsetQtdParcelas();
    
    /**
     * Gets the "Valor" element
     */
    java.math.BigDecimal getValor();
    
    /**
     * Gets (as xml) the "Valor" element
     */
    org.apache.xmlbeans.XmlDecimal xgetValor();
    
    /**
     * True if has "Valor" element
     */
    boolean isSetValor();
    
    /**
     * Sets the "Valor" element
     */
    void setValor(java.math.BigDecimal valor);
    
    /**
     * Sets (as xml) the "Valor" element
     */
    void xsetValor(org.apache.xmlbeans.XmlDecimal valor);
    
    /**
     * Unsets the "Valor" element
     */
    void unsetValor();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO newInstance() {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.InclusaoCobrancaDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
