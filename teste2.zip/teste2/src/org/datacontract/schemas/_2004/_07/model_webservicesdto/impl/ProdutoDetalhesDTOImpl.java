/*
 * XML Type:  ProdutoDetalhesDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ProdutoDetalhesDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ProdutoDetalhesDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.ProdutoDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO
{
    private static final long serialVersionUID = 1L;
    
    public ProdutoDetalhesDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CANCELADOPOR$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "CanceladoPor");
    private static final javax.xml.namespace.QName DATACANCELAMENTOCOBRANCA$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "DataCancelamentoCobranca");
    private static final javax.xml.namespace.QName DATACOBRANCA$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "DataCobranca");
    private static final javax.xml.namespace.QName DESCMOTCANCELAMENTO$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "DescMotCancelamento");
    private static final javax.xml.namespace.QName DESCRICAOSTATUS$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "DescricaoStatus");
    private static final javax.xml.namespace.QName DETALHEPARCELAS$10 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "DetalheParcelas");
    private static final javax.xml.namespace.QName IDENTIFICACAO$12 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Identificacao");
    private static final javax.xml.namespace.QName NOMEANEXOS$14 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "NomeAnexos");
    private static final javax.xml.namespace.QName QTDPARCELAS$16 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "QtdParcelas");
    private static final javax.xml.namespace.QName STATUS$18 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Status");
    private static final javax.xml.namespace.QName VALOR$20 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Valor");
    
    
    /**
     * Gets the "CanceladoPor" element
     */
    public java.lang.String getCanceladoPor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CANCELADOPOR$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CanceladoPor" element
     */
    public org.apache.xmlbeans.XmlString xgetCanceladoPor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CANCELADOPOR$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CanceladoPor" element
     */
    public boolean isNilCanceladoPor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CANCELADOPOR$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CanceladoPor" element
     */
    public boolean isSetCanceladoPor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CANCELADOPOR$0) != 0;
        }
    }
    
    /**
     * Sets the "CanceladoPor" element
     */
    public void setCanceladoPor(java.lang.String canceladoPor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CANCELADOPOR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CANCELADOPOR$0);
            }
            target.setStringValue(canceladoPor);
        }
    }
    
    /**
     * Sets (as xml) the "CanceladoPor" element
     */
    public void xsetCanceladoPor(org.apache.xmlbeans.XmlString canceladoPor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CANCELADOPOR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CANCELADOPOR$0);
            }
            target.set(canceladoPor);
        }
    }
    
    /**
     * Nils the "CanceladoPor" element
     */
    public void setNilCanceladoPor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CANCELADOPOR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CANCELADOPOR$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CanceladoPor" element
     */
    public void unsetCanceladoPor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CANCELADOPOR$0, 0);
        }
    }
    
    /**
     * Gets the "DataCancelamentoCobranca" element
     */
    public java.lang.String getDataCancelamentoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATACANCELAMENTOCOBRANCA$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataCancelamentoCobranca" element
     */
    public org.apache.xmlbeans.XmlString xgetDataCancelamentoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATACANCELAMENTOCOBRANCA$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataCancelamentoCobranca" element
     */
    public boolean isNilDataCancelamentoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATACANCELAMENTOCOBRANCA$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataCancelamentoCobranca" element
     */
    public boolean isSetDataCancelamentoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATACANCELAMENTOCOBRANCA$2) != 0;
        }
    }
    
    /**
     * Sets the "DataCancelamentoCobranca" element
     */
    public void setDataCancelamentoCobranca(java.lang.String dataCancelamentoCobranca)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATACANCELAMENTOCOBRANCA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATACANCELAMENTOCOBRANCA$2);
            }
            target.setStringValue(dataCancelamentoCobranca);
        }
    }
    
    /**
     * Sets (as xml) the "DataCancelamentoCobranca" element
     */
    public void xsetDataCancelamentoCobranca(org.apache.xmlbeans.XmlString dataCancelamentoCobranca)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATACANCELAMENTOCOBRANCA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATACANCELAMENTOCOBRANCA$2);
            }
            target.set(dataCancelamentoCobranca);
        }
    }
    
    /**
     * Nils the "DataCancelamentoCobranca" element
     */
    public void setNilDataCancelamentoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATACANCELAMENTOCOBRANCA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATACANCELAMENTOCOBRANCA$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataCancelamentoCobranca" element
     */
    public void unsetDataCancelamentoCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATACANCELAMENTOCOBRANCA$2, 0);
        }
    }
    
    /**
     * Gets the "DataCobranca" element
     */
    public java.lang.String getDataCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATACOBRANCA$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataCobranca" element
     */
    public org.apache.xmlbeans.XmlString xgetDataCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATACOBRANCA$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataCobranca" element
     */
    public boolean isNilDataCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATACOBRANCA$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataCobranca" element
     */
    public boolean isSetDataCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATACOBRANCA$4) != 0;
        }
    }
    
    /**
     * Sets the "DataCobranca" element
     */
    public void setDataCobranca(java.lang.String dataCobranca)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATACOBRANCA$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATACOBRANCA$4);
            }
            target.setStringValue(dataCobranca);
        }
    }
    
    /**
     * Sets (as xml) the "DataCobranca" element
     */
    public void xsetDataCobranca(org.apache.xmlbeans.XmlString dataCobranca)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATACOBRANCA$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATACOBRANCA$4);
            }
            target.set(dataCobranca);
        }
    }
    
    /**
     * Nils the "DataCobranca" element
     */
    public void setNilDataCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATACOBRANCA$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATACOBRANCA$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataCobranca" element
     */
    public void unsetDataCobranca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATACOBRANCA$4, 0);
        }
    }
    
    /**
     * Gets the "DescMotCancelamento" element
     */
    public java.lang.String getDescMotCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCMOTCANCELAMENTO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DescMotCancelamento" element
     */
    public org.apache.xmlbeans.XmlString xgetDescMotCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCMOTCANCELAMENTO$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DescMotCancelamento" element
     */
    public boolean isNilDescMotCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCMOTCANCELAMENTO$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DescMotCancelamento" element
     */
    public boolean isSetDescMotCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DESCMOTCANCELAMENTO$6) != 0;
        }
    }
    
    /**
     * Sets the "DescMotCancelamento" element
     */
    public void setDescMotCancelamento(java.lang.String descMotCancelamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCMOTCANCELAMENTO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DESCMOTCANCELAMENTO$6);
            }
            target.setStringValue(descMotCancelamento);
        }
    }
    
    /**
     * Sets (as xml) the "DescMotCancelamento" element
     */
    public void xsetDescMotCancelamento(org.apache.xmlbeans.XmlString descMotCancelamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCMOTCANCELAMENTO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESCMOTCANCELAMENTO$6);
            }
            target.set(descMotCancelamento);
        }
    }
    
    /**
     * Nils the "DescMotCancelamento" element
     */
    public void setNilDescMotCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCMOTCANCELAMENTO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESCMOTCANCELAMENTO$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DescMotCancelamento" element
     */
    public void unsetDescMotCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DESCMOTCANCELAMENTO$6, 0);
        }
    }
    
    /**
     * Gets the "DescricaoStatus" element
     */
    public java.lang.String getDescricaoStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRICAOSTATUS$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DescricaoStatus" element
     */
    public org.apache.xmlbeans.XmlString xgetDescricaoStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRICAOSTATUS$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DescricaoStatus" element
     */
    public boolean isNilDescricaoStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRICAOSTATUS$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DescricaoStatus" element
     */
    public boolean isSetDescricaoStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DESCRICAOSTATUS$8) != 0;
        }
    }
    
    /**
     * Sets the "DescricaoStatus" element
     */
    public void setDescricaoStatus(java.lang.String descricaoStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRICAOSTATUS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DESCRICAOSTATUS$8);
            }
            target.setStringValue(descricaoStatus);
        }
    }
    
    /**
     * Sets (as xml) the "DescricaoStatus" element
     */
    public void xsetDescricaoStatus(org.apache.xmlbeans.XmlString descricaoStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRICAOSTATUS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESCRICAOSTATUS$8);
            }
            target.set(descricaoStatus);
        }
    }
    
    /**
     * Nils the "DescricaoStatus" element
     */
    public void setNilDescricaoStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRICAOSTATUS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESCRICAOSTATUS$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DescricaoStatus" element
     */
    public void unsetDescricaoStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DESCRICAOSTATUS$8, 0);
        }
    }
    
    /**
     * Gets the "DetalheParcelas" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO getDetalheParcelas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO)get_store().find_element_user(DETALHEPARCELAS$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "DetalheParcelas" element
     */
    public boolean isNilDetalheParcelas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO)get_store().find_element_user(DETALHEPARCELAS$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DetalheParcelas" element
     */
    public boolean isSetDetalheParcelas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DETALHEPARCELAS$10) != 0;
        }
    }
    
    /**
     * Sets the "DetalheParcelas" element
     */
    public void setDetalheParcelas(org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO detalheParcelas)
    {
        generatedSetterHelperImpl(detalheParcelas, DETALHEPARCELAS$10, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "DetalheParcelas" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO addNewDetalheParcelas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO)get_store().add_element_user(DETALHEPARCELAS$10);
            return target;
        }
    }
    
    /**
     * Nils the "DetalheParcelas" element
     */
    public void setNilDetalheParcelas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO)get_store().find_element_user(DETALHEPARCELAS$10, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfParcelaProdutoDetalhesDTO)get_store().add_element_user(DETALHEPARCELAS$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DetalheParcelas" element
     */
    public void unsetDetalheParcelas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DETALHEPARCELAS$10, 0);
        }
    }
    
    /**
     * Gets the "Identificacao" element
     */
    public java.lang.String getIdentificacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDENTIFICACAO$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Identificacao" element
     */
    public org.apache.xmlbeans.XmlString xgetIdentificacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDENTIFICACAO$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Identificacao" element
     */
    public boolean isNilIdentificacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDENTIFICACAO$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Identificacao" element
     */
    public boolean isSetIdentificacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IDENTIFICACAO$12) != 0;
        }
    }
    
    /**
     * Sets the "Identificacao" element
     */
    public void setIdentificacao(java.lang.String identificacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDENTIFICACAO$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IDENTIFICACAO$12);
            }
            target.setStringValue(identificacao);
        }
    }
    
    /**
     * Sets (as xml) the "Identificacao" element
     */
    public void xsetIdentificacao(org.apache.xmlbeans.XmlString identificacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDENTIFICACAO$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDENTIFICACAO$12);
            }
            target.set(identificacao);
        }
    }
    
    /**
     * Nils the "Identificacao" element
     */
    public void setNilIdentificacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDENTIFICACAO$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDENTIFICACAO$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Identificacao" element
     */
    public void unsetIdentificacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IDENTIFICACAO$12, 0);
        }
    }
    
    /**
     * Gets the "NomeAnexos" element
     */
    public com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring getNomeAnexos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring target = null;
            target = (com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring)get_store().find_element_user(NOMEANEXOS$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "NomeAnexos" element
     */
    public boolean isNilNomeAnexos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring target = null;
            target = (com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring)get_store().find_element_user(NOMEANEXOS$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NomeAnexos" element
     */
    public boolean isSetNomeAnexos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOMEANEXOS$14) != 0;
        }
    }
    
    /**
     * Sets the "NomeAnexos" element
     */
    public void setNomeAnexos(com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring nomeAnexos)
    {
        generatedSetterHelperImpl(nomeAnexos, NOMEANEXOS$14, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "NomeAnexos" element
     */
    public com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring addNewNomeAnexos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring target = null;
            target = (com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring)get_store().add_element_user(NOMEANEXOS$14);
            return target;
        }
    }
    
    /**
     * Nils the "NomeAnexos" element
     */
    public void setNilNomeAnexos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring target = null;
            target = (com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring)get_store().find_element_user(NOMEANEXOS$14, 0);
            if (target == null)
            {
                target = (com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring)get_store().add_element_user(NOMEANEXOS$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NomeAnexos" element
     */
    public void unsetNomeAnexos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOMEANEXOS$14, 0);
        }
    }
    
    /**
     * Gets the "QtdParcelas" element
     */
    public int getQtdParcelas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(QTDPARCELAS$16, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "QtdParcelas" element
     */
    public org.apache.xmlbeans.XmlInt xgetQtdParcelas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(QTDPARCELAS$16, 0);
            return target;
        }
    }
    
    /**
     * True if has "QtdParcelas" element
     */
    public boolean isSetQtdParcelas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QTDPARCELAS$16) != 0;
        }
    }
    
    /**
     * Sets the "QtdParcelas" element
     */
    public void setQtdParcelas(int qtdParcelas)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(QTDPARCELAS$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(QTDPARCELAS$16);
            }
            target.setIntValue(qtdParcelas);
        }
    }
    
    /**
     * Sets (as xml) the "QtdParcelas" element
     */
    public void xsetQtdParcelas(org.apache.xmlbeans.XmlInt qtdParcelas)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(QTDPARCELAS$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(QTDPARCELAS$16);
            }
            target.set(qtdParcelas);
        }
    }
    
    /**
     * Unsets the "QtdParcelas" element
     */
    public void unsetQtdParcelas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QTDPARCELAS$16, 0);
        }
    }
    
    /**
     * Gets the "Status" element
     */
    public int getStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STATUS$18, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "Status" element
     */
    public org.apache.xmlbeans.XmlInt xgetStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(STATUS$18, 0);
            return target;
        }
    }
    
    /**
     * True if has "Status" element
     */
    public boolean isSetStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(STATUS$18) != 0;
        }
    }
    
    /**
     * Sets the "Status" element
     */
    public void setStatus(int status)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STATUS$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(STATUS$18);
            }
            target.setIntValue(status);
        }
    }
    
    /**
     * Sets (as xml) the "Status" element
     */
    public void xsetStatus(org.apache.xmlbeans.XmlInt status)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(STATUS$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(STATUS$18);
            }
            target.set(status);
        }
    }
    
    /**
     * Unsets the "Status" element
     */
    public void unsetStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(STATUS$18, 0);
        }
    }
    
    /**
     * Gets the "Valor" element
     */
    public java.math.BigDecimal getValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALOR$20, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "Valor" element
     */
    public org.apache.xmlbeans.XmlDecimal xgetValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDecimal target = null;
            target = (org.apache.xmlbeans.XmlDecimal)get_store().find_element_user(VALOR$20, 0);
            return target;
        }
    }
    
    /**
     * True if has "Valor" element
     */
    public boolean isSetValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALOR$20) != 0;
        }
    }
    
    /**
     * Sets the "Valor" element
     */
    public void setValor(java.math.BigDecimal valor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALOR$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALOR$20);
            }
            target.setBigDecimalValue(valor);
        }
    }
    
    /**
     * Sets (as xml) the "Valor" element
     */
    public void xsetValor(org.apache.xmlbeans.XmlDecimal valor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDecimal target = null;
            target = (org.apache.xmlbeans.XmlDecimal)get_store().find_element_user(VALOR$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDecimal)get_store().add_element_user(VALOR$20);
            }
            target.set(valor);
        }
    }
    
    /**
     * Unsets the "Valor" element
     */
    public void unsetValor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALOR$20, 0);
        }
    }
}
