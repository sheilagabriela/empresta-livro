/*
 * XML Type:  ArrayOfProdutoDetalhesDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ArrayOfProdutoDetalhesDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ArrayOfProdutoDetalhesDTOImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfProdutoDetalhesDTO
{
    private static final long serialVersionUID = 1L;
    
    public ArrayOfProdutoDetalhesDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PRODUTODETALHESDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ProdutoDetalhesDTO");
    
    
    /**
     * Gets array of all "ProdutoDetalhesDTO" elements
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO[] getProdutoDetalhesDTOArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PRODUTODETALHESDTO$0, targetList);
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO[] result = new org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "ProdutoDetalhesDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO getProdutoDetalhesDTOArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO)get_store().find_element_user(PRODUTODETALHESDTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "ProdutoDetalhesDTO" element
     */
    public boolean isNilProdutoDetalhesDTOArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO)get_store().find_element_user(PRODUTODETALHESDTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "ProdutoDetalhesDTO" element
     */
    public int sizeOfProdutoDetalhesDTOArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRODUTODETALHESDTO$0);
        }
    }
    
    /**
     * Sets array of all "ProdutoDetalhesDTO" element  WARNING: This method is not atomicaly synchronized.
     */
    public void setProdutoDetalhesDTOArray(org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO[] produtoDetalhesDTOArray)
    {
        check_orphaned();
        arraySetterHelper(produtoDetalhesDTOArray, PRODUTODETALHESDTO$0);
    }
    
    /**
     * Sets ith "ProdutoDetalhesDTO" element
     */
    public void setProdutoDetalhesDTOArray(int i, org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO produtoDetalhesDTO)
    {
        generatedSetterHelperImpl(produtoDetalhesDTO, PRODUTODETALHESDTO$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
    }
    
    /**
     * Nils the ith "ProdutoDetalhesDTO" element
     */
    public void setNilProdutoDetalhesDTOArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO)get_store().find_element_user(PRODUTODETALHESDTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "ProdutoDetalhesDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO insertNewProdutoDetalhesDTO(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO)get_store().insert_element_user(PRODUTODETALHESDTO$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "ProdutoDetalhesDTO" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO addNewProdutoDetalhesDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ProdutoDetalhesDTO)get_store().add_element_user(PRODUTODETALHESDTO$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "ProdutoDetalhesDTO" element
     */
    public void removeProdutoDetalhesDTO(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRODUTODETALHESDTO$0, i);
        }
    }
}
