/*
 * An XML document type.
 * Localname: DadosParceiroOutputDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * A document containing one DadosParceiroOutputDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO) element.
 *
 * This is a complex type.
 */
public class DadosParceiroOutputDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public DadosParceiroOutputDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DADOSPARCEIROOUTPUTDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DadosParceiroOutputDTO");
    
    
    /**
     * Gets the "DadosParceiroOutputDTO" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO getDadosParceiroOutputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO)get_store().find_element_user(DADOSPARCEIROOUTPUTDTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "DadosParceiroOutputDTO" element
     */
    public boolean isNilDadosParceiroOutputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO)get_store().find_element_user(DADOSPARCEIROOUTPUTDTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "DadosParceiroOutputDTO" element
     */
    public void setDadosParceiroOutputDTO(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO dadosParceiroOutputDTO)
    {
        generatedSetterHelperImpl(dadosParceiroOutputDTO, DADOSPARCEIROOUTPUTDTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "DadosParceiroOutputDTO" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO addNewDadosParceiroOutputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO)get_store().add_element_user(DADOSPARCEIROOUTPUTDTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "DadosParceiroOutputDTO" element
     */
    public void setNilDadosParceiroOutputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO)get_store().find_element_user(DADOSPARCEIROOUTPUTDTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosParceiroOutputDTO)get_store().add_element_user(DADOSPARCEIROOUTPUTDTO$0);
            }
            target.setNil();
        }
    }
}
