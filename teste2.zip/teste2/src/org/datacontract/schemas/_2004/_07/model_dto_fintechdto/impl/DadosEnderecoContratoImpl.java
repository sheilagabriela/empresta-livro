/*
 * XML Type:  DadosEnderecoContrato
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * An XML DadosEnderecoContrato(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public class DadosEnderecoContratoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato
{
    private static final long serialVersionUID = 1L;
    
    public DadosEnderecoContratoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName BAIRRO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Bairro");
    private static final javax.xml.namespace.QName CEP$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "CEP");
    private static final javax.xml.namespace.QName CIDADE$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Cidade");
    private static final javax.xml.namespace.QName ESTADO$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Estado");
    private static final javax.xml.namespace.QName NUMIMOVEL$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "NumImovel");
    private static final javax.xml.namespace.QName REFLOC$10 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "RefLoc");
    private static final javax.xml.namespace.QName RUA$12 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "Rua");
    
    
    /**
     * Gets the "Bairro" element
     */
    public java.lang.String getBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BAIRRO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Bairro" element
     */
    public org.apache.xmlbeans.XmlString xgetBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BAIRRO$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Bairro" element
     */
    public boolean isNilBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BAIRRO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Bairro" element
     */
    public boolean isSetBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(BAIRRO$0) != 0;
        }
    }
    
    /**
     * Sets the "Bairro" element
     */
    public void setBairro(java.lang.String bairro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BAIRRO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(BAIRRO$0);
            }
            target.setStringValue(bairro);
        }
    }
    
    /**
     * Sets (as xml) the "Bairro" element
     */
    public void xsetBairro(org.apache.xmlbeans.XmlString bairro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BAIRRO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(BAIRRO$0);
            }
            target.set(bairro);
        }
    }
    
    /**
     * Nils the "Bairro" element
     */
    public void setNilBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BAIRRO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(BAIRRO$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Bairro" element
     */
    public void unsetBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(BAIRRO$0, 0);
        }
    }
    
    /**
     * Gets the "CEP" element
     */
    public java.lang.String getCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CEP" element
     */
    public org.apache.xmlbeans.XmlString xgetCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CEP$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CEP" element
     */
    public boolean isNilCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CEP$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CEP" element
     */
    public boolean isSetCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CEP$2) != 0;
        }
    }
    
    /**
     * Sets the "CEP" element
     */
    public void setCEP(java.lang.String cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CEP$2);
            }
            target.setStringValue(cep);
        }
    }
    
    /**
     * Sets (as xml) the "CEP" element
     */
    public void xsetCEP(org.apache.xmlbeans.XmlString cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CEP$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CEP$2);
            }
            target.set(cep);
        }
    }
    
    /**
     * Nils the "CEP" element
     */
    public void setNilCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CEP$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CEP$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CEP" element
     */
    public void unsetCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CEP$2, 0);
        }
    }
    
    /**
     * Gets the "Cidade" element
     */
    public java.lang.String getCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CIDADE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Cidade" element
     */
    public org.apache.xmlbeans.XmlString xgetCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CIDADE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Cidade" element
     */
    public boolean isNilCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CIDADE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Cidade" element
     */
    public boolean isSetCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CIDADE$4) != 0;
        }
    }
    
    /**
     * Sets the "Cidade" element
     */
    public void setCidade(java.lang.String cidade)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CIDADE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CIDADE$4);
            }
            target.setStringValue(cidade);
        }
    }
    
    /**
     * Sets (as xml) the "Cidade" element
     */
    public void xsetCidade(org.apache.xmlbeans.XmlString cidade)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CIDADE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CIDADE$4);
            }
            target.set(cidade);
        }
    }
    
    /**
     * Nils the "Cidade" element
     */
    public void setNilCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CIDADE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CIDADE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Cidade" element
     */
    public void unsetCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CIDADE$4, 0);
        }
    }
    
    /**
     * Gets the "Estado" element
     */
    public java.lang.String getEstado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ESTADO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Estado" element
     */
    public org.apache.xmlbeans.XmlString xgetEstado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ESTADO$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Estado" element
     */
    public boolean isNilEstado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ESTADO$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Estado" element
     */
    public boolean isSetEstado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ESTADO$6) != 0;
        }
    }
    
    /**
     * Sets the "Estado" element
     */
    public void setEstado(java.lang.String estado)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ESTADO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ESTADO$6);
            }
            target.setStringValue(estado);
        }
    }
    
    /**
     * Sets (as xml) the "Estado" element
     */
    public void xsetEstado(org.apache.xmlbeans.XmlString estado)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ESTADO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ESTADO$6);
            }
            target.set(estado);
        }
    }
    
    /**
     * Nils the "Estado" element
     */
    public void setNilEstado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ESTADO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ESTADO$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Estado" element
     */
    public void unsetEstado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ESTADO$6, 0);
        }
    }
    
    /**
     * Gets the "NumImovel" element
     */
    public java.lang.String getNumImovel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMIMOVEL$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NumImovel" element
     */
    public org.apache.xmlbeans.XmlString xgetNumImovel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMIMOVEL$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "NumImovel" element
     */
    public boolean isNilNumImovel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMIMOVEL$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NumImovel" element
     */
    public boolean isSetNumImovel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMIMOVEL$8) != 0;
        }
    }
    
    /**
     * Sets the "NumImovel" element
     */
    public void setNumImovel(java.lang.String numImovel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMIMOVEL$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMIMOVEL$8);
            }
            target.setStringValue(numImovel);
        }
    }
    
    /**
     * Sets (as xml) the "NumImovel" element
     */
    public void xsetNumImovel(org.apache.xmlbeans.XmlString numImovel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMIMOVEL$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMIMOVEL$8);
            }
            target.set(numImovel);
        }
    }
    
    /**
     * Nils the "NumImovel" element
     */
    public void setNilNumImovel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMIMOVEL$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMIMOVEL$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NumImovel" element
     */
    public void unsetNumImovel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMIMOVEL$8, 0);
        }
    }
    
    /**
     * Gets the "RefLoc" element
     */
    public java.lang.String getRefLoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REFLOC$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "RefLoc" element
     */
    public org.apache.xmlbeans.XmlString xgetRefLoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(REFLOC$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "RefLoc" element
     */
    public boolean isNilRefLoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(REFLOC$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "RefLoc" element
     */
    public boolean isSetRefLoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REFLOC$10) != 0;
        }
    }
    
    /**
     * Sets the "RefLoc" element
     */
    public void setRefLoc(java.lang.String refLoc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REFLOC$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REFLOC$10);
            }
            target.setStringValue(refLoc);
        }
    }
    
    /**
     * Sets (as xml) the "RefLoc" element
     */
    public void xsetRefLoc(org.apache.xmlbeans.XmlString refLoc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(REFLOC$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(REFLOC$10);
            }
            target.set(refLoc);
        }
    }
    
    /**
     * Nils the "RefLoc" element
     */
    public void setNilRefLoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(REFLOC$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(REFLOC$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "RefLoc" element
     */
    public void unsetRefLoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REFLOC$10, 0);
        }
    }
    
    /**
     * Gets the "Rua" element
     */
    public java.lang.String getRua()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RUA$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Rua" element
     */
    public org.apache.xmlbeans.XmlString xgetRua()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RUA$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Rua" element
     */
    public boolean isNilRua()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RUA$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Rua" element
     */
    public boolean isSetRua()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RUA$12) != 0;
        }
    }
    
    /**
     * Sets the "Rua" element
     */
    public void setRua(java.lang.String rua)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RUA$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RUA$12);
            }
            target.setStringValue(rua);
        }
    }
    
    /**
     * Sets (as xml) the "Rua" element
     */
    public void xsetRua(org.apache.xmlbeans.XmlString rua)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RUA$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RUA$12);
            }
            target.set(rua);
        }
    }
    
    /**
     * Nils the "Rua" element
     */
    public void setNilRua()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RUA$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RUA$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Rua" element
     */
    public void unsetRua()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RUA$12, 0);
        }
    }
}
