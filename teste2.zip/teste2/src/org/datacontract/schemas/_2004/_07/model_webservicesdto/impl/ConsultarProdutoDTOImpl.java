/*
 * XML Type:  ConsultarProdutoDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML ConsultarProdutoDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class ConsultarProdutoDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.ServiceRequestPaiDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.ConsultarProdutoDTO
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarProdutoDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
