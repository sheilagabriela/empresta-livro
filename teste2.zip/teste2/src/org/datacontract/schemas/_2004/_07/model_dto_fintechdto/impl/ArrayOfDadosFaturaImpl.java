/*
 * XML Type:  ArrayOfDadosFatura
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * An XML ArrayOfDadosFatura(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public class ArrayOfDadosFaturaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosFatura
{
    private static final long serialVersionUID = 1L;
    
    public ArrayOfDadosFaturaImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DADOSFATURA$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DadosFatura");
    
    
    /**
     * Gets array of all "DadosFatura" elements
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura[] getDadosFaturaArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(DADOSFATURA$0, targetList);
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura[] result = new org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "DadosFatura" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura getDadosFaturaArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura)get_store().find_element_user(DADOSFATURA$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "DadosFatura" element
     */
    public boolean isNilDadosFaturaArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura)get_store().find_element_user(DADOSFATURA$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "DadosFatura" element
     */
    public int sizeOfDadosFaturaArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DADOSFATURA$0);
        }
    }
    
    /**
     * Sets array of all "DadosFatura" element  WARNING: This method is not atomicaly synchronized.
     */
    public void setDadosFaturaArray(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura[] dadosFaturaArray)
    {
        check_orphaned();
        arraySetterHelper(dadosFaturaArray, DADOSFATURA$0);
    }
    
    /**
     * Sets ith "DadosFatura" element
     */
    public void setDadosFaturaArray(int i, org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura dadosFatura)
    {
        generatedSetterHelperImpl(dadosFatura, DADOSFATURA$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
    }
    
    /**
     * Nils the ith "DadosFatura" element
     */
    public void setNilDadosFaturaArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura)get_store().find_element_user(DADOSFATURA$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "DadosFatura" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura insertNewDadosFatura(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura)get_store().insert_element_user(DADOSFATURA$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "DadosFatura" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura addNewDadosFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura)get_store().add_element_user(DADOSFATURA$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "DadosFatura" element
     */
    public void removeDadosFatura(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DADOSFATURA$0, i);
        }
    }
}
