/*
 * XML Type:  DadosInstalacaoOutputDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * An XML DadosInstalacaoOutputDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public class DadosInstalacaoOutputDTOImpl extends org.datacontract.schemas._2004._07.model_dto_fintechdto.impl.FintechBaseDTOImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosInstalacaoOutputDTO
{
    private static final long serialVersionUID = 1L;
    
    public DadosInstalacaoOutputDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName LISTACONTRATOS$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "ListaContratos");
    private static final javax.xml.namespace.QName LISTAENDERECOS$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "ListaEnderecos");
    
    
    /**
     * Gets the "ListaContratos" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosContrato getListaContratos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosContrato)get_store().find_element_user(LISTACONTRATOS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ListaContratos" element
     */
    public boolean isNilListaContratos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosContrato)get_store().find_element_user(LISTACONTRATOS$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ListaContratos" element
     */
    public boolean isSetListaContratos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LISTACONTRATOS$0) != 0;
        }
    }
    
    /**
     * Sets the "ListaContratos" element
     */
    public void setListaContratos(org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosContrato listaContratos)
    {
        generatedSetterHelperImpl(listaContratos, LISTACONTRATOS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ListaContratos" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosContrato addNewListaContratos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosContrato)get_store().add_element_user(LISTACONTRATOS$0);
            return target;
        }
    }
    
    /**
     * Nils the "ListaContratos" element
     */
    public void setNilListaContratos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosContrato)get_store().find_element_user(LISTACONTRATOS$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosContrato)get_store().add_element_user(LISTACONTRATOS$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ListaContratos" element
     */
    public void unsetListaContratos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LISTACONTRATOS$0, 0);
        }
    }
    
    /**
     * Gets the "ListaEnderecos" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato getListaEnderecos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato)get_store().find_element_user(LISTAENDERECOS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ListaEnderecos" element
     */
    public boolean isNilListaEnderecos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato)get_store().find_element_user(LISTAENDERECOS$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ListaEnderecos" element
     */
    public boolean isSetListaEnderecos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LISTAENDERECOS$2) != 0;
        }
    }
    
    /**
     * Sets the "ListaEnderecos" element
     */
    public void setListaEnderecos(org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato listaEnderecos)
    {
        generatedSetterHelperImpl(listaEnderecos, LISTAENDERECOS$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ListaEnderecos" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato addNewListaEnderecos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato)get_store().add_element_user(LISTAENDERECOS$2);
            return target;
        }
    }
    
    /**
     * Nils the "ListaEnderecos" element
     */
    public void setNilListaEnderecos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato)get_store().find_element_user(LISTAENDERECOS$2, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato)get_store().add_element_user(LISTAENDERECOS$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ListaEnderecos" element
     */
    public void unsetListaEnderecos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LISTAENDERECOS$2, 0);
        }
    }
}
