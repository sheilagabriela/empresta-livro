/*
 * XML Type:  ArrayOfDadosEnderecoContrato
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * An XML ArrayOfDadosEnderecoContrato(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO).
 *
 * This is a complex type.
 */
public class ArrayOfDadosEnderecoContratoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato
{
    private static final long serialVersionUID = 1L;
    
    public ArrayOfDadosEnderecoContratoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DADOSENDERECOCONTRATO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DadosEnderecoContrato");
    
    
    /**
     * Gets array of all "DadosEnderecoContrato" elements
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato[] getDadosEnderecoContratoArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(DADOSENDERECOCONTRATO$0, targetList);
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato[] result = new org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "DadosEnderecoContrato" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato getDadosEnderecoContratoArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato)get_store().find_element_user(DADOSENDERECOCONTRATO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "DadosEnderecoContrato" element
     */
    public boolean isNilDadosEnderecoContratoArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato)get_store().find_element_user(DADOSENDERECOCONTRATO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "DadosEnderecoContrato" element
     */
    public int sizeOfDadosEnderecoContratoArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DADOSENDERECOCONTRATO$0);
        }
    }
    
    /**
     * Sets array of all "DadosEnderecoContrato" element  WARNING: This method is not atomicaly synchronized.
     */
    public void setDadosEnderecoContratoArray(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato[] dadosEnderecoContratoArray)
    {
        check_orphaned();
        arraySetterHelper(dadosEnderecoContratoArray, DADOSENDERECOCONTRATO$0);
    }
    
    /**
     * Sets ith "DadosEnderecoContrato" element
     */
    public void setDadosEnderecoContratoArray(int i, org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato dadosEnderecoContrato)
    {
        generatedSetterHelperImpl(dadosEnderecoContrato, DADOSENDERECOCONTRATO$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
    }
    
    /**
     * Nils the ith "DadosEnderecoContrato" element
     */
    public void setNilDadosEnderecoContratoArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato)get_store().find_element_user(DADOSENDERECOCONTRATO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "DadosEnderecoContrato" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato insertNewDadosEnderecoContrato(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato)get_store().insert_element_user(DADOSENDERECOCONTRATO$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "DadosEnderecoContrato" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato addNewDadosEnderecoContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnderecoContrato)get_store().add_element_user(DADOSENDERECOCONTRATO$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "DadosEnderecoContrato" element
     */
    public void removeDadosEnderecoContrato(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DADOSENDERECOCONTRATO$0, i);
        }
    }
}
