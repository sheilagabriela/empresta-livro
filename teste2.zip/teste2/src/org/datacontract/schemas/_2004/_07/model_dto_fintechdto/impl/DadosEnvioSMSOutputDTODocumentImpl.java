/*
 * An XML document type.
 * Localname: DadosEnvioSMSOutputDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTODocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * A document containing one DadosEnvioSMSOutputDTO(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO) element.
 *
 * This is a complex type.
 */
public class DadosEnvioSMSOutputDTODocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTODocument
{
    private static final long serialVersionUID = 1L;
    
    public DadosEnvioSMSOutputDTODocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DADOSENVIOSMSOUTPUTDTO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DadosEnvioSMSOutputDTO");
    
    
    /**
     * Gets the "DadosEnvioSMSOutputDTO" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO getDadosEnvioSMSOutputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO)get_store().find_element_user(DADOSENVIOSMSOUTPUTDTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "DadosEnvioSMSOutputDTO" element
     */
    public boolean isNilDadosEnvioSMSOutputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO)get_store().find_element_user(DADOSENVIOSMSOUTPUTDTO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "DadosEnvioSMSOutputDTO" element
     */
    public void setDadosEnvioSMSOutputDTO(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO dadosEnvioSMSOutputDTO)
    {
        generatedSetterHelperImpl(dadosEnvioSMSOutputDTO, DADOSENVIOSMSOUTPUTDTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "DadosEnvioSMSOutputDTO" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO addNewDadosEnvioSMSOutputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO)get_store().add_element_user(DADOSENVIOSMSOUTPUTDTO$0);
            return target;
        }
    }
    
    /**
     * Nils the "DadosEnvioSMSOutputDTO" element
     */
    public void setNilDadosEnvioSMSOutputDTO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO)get_store().find_element_user(DADOSENVIOSMSOUTPUTDTO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosEnvioSMSOutputDTO)get_store().add_element_user(DADOSENVIOSMSOUTPUTDTO$0);
            }
            target.setNil();
        }
    }
}
