/*
 * XML Type:  RetornoConsultaParceiroDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML RetornoConsultaParceiroDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class RetornoConsultaParceiroDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.ServiceRequestPaiDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.RetornoConsultaParceiroDTO
{
    private static final long serialVersionUID = 1L;
    
    public RetornoConsultaParceiroDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRYPARCEIRO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ArryParceiro");
    private static final javax.xml.namespace.QName CONSTULALISTAPARCEIRO$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "ConstulaListaParceiro");
    private static final javax.xml.namespace.QName RESULTADO$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Resultado");
    
    
    /**
     * Gets the "ArryParceiro" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO getArryParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO)get_store().find_element_user(ARRYPARCEIRO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArryParceiro" element
     */
    public boolean isNilArryParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO)get_store().find_element_user(ARRYPARCEIRO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ArryParceiro" element
     */
    public boolean isSetArryParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ARRYPARCEIRO$0) != 0;
        }
    }
    
    /**
     * Sets the "ArryParceiro" element
     */
    public void setArryParceiro(org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO arryParceiro)
    {
        generatedSetterHelperImpl(arryParceiro, ARRYPARCEIRO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ArryParceiro" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO addNewArryParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO)get_store().add_element_user(ARRYPARCEIRO$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArryParceiro" element
     */
    public void setNilArryParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO)get_store().find_element_user(ARRYPARCEIRO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO)get_store().add_element_user(ARRYPARCEIRO$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ArryParceiro" element
     */
    public void unsetArryParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ARRYPARCEIRO$0, 0);
        }
    }
    
    /**
     * Gets the "ConstulaListaParceiro" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO getConstulaListaParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO)get_store().find_element_user(CONSTULALISTAPARCEIRO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ConstulaListaParceiro" element
     */
    public boolean isNilConstulaListaParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO)get_store().find_element_user(CONSTULALISTAPARCEIRO$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ConstulaListaParceiro" element
     */
    public boolean isSetConstulaListaParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONSTULALISTAPARCEIRO$2) != 0;
        }
    }
    
    /**
     * Sets the "ConstulaListaParceiro" element
     */
    public void setConstulaListaParceiro(org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO constulaListaParceiro)
    {
        generatedSetterHelperImpl(constulaListaParceiro, CONSTULALISTAPARCEIRO$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConstulaListaParceiro" element
     */
    public org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO addNewConstulaListaParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO)get_store().add_element_user(CONSTULALISTAPARCEIRO$2);
            return target;
        }
    }
    
    /**
     * Nils the "ConstulaListaParceiro" element
     */
    public void setNilConstulaListaParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO target = null;
            target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO)get_store().find_element_user(CONSTULALISTAPARCEIRO$2, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_webservicesdto.ArrayOfConsultaParceiroDTO)get_store().add_element_user(CONSTULALISTAPARCEIRO$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ConstulaListaParceiro" element
     */
    public void unsetConstulaListaParceiro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONSTULALISTAPARCEIRO$2, 0);
        }
    }
    
    /**
     * Gets the "Resultado" element
     */
    public java.lang.String getResultado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RESULTADO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Resultado" element
     */
    public org.apache.xmlbeans.XmlString xgetResultado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RESULTADO$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Resultado" element
     */
    public boolean isNilResultado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RESULTADO$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Resultado" element
     */
    public boolean isSetResultado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RESULTADO$4) != 0;
        }
    }
    
    /**
     * Sets the "Resultado" element
     */
    public void setResultado(java.lang.String resultado)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RESULTADO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RESULTADO$4);
            }
            target.setStringValue(resultado);
        }
    }
    
    /**
     * Sets (as xml) the "Resultado" element
     */
    public void xsetResultado(org.apache.xmlbeans.XmlString resultado)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RESULTADO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RESULTADO$4);
            }
            target.set(resultado);
        }
    }
    
    /**
     * Nils the "Resultado" element
     */
    public void setNilResultado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RESULTADO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RESULTADO$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Resultado" element
     */
    public void unsetResultado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RESULTADO$4, 0);
        }
    }
}
