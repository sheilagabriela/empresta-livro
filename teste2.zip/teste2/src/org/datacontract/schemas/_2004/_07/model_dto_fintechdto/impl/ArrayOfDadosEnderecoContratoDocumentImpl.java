/*
 * An XML document type.
 * Localname: ArrayOfDadosEnderecoContrato
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContratoDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * A document containing one ArrayOfDadosEnderecoContrato(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO) element.
 *
 * This is a complex type.
 */
public class ArrayOfDadosEnderecoContratoDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContratoDocument
{
    private static final long serialVersionUID = 1L;
    
    public ArrayOfDadosEnderecoContratoDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFDADOSENDERECOCONTRATO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "ArrayOfDadosEnderecoContrato");
    
    
    /**
     * Gets the "ArrayOfDadosEnderecoContrato" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato getArrayOfDadosEnderecoContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato)get_store().find_element_user(ARRAYOFDADOSENDERECOCONTRATO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfDadosEnderecoContrato" element
     */
    public boolean isNilArrayOfDadosEnderecoContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato)get_store().find_element_user(ARRAYOFDADOSENDERECOCONTRATO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfDadosEnderecoContrato" element
     */
    public void setArrayOfDadosEnderecoContrato(org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato arrayOfDadosEnderecoContrato)
    {
        generatedSetterHelperImpl(arrayOfDadosEnderecoContrato, ARRAYOFDADOSENDERECOCONTRATO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ArrayOfDadosEnderecoContrato" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato addNewArrayOfDadosEnderecoContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato)get_store().add_element_user(ARRAYOFDADOSENDERECOCONTRATO$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfDadosEnderecoContrato" element
     */
    public void setNilArrayOfDadosEnderecoContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato)get_store().find_element_user(ARRAYOFDADOSENDERECOCONTRATO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.ArrayOfDadosEnderecoContrato)get_store().add_element_user(ARRAYOFDADOSENDERECOCONTRATO$0);
            }
            target.setNil();
        }
    }
}
