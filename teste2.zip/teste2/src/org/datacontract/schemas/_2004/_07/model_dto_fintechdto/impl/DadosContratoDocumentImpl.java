/*
 * An XML document type.
 * Localname: DadosContrato
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContratoDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * A document containing one DadosContrato(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO) element.
 *
 * This is a complex type.
 */
public class DadosContratoDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContratoDocument
{
    private static final long serialVersionUID = 1L;
    
    public DadosContratoDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DADOSCONTRATO$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DadosContrato");
    
    
    /**
     * Gets the "DadosContrato" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato getDadosContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato)get_store().find_element_user(DADOSCONTRATO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "DadosContrato" element
     */
    public boolean isNilDadosContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato)get_store().find_element_user(DADOSCONTRATO$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "DadosContrato" element
     */
    public void setDadosContrato(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato dadosContrato)
    {
        generatedSetterHelperImpl(dadosContrato, DADOSCONTRATO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "DadosContrato" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato addNewDadosContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato)get_store().add_element_user(DADOSCONTRATO$0);
            return target;
        }
    }
    
    /**
     * Nils the "DadosContrato" element
     */
    public void setNilDadosContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato)get_store().find_element_user(DADOSCONTRATO$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosContrato)get_store().add_element_user(DADOSCONTRATO$0);
            }
            target.setNil();
        }
    }
}
