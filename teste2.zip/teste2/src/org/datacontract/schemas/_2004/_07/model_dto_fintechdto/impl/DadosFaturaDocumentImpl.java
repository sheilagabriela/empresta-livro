/*
 * An XML document type.
 * Localname: DadosFatura
 * Namespace: http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO
 * Java type: org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFaturaDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_dto_fintechdto.impl;
/**
 * A document containing one DadosFatura(@http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO) element.
 *
 * This is a complex type.
 */
public class DadosFaturaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFaturaDocument
{
    private static final long serialVersionUID = 1L;
    
    public DadosFaturaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DADOSFATURA$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.Dto.FintechDTO", "DadosFatura");
    
    
    /**
     * Gets the "DadosFatura" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura getDadosFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura)get_store().find_element_user(DADOSFATURA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "DadosFatura" element
     */
    public boolean isNilDadosFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura)get_store().find_element_user(DADOSFATURA$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "DadosFatura" element
     */
    public void setDadosFatura(org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura dadosFatura)
    {
        generatedSetterHelperImpl(dadosFatura, DADOSFATURA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "DadosFatura" element
     */
    public org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura addNewDadosFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura)get_store().add_element_user(DADOSFATURA$0);
            return target;
        }
    }
    
    /**
     * Nils the "DadosFatura" element
     */
    public void setNilDadosFatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura target = null;
            target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura)get_store().find_element_user(DADOSFATURA$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.model_dto_fintechdto.DadosFatura)get_store().add_element_user(DADOSFATURA$0);
            }
            target.setNil();
        }
    }
}
