/*
 * XML Type:  CadastroDoacaoDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto;


/**
 * An XML CadastroDoacaoDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public interface CadastroDoacaoDTO extends org.datacontract.schemas._2004._07.model_webservicesdto.CobrancaDTO
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CadastroDoacaoDTO.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3965ADB232D1D9A0AB9A333DE5AD2A31").resolveHandle("cadastrodoacaodto5c9atype");
    
    /**
     * Gets the "CPF" element
     */
    java.lang.String getCPF();
    
    /**
     * Gets (as xml) the "CPF" element
     */
    org.apache.xmlbeans.XmlString xgetCPF();
    
    /**
     * Tests for nil "CPF" element
     */
    boolean isNilCPF();
    
    /**
     * True if has "CPF" element
     */
    boolean isSetCPF();
    
    /**
     * Sets the "CPF" element
     */
    void setCPF(java.lang.String cpf);
    
    /**
     * Sets (as xml) the "CPF" element
     */
    void xsetCPF(org.apache.xmlbeans.XmlString cpf);
    
    /**
     * Nils the "CPF" element
     */
    void setNilCPF();
    
    /**
     * Unsets the "CPF" element
     */
    void unsetCPF();
    
    /**
     * Gets the "CodDistribuidora" element
     */
    java.lang.String getCodDistribuidora();
    
    /**
     * Gets (as xml) the "CodDistribuidora" element
     */
    org.apache.xmlbeans.XmlString xgetCodDistribuidora();
    
    /**
     * Tests for nil "CodDistribuidora" element
     */
    boolean isNilCodDistribuidora();
    
    /**
     * True if has "CodDistribuidora" element
     */
    boolean isSetCodDistribuidora();
    
    /**
     * Sets the "CodDistribuidora" element
     */
    void setCodDistribuidora(java.lang.String codDistribuidora);
    
    /**
     * Sets (as xml) the "CodDistribuidora" element
     */
    void xsetCodDistribuidora(org.apache.xmlbeans.XmlString codDistribuidora);
    
    /**
     * Nils the "CodDistribuidora" element
     */
    void setNilCodDistribuidora();
    
    /**
     * Unsets the "CodDistribuidora" element
     */
    void unsetCodDistribuidora();
    
    /**
     * Gets the "DataNascimento" element
     */
    java.lang.String getDataNascimento();
    
    /**
     * Gets (as xml) the "DataNascimento" element
     */
    org.apache.xmlbeans.XmlString xgetDataNascimento();
    
    /**
     * Tests for nil "DataNascimento" element
     */
    boolean isNilDataNascimento();
    
    /**
     * True if has "DataNascimento" element
     */
    boolean isSetDataNascimento();
    
    /**
     * Sets the "DataNascimento" element
     */
    void setDataNascimento(java.lang.String dataNascimento);
    
    /**
     * Sets (as xml) the "DataNascimento" element
     */
    void xsetDataNascimento(org.apache.xmlbeans.XmlString dataNascimento);
    
    /**
     * Nils the "DataNascimento" element
     */
    void setNilDataNascimento();
    
    /**
     * Unsets the "DataNascimento" element
     */
    void unsetDataNascimento();
    
    /**
     * Gets the "Email" element
     */
    java.lang.String getEmail();
    
    /**
     * Gets (as xml) the "Email" element
     */
    org.apache.xmlbeans.XmlString xgetEmail();
    
    /**
     * Tests for nil "Email" element
     */
    boolean isNilEmail();
    
    /**
     * True if has "Email" element
     */
    boolean isSetEmail();
    
    /**
     * Sets the "Email" element
     */
    void setEmail(java.lang.String email);
    
    /**
     * Sets (as xml) the "Email" element
     */
    void xsetEmail(org.apache.xmlbeans.XmlString email);
    
    /**
     * Nils the "Email" element
     */
    void setNilEmail();
    
    /**
     * Unsets the "Email" element
     */
    void unsetEmail();
    
    /**
     * Gets the "NomeAnexo" element
     */
    java.lang.String getNomeAnexo();
    
    /**
     * Gets (as xml) the "NomeAnexo" element
     */
    org.apache.xmlbeans.XmlString xgetNomeAnexo();
    
    /**
     * Tests for nil "NomeAnexo" element
     */
    boolean isNilNomeAnexo();
    
    /**
     * True if has "NomeAnexo" element
     */
    boolean isSetNomeAnexo();
    
    /**
     * Sets the "NomeAnexo" element
     */
    void setNomeAnexo(java.lang.String nomeAnexo);
    
    /**
     * Sets (as xml) the "NomeAnexo" element
     */
    void xsetNomeAnexo(org.apache.xmlbeans.XmlString nomeAnexo);
    
    /**
     * Nils the "NomeAnexo" element
     */
    void setNilNomeAnexo();
    
    /**
     * Unsets the "NomeAnexo" element
     */
    void unsetNomeAnexo();
    
    /**
     * Gets the "RG" element
     */
    java.lang.String getRG();
    
    /**
     * Gets (as xml) the "RG" element
     */
    org.apache.xmlbeans.XmlString xgetRG();
    
    /**
     * Tests for nil "RG" element
     */
    boolean isNilRG();
    
    /**
     * True if has "RG" element
     */
    boolean isSetRG();
    
    /**
     * Sets the "RG" element
     */
    void setRG(java.lang.String rg);
    
    /**
     * Sets (as xml) the "RG" element
     */
    void xsetRG(org.apache.xmlbeans.XmlString rg);
    
    /**
     * Nils the "RG" element
     */
    void setNilRG();
    
    /**
     * Unsets the "RG" element
     */
    void unsetRG();
    
    /**
     * Gets the "TelefoneCelular" element
     */
    java.lang.String getTelefoneCelular();
    
    /**
     * Gets (as xml) the "TelefoneCelular" element
     */
    org.apache.xmlbeans.XmlString xgetTelefoneCelular();
    
    /**
     * Tests for nil "TelefoneCelular" element
     */
    boolean isNilTelefoneCelular();
    
    /**
     * True if has "TelefoneCelular" element
     */
    boolean isSetTelefoneCelular();
    
    /**
     * Sets the "TelefoneCelular" element
     */
    void setTelefoneCelular(java.lang.String telefoneCelular);
    
    /**
     * Sets (as xml) the "TelefoneCelular" element
     */
    void xsetTelefoneCelular(org.apache.xmlbeans.XmlString telefoneCelular);
    
    /**
     * Nils the "TelefoneCelular" element
     */
    void setNilTelefoneCelular();
    
    /**
     * Unsets the "TelefoneCelular" element
     */
    void unsetTelefoneCelular();
    
    /**
     * Gets the "TelefoneFixo" element
     */
    java.lang.String getTelefoneFixo();
    
    /**
     * Gets (as xml) the "TelefoneFixo" element
     */
    org.apache.xmlbeans.XmlString xgetTelefoneFixo();
    
    /**
     * Tests for nil "TelefoneFixo" element
     */
    boolean isNilTelefoneFixo();
    
    /**
     * True if has "TelefoneFixo" element
     */
    boolean isSetTelefoneFixo();
    
    /**
     * Sets the "TelefoneFixo" element
     */
    void setTelefoneFixo(java.lang.String telefoneFixo);
    
    /**
     * Sets (as xml) the "TelefoneFixo" element
     */
    void xsetTelefoneFixo(org.apache.xmlbeans.XmlString telefoneFixo);
    
    /**
     * Nils the "TelefoneFixo" element
     */
    void setNilTelefoneFixo();
    
    /**
     * Unsets the "TelefoneFixo" element
     */
    void unsetTelefoneFixo();
    
    /**
     * Gets the "TermoConfirmacao" element
     */
    java.lang.String getTermoConfirmacao();
    
    /**
     * Gets (as xml) the "TermoConfirmacao" element
     */
    org.apache.xmlbeans.XmlString xgetTermoConfirmacao();
    
    /**
     * Tests for nil "TermoConfirmacao" element
     */
    boolean isNilTermoConfirmacao();
    
    /**
     * True if has "TermoConfirmacao" element
     */
    boolean isSetTermoConfirmacao();
    
    /**
     * Sets the "TermoConfirmacao" element
     */
    void setTermoConfirmacao(java.lang.String termoConfirmacao);
    
    /**
     * Sets (as xml) the "TermoConfirmacao" element
     */
    void xsetTermoConfirmacao(org.apache.xmlbeans.XmlString termoConfirmacao);
    
    /**
     * Nils the "TermoConfirmacao" element
     */
    void setNilTermoConfirmacao();
    
    /**
     * Unsets the "TermoConfirmacao" element
     */
    void unsetTermoConfirmacao();
    
    /**
     * Gets the "Valor" element
     */
    java.lang.String getValor();
    
    /**
     * Gets (as xml) the "Valor" element
     */
    org.apache.xmlbeans.XmlString xgetValor();
    
    /**
     * Tests for nil "Valor" element
     */
    boolean isNilValor();
    
    /**
     * True if has "Valor" element
     */
    boolean isSetValor();
    
    /**
     * Sets the "Valor" element
     */
    void setValor(java.lang.String valor);
    
    /**
     * Sets (as xml) the "Valor" element
     */
    void xsetValor(org.apache.xmlbeans.XmlString valor);
    
    /**
     * Nils the "Valor" element
     */
    void setNilValor();
    
    /**
     * Unsets the "Valor" element
     */
    void unsetValor();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO newInstance() {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.model_webservicesdto.CadastroDoacaoDTO) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
