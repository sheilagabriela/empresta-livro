/*
 * XML Type:  CadastroClienteDTO
 * Namespace: http://schemas.datacontract.org/2004/07/Model.WebServicesDTO
 * Java type: org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.model_webservicesdto.impl;
/**
 * An XML CadastroClienteDTO(@http://schemas.datacontract.org/2004/07/Model.WebServicesDTO).
 *
 * This is a complex type.
 */
public class CadastroClienteDTOImpl extends org.datacontract.schemas._2004._07.model_webservicesdto.impl.ServiceRequestPaiDTOImpl implements org.datacontract.schemas._2004._07.model_webservicesdto.CadastroClienteDTO
{
    private static final long serialVersionUID = 1L;
    
    public CadastroClienteDTOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CNPJ$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "CNPJ");
    private static final javax.xml.namespace.QName CPF$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "CPF");
    private static final javax.xml.namespace.QName CPFCONJUGE$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "CPFConjuge");
    private static final javax.xml.namespace.QName CPFRESPONSAVEL$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "CpfResponsavel");
    private static final javax.xml.namespace.QName DATAABERTURA$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "DataAbertura");
    private static final javax.xml.namespace.QName DATANASCIMENTO$10 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "DataNascimento");
    private static final javax.xml.namespace.QName EMAIL$12 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Email");
    private static final javax.xml.namespace.QName INSCRICAOESTADUAL$14 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "InscricaoEstadual");
    private static final javax.xml.namespace.QName INSTALACAO$16 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Instalacao");
    private static final javax.xml.namespace.QName NOMECONJUGE$18 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "NomeConjuge");
    private static final javax.xml.namespace.QName NOMECONTATO$20 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "NomeContato");
    private static final javax.xml.namespace.QName NOMERESPONSAVEL$22 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "NomeResponsavel");
    private static final javax.xml.namespace.QName OPERACAO$24 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "Operacao");
    private static final javax.xml.namespace.QName PFPJ$26 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "PF_PJ");
    private static final javax.xml.namespace.QName PN$28 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "PN");
    private static final javax.xml.namespace.QName RG$30 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "RG");
    private static final javax.xml.namespace.QName RGCONJUGE$32 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "RGConjuge");
    private static final javax.xml.namespace.QName RGRESPONSAVEL$34 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "RgResponsavel");
    private static final javax.xml.namespace.QName TELEFONECELULAR$36 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "TelefoneCelular");
    private static final javax.xml.namespace.QName TELEFONECONTATO$38 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "TelefoneContato");
    private static final javax.xml.namespace.QName TELEFONEFIXO$40 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/Model.WebServicesDTO", "TelefoneFixo");
    
    
    /**
     * Gets the "CNPJ" element
     */
    public java.lang.String getCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CNPJ" element
     */
    public org.apache.xmlbeans.XmlString xgetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNPJ$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CNPJ" element
     */
    public boolean isNilCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNPJ$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CNPJ" element
     */
    public boolean isSetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CNPJ$0) != 0;
        }
    }
    
    /**
     * Sets the "CNPJ" element
     */
    public void setCNPJ(java.lang.String cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CNPJ$0);
            }
            target.setStringValue(cnpj);
        }
    }
    
    /**
     * Sets (as xml) the "CNPJ" element
     */
    public void xsetCNPJ(org.apache.xmlbeans.XmlString cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CNPJ$0);
            }
            target.set(cnpj);
        }
    }
    
    /**
     * Nils the "CNPJ" element
     */
    public void setNilCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CNPJ$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CNPJ" element
     */
    public void unsetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CNPJ$0, 0);
        }
    }
    
    /**
     * Gets the "CPF" element
     */
    public java.lang.String getCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CPF" element
     */
    public org.apache.xmlbeans.XmlString xgetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPF$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CPF" element
     */
    public boolean isNilCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPF$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CPF" element
     */
    public boolean isSetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPF$2) != 0;
        }
    }
    
    /**
     * Sets the "CPF" element
     */
    public void setCPF(java.lang.String cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPF$2);
            }
            target.setStringValue(cpf);
        }
    }
    
    /**
     * Sets (as xml) the "CPF" element
     */
    public void xsetCPF(org.apache.xmlbeans.XmlString cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CPF$2);
            }
            target.set(cpf);
        }
    }
    
    /**
     * Nils the "CPF" element
     */
    public void setNilCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CPF$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CPF" element
     */
    public void unsetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPF$2, 0);
        }
    }
    
    /**
     * Gets the "CPFConjuge" element
     */
    public java.lang.String getCPFConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPFCONJUGE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CPFConjuge" element
     */
    public org.apache.xmlbeans.XmlString xgetCPFConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPFCONJUGE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CPFConjuge" element
     */
    public boolean isNilCPFConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPFCONJUGE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CPFConjuge" element
     */
    public boolean isSetCPFConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPFCONJUGE$4) != 0;
        }
    }
    
    /**
     * Sets the "CPFConjuge" element
     */
    public void setCPFConjuge(java.lang.String cpfConjuge)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPFCONJUGE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPFCONJUGE$4);
            }
            target.setStringValue(cpfConjuge);
        }
    }
    
    /**
     * Sets (as xml) the "CPFConjuge" element
     */
    public void xsetCPFConjuge(org.apache.xmlbeans.XmlString cpfConjuge)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPFCONJUGE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CPFCONJUGE$4);
            }
            target.set(cpfConjuge);
        }
    }
    
    /**
     * Nils the "CPFConjuge" element
     */
    public void setNilCPFConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPFCONJUGE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CPFCONJUGE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CPFConjuge" element
     */
    public void unsetCPFConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPFCONJUGE$4, 0);
        }
    }
    
    /**
     * Gets the "CpfResponsavel" element
     */
    public java.lang.String getCpfResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPFRESPONSAVEL$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CpfResponsavel" element
     */
    public org.apache.xmlbeans.XmlString xgetCpfResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPFRESPONSAVEL$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CpfResponsavel" element
     */
    public boolean isNilCpfResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPFRESPONSAVEL$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CpfResponsavel" element
     */
    public boolean isSetCpfResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPFRESPONSAVEL$6) != 0;
        }
    }
    
    /**
     * Sets the "CpfResponsavel" element
     */
    public void setCpfResponsavel(java.lang.String cpfResponsavel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPFRESPONSAVEL$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPFRESPONSAVEL$6);
            }
            target.setStringValue(cpfResponsavel);
        }
    }
    
    /**
     * Sets (as xml) the "CpfResponsavel" element
     */
    public void xsetCpfResponsavel(org.apache.xmlbeans.XmlString cpfResponsavel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPFRESPONSAVEL$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CPFRESPONSAVEL$6);
            }
            target.set(cpfResponsavel);
        }
    }
    
    /**
     * Nils the "CpfResponsavel" element
     */
    public void setNilCpfResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CPFRESPONSAVEL$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CPFRESPONSAVEL$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CpfResponsavel" element
     */
    public void unsetCpfResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPFRESPONSAVEL$6, 0);
        }
    }
    
    /**
     * Gets the "DataAbertura" element
     */
    public java.lang.String getDataAbertura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAABERTURA$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataAbertura" element
     */
    public org.apache.xmlbeans.XmlString xgetDataAbertura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAABERTURA$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataAbertura" element
     */
    public boolean isNilDataAbertura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAABERTURA$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataAbertura" element
     */
    public boolean isSetDataAbertura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATAABERTURA$8) != 0;
        }
    }
    
    /**
     * Sets the "DataAbertura" element
     */
    public void setDataAbertura(java.lang.String dataAbertura)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAABERTURA$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAABERTURA$8);
            }
            target.setStringValue(dataAbertura);
        }
    }
    
    /**
     * Sets (as xml) the "DataAbertura" element
     */
    public void xsetDataAbertura(org.apache.xmlbeans.XmlString dataAbertura)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAABERTURA$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATAABERTURA$8);
            }
            target.set(dataAbertura);
        }
    }
    
    /**
     * Nils the "DataAbertura" element
     */
    public void setNilDataAbertura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAABERTURA$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATAABERTURA$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataAbertura" element
     */
    public void unsetDataAbertura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATAABERTURA$8, 0);
        }
    }
    
    /**
     * Gets the "DataNascimento" element
     */
    public java.lang.String getDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATANASCIMENTO$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataNascimento" element
     */
    public org.apache.xmlbeans.XmlString xgetDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATANASCIMENTO$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataNascimento" element
     */
    public boolean isNilDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATANASCIMENTO$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataNascimento" element
     */
    public boolean isSetDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATANASCIMENTO$10) != 0;
        }
    }
    
    /**
     * Sets the "DataNascimento" element
     */
    public void setDataNascimento(java.lang.String dataNascimento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATANASCIMENTO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATANASCIMENTO$10);
            }
            target.setStringValue(dataNascimento);
        }
    }
    
    /**
     * Sets (as xml) the "DataNascimento" element
     */
    public void xsetDataNascimento(org.apache.xmlbeans.XmlString dataNascimento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATANASCIMENTO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATANASCIMENTO$10);
            }
            target.set(dataNascimento);
        }
    }
    
    /**
     * Nils the "DataNascimento" element
     */
    public void setNilDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATANASCIMENTO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATANASCIMENTO$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataNascimento" element
     */
    public void unsetDataNascimento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATANASCIMENTO$10, 0);
        }
    }
    
    /**
     * Gets the "Email" element
     */
    public java.lang.String getEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Email" element
     */
    public org.apache.xmlbeans.XmlString xgetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EMAIL$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Email" element
     */
    public boolean isNilEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EMAIL$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Email" element
     */
    public boolean isSetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EMAIL$12) != 0;
        }
    }
    
    /**
     * Sets the "Email" element
     */
    public void setEmail(java.lang.String email)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EMAIL$12);
            }
            target.setStringValue(email);
        }
    }
    
    /**
     * Sets (as xml) the "Email" element
     */
    public void xsetEmail(org.apache.xmlbeans.XmlString email)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EMAIL$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EMAIL$12);
            }
            target.set(email);
        }
    }
    
    /**
     * Nils the "Email" element
     */
    public void setNilEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EMAIL$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EMAIL$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Email" element
     */
    public void unsetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EMAIL$12, 0);
        }
    }
    
    /**
     * Gets the "InscricaoEstadual" element
     */
    public java.lang.String getInscricaoEstadual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOESTADUAL$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "InscricaoEstadual" element
     */
    public org.apache.xmlbeans.XmlString xgetInscricaoEstadual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSCRICAOESTADUAL$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "InscricaoEstadual" element
     */
    public boolean isNilInscricaoEstadual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSCRICAOESTADUAL$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "InscricaoEstadual" element
     */
    public boolean isSetInscricaoEstadual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INSCRICAOESTADUAL$14) != 0;
        }
    }
    
    /**
     * Sets the "InscricaoEstadual" element
     */
    public void setInscricaoEstadual(java.lang.String inscricaoEstadual)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOESTADUAL$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSCRICAOESTADUAL$14);
            }
            target.setStringValue(inscricaoEstadual);
        }
    }
    
    /**
     * Sets (as xml) the "InscricaoEstadual" element
     */
    public void xsetInscricaoEstadual(org.apache.xmlbeans.XmlString inscricaoEstadual)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSCRICAOESTADUAL$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INSCRICAOESTADUAL$14);
            }
            target.set(inscricaoEstadual);
        }
    }
    
    /**
     * Nils the "InscricaoEstadual" element
     */
    public void setNilInscricaoEstadual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSCRICAOESTADUAL$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INSCRICAOESTADUAL$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "InscricaoEstadual" element
     */
    public void unsetInscricaoEstadual()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INSCRICAOESTADUAL$14, 0);
        }
    }
    
    /**
     * Gets the "Instalacao" element
     */
    public java.lang.String getInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALACAO$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Instalacao" element
     */
    public org.apache.xmlbeans.XmlString xgetInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$16, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Instalacao" element
     */
    public boolean isNilInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "Instalacao" element
     */
    public void setInstalacao(java.lang.String instalacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALACAO$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSTALACAO$16);
            }
            target.setStringValue(instalacao);
        }
    }
    
    /**
     * Sets (as xml) the "Instalacao" element
     */
    public void xsetInstalacao(org.apache.xmlbeans.XmlString instalacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INSTALACAO$16);
            }
            target.set(instalacao);
        }
    }
    
    /**
     * Nils the "Instalacao" element
     */
    public void setNilInstalacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INSTALACAO$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INSTALACAO$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Gets the "NomeConjuge" element
     */
    public java.lang.String getNomeConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMECONJUGE$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NomeConjuge" element
     */
    public org.apache.xmlbeans.XmlString xgetNomeConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMECONJUGE$18, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "NomeConjuge" element
     */
    public boolean isNilNomeConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMECONJUGE$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NomeConjuge" element
     */
    public boolean isSetNomeConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOMECONJUGE$18) != 0;
        }
    }
    
    /**
     * Sets the "NomeConjuge" element
     */
    public void setNomeConjuge(java.lang.String nomeConjuge)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMECONJUGE$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOMECONJUGE$18);
            }
            target.setStringValue(nomeConjuge);
        }
    }
    
    /**
     * Sets (as xml) the "NomeConjuge" element
     */
    public void xsetNomeConjuge(org.apache.xmlbeans.XmlString nomeConjuge)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMECONJUGE$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMECONJUGE$18);
            }
            target.set(nomeConjuge);
        }
    }
    
    /**
     * Nils the "NomeConjuge" element
     */
    public void setNilNomeConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMECONJUGE$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMECONJUGE$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NomeConjuge" element
     */
    public void unsetNomeConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOMECONJUGE$18, 0);
        }
    }
    
    /**
     * Gets the "NomeContato" element
     */
    public java.lang.String getNomeContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMECONTATO$20, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NomeContato" element
     */
    public org.apache.xmlbeans.XmlString xgetNomeContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMECONTATO$20, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "NomeContato" element
     */
    public boolean isNilNomeContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMECONTATO$20, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NomeContato" element
     */
    public boolean isSetNomeContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOMECONTATO$20) != 0;
        }
    }
    
    /**
     * Sets the "NomeContato" element
     */
    public void setNomeContato(java.lang.String nomeContato)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMECONTATO$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOMECONTATO$20);
            }
            target.setStringValue(nomeContato);
        }
    }
    
    /**
     * Sets (as xml) the "NomeContato" element
     */
    public void xsetNomeContato(org.apache.xmlbeans.XmlString nomeContato)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMECONTATO$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMECONTATO$20);
            }
            target.set(nomeContato);
        }
    }
    
    /**
     * Nils the "NomeContato" element
     */
    public void setNilNomeContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMECONTATO$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMECONTATO$20);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NomeContato" element
     */
    public void unsetNomeContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOMECONTATO$20, 0);
        }
    }
    
    /**
     * Gets the "NomeResponsavel" element
     */
    public java.lang.String getNomeResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMERESPONSAVEL$22, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NomeResponsavel" element
     */
    public org.apache.xmlbeans.XmlString xgetNomeResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMERESPONSAVEL$22, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "NomeResponsavel" element
     */
    public boolean isNilNomeResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMERESPONSAVEL$22, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NomeResponsavel" element
     */
    public boolean isSetNomeResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOMERESPONSAVEL$22) != 0;
        }
    }
    
    /**
     * Sets the "NomeResponsavel" element
     */
    public void setNomeResponsavel(java.lang.String nomeResponsavel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMERESPONSAVEL$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOMERESPONSAVEL$22);
            }
            target.setStringValue(nomeResponsavel);
        }
    }
    
    /**
     * Sets (as xml) the "NomeResponsavel" element
     */
    public void xsetNomeResponsavel(org.apache.xmlbeans.XmlString nomeResponsavel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMERESPONSAVEL$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMERESPONSAVEL$22);
            }
            target.set(nomeResponsavel);
        }
    }
    
    /**
     * Nils the "NomeResponsavel" element
     */
    public void setNilNomeResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMERESPONSAVEL$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMERESPONSAVEL$22);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NomeResponsavel" element
     */
    public void unsetNomeResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOMERESPONSAVEL$22, 0);
        }
    }
    
    /**
     * Gets the "Operacao" element
     */
    public int getOperacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPERACAO$24, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "Operacao" element
     */
    public org.apache.xmlbeans.XmlInt xgetOperacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(OPERACAO$24, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Operacao" element
     */
    public void setOperacao(int operacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPERACAO$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OPERACAO$24);
            }
            target.setIntValue(operacao);
        }
    }
    
    /**
     * Sets (as xml) the "Operacao" element
     */
    public void xsetOperacao(org.apache.xmlbeans.XmlInt operacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(OPERACAO$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(OPERACAO$24);
            }
            target.set(operacao);
        }
    }
    
    /**
     * Gets the "PF_PJ" element
     */
    public int getPFPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PFPJ$26, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "PF_PJ" element
     */
    public org.apache.xmlbeans.XmlInt xgetPFPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(PFPJ$26, 0);
            return target;
        }
    }
    
    /**
     * Sets the "PF_PJ" element
     */
    public void setPFPJ(int pfpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PFPJ$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PFPJ$26);
            }
            target.setIntValue(pfpj);
        }
    }
    
    /**
     * Sets (as xml) the "PF_PJ" element
     */
    public void xsetPFPJ(org.apache.xmlbeans.XmlInt pfpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(PFPJ$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(PFPJ$26);
            }
            target.set(pfpj);
        }
    }
    
    /**
     * Gets the "PN" element
     */
    public java.lang.String getPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PN$28, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "PN" element
     */
    public org.apache.xmlbeans.XmlString xgetPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$28, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "PN" element
     */
    public boolean isNilPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$28, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "PN" element
     */
    public void setPN(java.lang.String pn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PN$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PN$28);
            }
            target.setStringValue(pn);
        }
    }
    
    /**
     * Sets (as xml) the "PN" element
     */
    public void xsetPN(org.apache.xmlbeans.XmlString pn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PN$28);
            }
            target.set(pn);
        }
    }
    
    /**
     * Nils the "PN" element
     */
    public void setNilPN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PN$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PN$28);
            }
            target.setNil();
        }
    }
    
    /**
     * Gets the "RG" element
     */
    public java.lang.String getRG()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RG$30, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "RG" element
     */
    public org.apache.xmlbeans.XmlString xgetRG()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RG$30, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "RG" element
     */
    public boolean isNilRG()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RG$30, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "RG" element
     */
    public boolean isSetRG()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RG$30) != 0;
        }
    }
    
    /**
     * Sets the "RG" element
     */
    public void setRG(java.lang.String rg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RG$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RG$30);
            }
            target.setStringValue(rg);
        }
    }
    
    /**
     * Sets (as xml) the "RG" element
     */
    public void xsetRG(org.apache.xmlbeans.XmlString rg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RG$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RG$30);
            }
            target.set(rg);
        }
    }
    
    /**
     * Nils the "RG" element
     */
    public void setNilRG()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RG$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RG$30);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "RG" element
     */
    public void unsetRG()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RG$30, 0);
        }
    }
    
    /**
     * Gets the "RGConjuge" element
     */
    public java.lang.String getRGConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RGCONJUGE$32, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "RGConjuge" element
     */
    public org.apache.xmlbeans.XmlString xgetRGConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RGCONJUGE$32, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "RGConjuge" element
     */
    public boolean isNilRGConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RGCONJUGE$32, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "RGConjuge" element
     */
    public boolean isSetRGConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RGCONJUGE$32) != 0;
        }
    }
    
    /**
     * Sets the "RGConjuge" element
     */
    public void setRGConjuge(java.lang.String rgConjuge)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RGCONJUGE$32, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RGCONJUGE$32);
            }
            target.setStringValue(rgConjuge);
        }
    }
    
    /**
     * Sets (as xml) the "RGConjuge" element
     */
    public void xsetRGConjuge(org.apache.xmlbeans.XmlString rgConjuge)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RGCONJUGE$32, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RGCONJUGE$32);
            }
            target.set(rgConjuge);
        }
    }
    
    /**
     * Nils the "RGConjuge" element
     */
    public void setNilRGConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RGCONJUGE$32, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RGCONJUGE$32);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "RGConjuge" element
     */
    public void unsetRGConjuge()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RGCONJUGE$32, 0);
        }
    }
    
    /**
     * Gets the "RgResponsavel" element
     */
    public java.lang.String getRgResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RGRESPONSAVEL$34, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "RgResponsavel" element
     */
    public org.apache.xmlbeans.XmlString xgetRgResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RGRESPONSAVEL$34, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "RgResponsavel" element
     */
    public boolean isNilRgResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RGRESPONSAVEL$34, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "RgResponsavel" element
     */
    public boolean isSetRgResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RGRESPONSAVEL$34) != 0;
        }
    }
    
    /**
     * Sets the "RgResponsavel" element
     */
    public void setRgResponsavel(java.lang.String rgResponsavel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RGRESPONSAVEL$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RGRESPONSAVEL$34);
            }
            target.setStringValue(rgResponsavel);
        }
    }
    
    /**
     * Sets (as xml) the "RgResponsavel" element
     */
    public void xsetRgResponsavel(org.apache.xmlbeans.XmlString rgResponsavel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RGRESPONSAVEL$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RGRESPONSAVEL$34);
            }
            target.set(rgResponsavel);
        }
    }
    
    /**
     * Nils the "RgResponsavel" element
     */
    public void setNilRgResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(RGRESPONSAVEL$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(RGRESPONSAVEL$34);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "RgResponsavel" element
     */
    public void unsetRgResponsavel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RGRESPONSAVEL$34, 0);
        }
    }
    
    /**
     * Gets the "TelefoneCelular" element
     */
    public java.lang.String getTelefoneCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TELEFONECELULAR$36, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "TelefoneCelular" element
     */
    public org.apache.xmlbeans.XmlString xgetTelefoneCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONECELULAR$36, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "TelefoneCelular" element
     */
    public boolean isNilTelefoneCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONECELULAR$36, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "TelefoneCelular" element
     */
    public boolean isSetTelefoneCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TELEFONECELULAR$36) != 0;
        }
    }
    
    /**
     * Sets the "TelefoneCelular" element
     */
    public void setTelefoneCelular(java.lang.String telefoneCelular)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TELEFONECELULAR$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TELEFONECELULAR$36);
            }
            target.setStringValue(telefoneCelular);
        }
    }
    
    /**
     * Sets (as xml) the "TelefoneCelular" element
     */
    public void xsetTelefoneCelular(org.apache.xmlbeans.XmlString telefoneCelular)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONECELULAR$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TELEFONECELULAR$36);
            }
            target.set(telefoneCelular);
        }
    }
    
    /**
     * Nils the "TelefoneCelular" element
     */
    public void setNilTelefoneCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONECELULAR$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TELEFONECELULAR$36);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "TelefoneCelular" element
     */
    public void unsetTelefoneCelular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TELEFONECELULAR$36, 0);
        }
    }
    
    /**
     * Gets the "TelefoneContato" element
     */
    public java.lang.String getTelefoneContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TELEFONECONTATO$38, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "TelefoneContato" element
     */
    public org.apache.xmlbeans.XmlString xgetTelefoneContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONECONTATO$38, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "TelefoneContato" element
     */
    public boolean isNilTelefoneContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONECONTATO$38, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "TelefoneContato" element
     */
    public boolean isSetTelefoneContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TELEFONECONTATO$38) != 0;
        }
    }
    
    /**
     * Sets the "TelefoneContato" element
     */
    public void setTelefoneContato(java.lang.String telefoneContato)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TELEFONECONTATO$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TELEFONECONTATO$38);
            }
            target.setStringValue(telefoneContato);
        }
    }
    
    /**
     * Sets (as xml) the "TelefoneContato" element
     */
    public void xsetTelefoneContato(org.apache.xmlbeans.XmlString telefoneContato)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONECONTATO$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TELEFONECONTATO$38);
            }
            target.set(telefoneContato);
        }
    }
    
    /**
     * Nils the "TelefoneContato" element
     */
    public void setNilTelefoneContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONECONTATO$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TELEFONECONTATO$38);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "TelefoneContato" element
     */
    public void unsetTelefoneContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TELEFONECONTATO$38, 0);
        }
    }
    
    /**
     * Gets the "TelefoneFixo" element
     */
    public java.lang.String getTelefoneFixo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TELEFONEFIXO$40, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "TelefoneFixo" element
     */
    public org.apache.xmlbeans.XmlString xgetTelefoneFixo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONEFIXO$40, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "TelefoneFixo" element
     */
    public boolean isNilTelefoneFixo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONEFIXO$40, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "TelefoneFixo" element
     */
    public boolean isSetTelefoneFixo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TELEFONEFIXO$40) != 0;
        }
    }
    
    /**
     * Sets the "TelefoneFixo" element
     */
    public void setTelefoneFixo(java.lang.String telefoneFixo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TELEFONEFIXO$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TELEFONEFIXO$40);
            }
            target.setStringValue(telefoneFixo);
        }
    }
    
    /**
     * Sets (as xml) the "TelefoneFixo" element
     */
    public void xsetTelefoneFixo(org.apache.xmlbeans.XmlString telefoneFixo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONEFIXO$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TELEFONEFIXO$40);
            }
            target.set(telefoneFixo);
        }
    }
    
    /**
     * Nils the "TelefoneFixo" element
     */
    public void setNilTelefoneFixo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TELEFONEFIXO$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TELEFONEFIXO$40);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "TelefoneFixo" element
     */
    public void unsetTelefoneFixo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TELEFONEFIXO$40, 0);
        }
    }
}
