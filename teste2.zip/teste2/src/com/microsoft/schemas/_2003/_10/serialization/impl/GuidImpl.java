/*
 * XML Type:  guid
 * Namespace: http://schemas.microsoft.com/2003/10/Serialization/
 * Java type: com.microsoft.schemas._2003._10.serialization.Guid
 *
 * Automatically generated - do not modify.
 */
package com.microsoft.schemas._2003._10.serialization.impl;
/**
 * An XML guid(@http://schemas.microsoft.com/2003/10/Serialization/).
 *
 * This is an atomic type that is a restriction of com.microsoft.schemas._2003._10.serialization.Guid.
 */
public class GuidImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements com.microsoft.schemas._2003._10.serialization.Guid
{
    private static final long serialVersionUID = 1L;
    
    public GuidImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected GuidImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
