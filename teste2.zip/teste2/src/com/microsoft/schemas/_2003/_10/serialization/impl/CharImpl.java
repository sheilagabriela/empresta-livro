/*
 * XML Type:  char
 * Namespace: http://schemas.microsoft.com/2003/10/Serialization/
 * Java type: com.microsoft.schemas._2003._10.serialization.Char
 *
 * Automatically generated - do not modify.
 */
package com.microsoft.schemas._2003._10.serialization.impl;
/**
 * An XML char(@http://schemas.microsoft.com/2003/10/Serialization/).
 *
 * This is an atomic type that is a restriction of com.microsoft.schemas._2003._10.serialization.Char.
 */
public class CharImpl extends org.apache.xmlbeans.impl.values.JavaIntHolderEx implements com.microsoft.schemas._2003._10.serialization.Char
{
    private static final long serialVersionUID = 1L;
    
    public CharImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected CharImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
